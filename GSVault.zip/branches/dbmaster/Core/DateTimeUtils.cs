using System;

public static class DateTimeUtils
{
    public static long ToTimeStamp(this DateTime currentTime)
    {
        DateTimeOffset dateTimeOffsetLocal = new DateTimeOffset(currentTime);
        return dateTimeOffsetLocal.ToUnixTimeMilliseconds();
    }

    public static DateTime RoundToSecond(this DateTime dt)
    {
        return new DateTime(dt.Year, dt.Month, dt.Day,
                            dt.Hour, dt.Minute, dt.Second);
    }

    public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
    {
        // Unix timestamp is seconds past epoch
        DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
        dateTime = dateTime.AddMilliseconds(unixTimeStamp).ToLocalTime();
        return dateTime;
    }
}
