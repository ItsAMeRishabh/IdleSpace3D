﻿using GS.GameConsts;
using System.Collections.Generic;

namespace GS
{
    public class GameManager
    {
        private GameState currentState = GameState.NullState;

        public GameState CurrentState
        {
            get { return currentState; }
            private set { currentState = value; }
        }

        /// <summary>
        /// List of controllers which are required entire game
        /// </summary>
        private List<IController> appControllers = new List<IController>();

        /// <summary>
        /// List of active controllers for current scene
        /// </summary>
        private List<IController> sceneControllers = new List<IController>();

        /// <summary>
        /// Holds the previous Game state
        /// </summary>
        private GameState previousState = GameState.NullState;


        /// <summary>
        /// Sets the New Game State 
        /// </summary>
        /// <param name="state"></param>
        public void SetGameState(GameState state)
        {
            previousState = currentState; this.currentState = state;
        }

        /// <summary>
        /// Controls the Pause state of the game.
        /// Sets back the previous state on Resume
        /// </summary>
        /// <param name="pause">Pause/Resume</param>
        public void Pause(bool pause)
        {
            if (pause && currentState != GameState.Paused)
            {
                SetGameState(GameState.Paused);

                // Store current TimeScale of the game
               // timeScaleBeforePause = Time.timeScale;

                // Set Game TimeScale to 0 to pause game
               // Time.timeScale = 0.0f;
            }
            else if (!pause && currentState == GameState.Paused)
            {
                SetGameState(previousState);

                // Assign timeScale that we saved before pauing the game
                // Time.timeScale = timeScaleBeforePause;
            }
        }
            
        /// <summary>
        /// Internal App Controller init 
        /// </summary>
        /// <param name="controller"></param>
        public void InitAppController(IController controller)
        {
            if (controller != null)
            {
                controller.Initialize();
                controller.RegisterListener();
                appControllers.Add(controller);
            }
            else
                Log.Error("Controller is null, not able to Initialize");
        }

        /// <summary>
        /// Add controller to controllers list
        /// </summary>
        /// <param name="controller"></param>
        public void AddSceneController(IController controller)
        {
            controller.Initialize();
            controller.RegisterListener();
            sceneControllers.Add(controller);

        }

        /// <summary>
        /// Removes the controller from controllers
        /// </summary>
        /// <param name="controller"></param>
        public void RemoveSceneController(IController controller)
        {
            sceneControllers.Remove(controller);
            controller.UnRegisterListener();
            controller.Release();
        }


        /// <summary>
        /// Releases all active controllers 
        /// </summary>
        public void RemoveAllControllers()
        {
            if (sceneControllers == null)
                return;

            for (int i = 0; i < sceneControllers.Count; i++)
            {
                sceneControllers[i].UnRegisterListener();
                sceneControllers[i].Release();
            }
            sceneControllers.Clear();
        }

        public void RegisterAllAppController()
        {
            for (int i = 0; i < appControllers.Count; i++)
                appControllers[i].RegisterListener();
        }

        /// <summary>
        /// Updates all controllers here
        /// </summary>
        public void Update()
        {
            for (int i = 0; i < appControllers.Count; i++)
            {
                appControllers[i].Update();
            }

            for (int i = 0; i < sceneControllers.Count; i++)
            {
                sceneControllers[i].Update();
            }
        }

        /// <summary>
        /// Releases all controllers while Quitting Application
        /// </summary>
        public void QuitApplication()
        {
            if (appControllers != null)
            {
                for (int i = 0; i < appControllers.Count; i++)
                    appControllers[i].Release();
                appControllers.Clear();
            }
        }

    }
}
