﻿using System;
using GS.GameEvents;

namespace GS
{
    /// <summary>
    /// Instantiates game manager class and listenes Application related events
    /// </summary>
    public class GameManagerController<TSettingsType> : IController
        where TSettingsType : Enum
    {
        /// <summary>
        /// reference to Game Manager Instance
        /// </summary>
        private GameManager gameManager;

        private Settings settings = new Settings();

        /// <summary>
        /// Instanstiates Game Manager and settings 
        /// </summary>
        public void Initialize()
        {
            gameManager = new GameManager();

            int length = Enum.GetNames(typeof(TSettingsType)).Length;
            settings = new Settings();
            settings.Intialize(length);
        }

        /// <summary>
        /// Registering all game manager related Events
        /// </summary>
        public void RegisterListener()
        {
            Utils.EM.AddListener<GameEvents.ChangeGameState>(OnGameStateChangeListener);
            Utils.EM.AddListener<AddSceneController>(OnAddSceneControllerListener);
            Utils.EM.AddListener<AddAppController>(OnAddAppControllerListener);
            Utils.EM.AddListener<GameEvents.ApplicationQuitEvent>(OnQuitApplicationListener);
            Utils.EM.AddListener<GameEvents.SetSettingEvent>(OnSetSettingListener);
            Utils.EM.AddListener<GameEvents.GetSettingEvent>(OnGetSettingListener);
        }

        /// <summary>
        /// Unregistering all game manager related Events
        /// </summary>
        public void UnRegisterListener()
        {
            Utils.EM.RemoveListener<GameEvents.ChangeGameState>(OnGameStateChangeListener);
            Utils.EM.RemoveListener<AddSceneController>(OnAddSceneControllerListener);
 			Utils.EM.RemoveListener<AddAppController>(OnAddAppControllerListener);
            Utils.EM.RemoveListener<GameEvents.ApplicationQuitEvent>(OnQuitApplicationListener);
            Utils.EM.RemoveListener<GameEvents.SetSettingEvent>(OnSetSettingListener);
            Utils.EM.RemoveListener<GameEvents.GetSettingEvent>(OnGetSettingListener);
        }

        /// <summary>
        /// Callback for Get Settings Event value by setting type
        /// </summary>
        /// <param name="getEvent"></param>
        private void OnGetSettingListener(GetSettingEvent getEvent)
        {
            if (getEvent == null || getEvent.callback == null)
                return;

            getEvent.callback(settings.Get((int)getEvent.key, getEvent.defaultValue));
        }


        /// <summary>
        /// Listener for Set the settings data by setting type
        /// </summary>
        /// <param name="setEvent"></param>
        private void OnSetSettingListener(SetSettingEvent setEvent)
        {
            if (setEvent == null)
                return;

            settings.Set((int)setEvent.key, setEvent.val);
        }

        /// <summary>
        /// Adds scene controller which are getting created in SceneHandler classes
        /// </summary>
        /// <param name="sceneControllerEvent"></param>
        private void OnAddSceneControllerListener(AddSceneController sceneControllerEvent)
        {
            if (sceneControllerEvent == null || gameManager == null)
                return;
            gameManager.AddSceneController(sceneControllerEvent.controller);
        }

        /// <summary>
        /// Adds app controller which are getting created in SceneHandler classes
        /// </summary>
        /// <param name="sceneControllerEvent"></param>
        private void OnAddAppControllerListener(AddAppController sceneControllerEvent)
        {
            if (sceneControllerEvent == null || gameManager == null)
                return;
            gameManager.InitAppController(sceneControllerEvent.controller);
        }

        /// <summary>
        /// Registering all App Controllers here
        /// </summary>
        public void RegisterAllAppController()
        {
            if (gameManager == null)
                return;
            gameManager.RegisterAllAppController();
        }

        /// <summary>
        /// Adds Controller which remains throught out the game
        /// </summary>
        /// <param name="controller"></param>
        public void AddAppController(IController controller)
        {
            if (controller == null || gameManager == null)
                return;
            gameManager.InitAppController(controller);
        }

        /// <summary>
        /// Listener for Quit Application Event
        /// </summary>
        /// <param name="quitEvent"></param>
        private void OnQuitApplicationListener(ApplicationQuitEvent quitEvent)
        {
            if (quitEvent == null || gameManager == null)
                return;
            gameManager.QuitApplication();
        }

        /// <summary>
        /// Listener for Change Game State Event
        /// </summary>
        /// <param name="gameStateEvent"></param>
        private void OnGameStateChangeListener(ChangeGameState gameStateEvent)
        {
            if (gameStateEvent == null || gameManager == null)
                return;
            gameManager.SetGameState(gameStateEvent.gameState);
        }


        /// <summary>
        /// Updates all app and scene controllers
        /// </summary>
        public void Update()
        {
            if (gameManager != null)
                gameManager.Update();
        }

        /// <summary>
        /// Relases resources here if any while quitting
        /// </summary>
        public void Release()
        {
            
        }
    }
}
