﻿
using System;
using System.Collections;
using System.Collections.Generic;

namespace GS
{
    /// <summary>
    /// This class holds all types Settings data
    /// </summary>
    public class Settings
    {
        private object[] properties;

        public void Intialize(int maxCount)
        {
            properties = new object[maxCount];
        }

        public virtual void Set(int index, object data)
        {
            properties[index] = data;
        }

        public virtual object Get(int index, object defaultValue)
        {
            if(properties == null && (index < properties.Length && index >= 0))
            {
                object val = properties[index];
                if (val != null)
                    return val;
            }
            return defaultValue;
        }
    }

    /// <summary>
    /// Category Template used for User Profile and Store
    /// </summary>
    public class Category
    {
        /// <summary>
        /// Category ID
        /// </summary>
        public string id;

        /// <summary>
        /// Category Name
        /// </summary>
        public string name;

        /// <summary>
        /// Category description
        /// </summary>
        public string description;

        /// <summary>
        /// Access using custom enum as index
        /// </summary>
        public ArrayList userData;

        /// <summary>
        /// Multi level sub categories if required
        /// </summary>
        public List<Category> subCategory;
    }

    public class UserProfile
    {
        public string profileName;
        public Category userData;
    }


    public class ProfileManager
    {
        public UserProfile currentProfile;

        public void Load()
        {

        }

        public void Save()
        {

        }
    }
}
