﻿using GS.GameConsts;
using UnityEngine;

namespace GS.Audio
{
    /// <summary>
    /// interface for accessing all types of Audio System 
    /// </summary>
    public interface IAudioSystem
    {
        /// <summary>
        /// Prepares Audio Sources and Audio Listeners
        /// </summary>
        void Initialize();

        /// <summary>
        /// Updates Timer based functionalities
        /// </summary>
        void Update();


        /// <summary>
        /// Is clip playing in channel
        /// </summary>
        /// <param name="channel"></param>
        /// <returns></returns>
        bool IsPlaying(AudioChannelType channel);

        void PlayClip(AudioChannelType channel, AudioClip clip, bool loop, float fadeSpeed);

        /// <summary>
        /// Plays an audio clip based on channel type and index type
        /// </summary>
        /// <param name="channel"></param>
        /// <param name="audioIndex"></param>
        /// <param name="loop"></param>
        /// <param name="fadeSpeed">if 0, no fading functionality</param>
        void Play(AudioChannelType channel, int audioIndex, bool loop, float fadeSpeed);

        /// <summary>
        /// Pause an Audio Source by channel type
        /// </summary>
        /// <param name="channel"></param>
        void Pause(AudioChannelType channel);

        /// <summary>
        /// Resumes an audio Source by channel type
        /// </summary>
        /// <param name="channel"></param>
        void Resume(AudioChannelType channel);

        /// <summary>
        /// Stops an audio source by channel 
        /// </summary>
        void Stop(AudioChannelType channel);

        /// <summary>
        /// Set volume of particular channel
        /// </summary>
        /// <param name="channel"></param>
        void SetVolume(AudioChannelType channel, float volume);

        /// <summary>
        /// Gets the current volume of this channel
        /// </summary>
        /// <param name="channel"></param>
        /// <returns></returns>
        float GetVolume(AudioChannelType channel);


        /// <summary>
        /// Sets the master volume which will effect all channels
        /// </summary>
        void SetMasterVolume(float volume);

        /// <summary>
        /// Gets the master volume
        /// </summary>
        /// <returns></returns>
        float GetMasterVolume();

        /// <summary>
        /// Pauses all audio clips in all channels
        /// </summary>
        void PauseAll();

        /// <summary>
        /// Resumes all audio clips in all channels
        /// </summary>
        void ResumeAll();

        /// <summary>
        /// Stop playing all audio clips  in all channels
        /// </summary>
        void StopAll();

        void SetTimer(AudioChannelType channelType, float time);

        float GetTimer(AudioChannelType channelType);
    }
}
