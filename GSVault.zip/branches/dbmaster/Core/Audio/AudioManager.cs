﻿
namespace GS.Audio
{
    /// <summary>
    /// This class manages all perform audio actions like play, pause, mute, volume control etc...
    /// </summary>
    public class AudioManager
    {
        public class ChannelData
        {

        }

    }
}
