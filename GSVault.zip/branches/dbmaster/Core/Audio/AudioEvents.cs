﻿
namespace GS
{
    public enum AudioChannelType
    {
        Music,
        SFX,
        Voice
    }

    namespace AudioEvents
    {

    }
}
