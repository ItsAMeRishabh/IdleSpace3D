﻿
namespace GS.Audio
{
    /// <summary>
    /// Base Audio class for all types of Audios
    /// </summary>
    public abstract class IAudio
    {

    }
}
