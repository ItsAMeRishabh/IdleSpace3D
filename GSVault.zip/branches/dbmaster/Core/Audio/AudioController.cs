﻿
namespace GS.Audio
{
    /// <summary>
    /// Listenes Audio replated Events and performs corresponding Audio Actions
    /// </summary>
    class AudioController : IController
    {
        /// <summary>
        /// Initializes Audio Manager
        /// </summary>
        public void Initialize()
        {

        }

        /// <summary>
        /// Registering all Audio related Listeners here
        /// </summary>
        public void RegisterListener()
        {

        }

        public void Release()
        {
        }

        /// <summary>
        /// UnRegistering all Audio related Listeners here
        /// </summary>

        public void UnRegisterListener()
        {
        }

        public void Update()
        {
        }
    }
}
