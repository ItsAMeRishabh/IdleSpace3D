﻿
namespace GS
{
    /// <summary>
    /// Logger Interface class for logging messages
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        /// Logs a message as Warning
        /// </summary>
        /// <param name="message"></param>
        void Warning(object message);

        /// <summary>
        /// Logs a message to the Console
        /// </summary>
        /// <param name="message"></param>
        void Print(object message, LogFilter logFilter);

        /// <summary>
        /// Logs a message to the Console
        /// </summary>
        /// <param name="message"></param>
        void Print(object message, UnityEngine.Object obj, LogFilter logFilter);

        /// <summary>
        /// Logs a Error message to the Unity Console
        /// </summary>
        /// <param name="message"></param>
        void Error(object message);
    }
}
