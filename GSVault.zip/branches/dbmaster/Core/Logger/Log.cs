﻿
namespace GS
{
    /// <summary>
    /// Log Filter Type
    /// </summary>
    public enum LogFilter : byte
    {
        Default = 0,
        UI = 1,
        Game = 2,
        GameEvent = 4,
        Error = 8,
        Network = 16,
        Data
    }

    /// <summary>
    /// LogFilter Compares with & operation
    /// </summary>
    public static class LogFilterCompare
    {
        public static bool Compare(this LogFilter myFlag, LogFilter condition)
        {
            return ((myFlag & condition) == myFlag);
        }
    }

    /// <summary>
    /// Log class handles all logging message using filter
    /// </summary>
    public static class Log
    {
        private static ILogger logger = null;
        private static LogFilter currentFilter = LogFilter.Default;

        /// <summary>
        /// logger has to set before calling Print function 
        /// </summary>
        /// <param name="ilogger"></param>
        /// <param name="logFilter"></param>
        public static void Initialize(ILogger ilogger, LogFilter logFilter)
        {
            logger = ilogger;
            currentFilter = logFilter;
        }

        /// <summary>
        /// Prints message if logfilter success
        /// </summary>
        /// <param name="message"></param>
        /// <param name="logFilter"></param>
        public static void Print(string message, LogFilter logFilter = LogFilter.Default)
        {
            if (logger == null)
                return;

            if(logFilter.Compare(currentFilter))
                logger.Print(message, logFilter);
        }

        /// <summary>
        /// Prints message if logfilter success
        /// </summary>
        /// <param name="message"></param>
        /// <param name="logFilter"></param>
        public static void Print(string message, UnityEngine.Object obj, LogFilter logFilter = LogFilter.Default)
        {
            if (logger == null)
                return;

            if (logFilter.Compare(currentFilter))
                logger.Print(message, obj, logFilter);
        }

        /// <summary>
        /// Logs the messages as Warning
        /// </summary>
        /// <param name="message"></param>
        public static void Warning(string message)
        {
            if (logger == null)
                return;
            logger.Warning(message);
        }

        /// <summary>
        /// Logs the message as Error
        /// </summary>
        /// <param name="message"></param>
        public static void Error(string message)
        {
            if (logger == null)
                return;
            logger.Error(message);
        }
    }
}
