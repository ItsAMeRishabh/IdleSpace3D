﻿
namespace GS
{
    /// <summary>
    /// State Interface used by StateMachine
    /// </summary>
    public interface IState
    {
        /// <summary>
        /// Whether from this state can go back to previous state
        /// </summary>
        bool CanGoBack { get; set; }

        /// <summary>
        /// Flag whther this state to be added to Previous Stack or not
        /// </summary>
        bool AddToPreviousStack { get; set; }

        /// <summary>
        /// Initialize your objects here
        /// </summary>
        void Initialize();

        /// <summary>
        /// Returns State Id
        /// </summary>
        /// <returns></returns>
        int GetStateID();

        /// <summary>
        /// Triggers while entering state
        /// </summary>
        void DoBeforeEntering();

        /// <summary>
        /// Update once per frame
        /// </summary>
        void UpdateState();

        /// <summary>
        /// Triggers when it is leaving this state
        /// </summary>
        void DoBeforeLeaving();

        /// <summary>
        /// Destroy your object here
        /// </summary>
        void Release();

    }
}
