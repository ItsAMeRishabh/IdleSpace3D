﻿using System.Collections.Generic;

namespace GS
{
    /// <summary>
    /// State machine hold and manages all states. 
    /// </summary>
    public abstract class StateMachine
    {
        public int CurrentStateID
        {
            get
            {
                if (currentState != null)
                    return currentState.GetStateID();
                else
                    return -1; // No State Assigned
            }
        }
       

        /// <summary>
        /// Holds the current State
        /// </summary>
        protected IState currentState;

        /// <summary>
        /// Holds Current state
        /// </summary>
        public IState CurrentState { get { return currentState; } }

        /// <summary>
        /// List of all States
        /// </summary>
        protected List<IState> states;

        /// <summary>
        /// List of Previous States Stack
        /// </summary>
        protected List<IState> previousStates;

        public StateMachine()
        {
           
        }

        /// <summary>
        /// Initializes all lists 
        /// </summary>
        public virtual void Initialize()
        {
            states = new List<IState>();
            previousStates = new List<IState>();
        }


        /// <summary>
        /// Add state to state machine
        /// </summary>
        /// <param name="s"></param>
        public virtual void AddState(IState s)
        {
            if (states == null)
                return;

            if (s == null)
            {
                Log.Error("Trying to add NULL state");
                return;
            }
            
            if (!states.Contains(s))
            {
                s.Initialize();
                states.Add(s);
            }

            if (states.Count == 1)
            {
                //This is the first state and immediate state.
                ChangeState(s);
            }

            
        }

        /// <summary>
        /// Get state by state ID
        /// </summary>
        /// <param name="stateID"></param>
        /// <returns></returns>
        public IState GetState(int stateID)
        {
            if (states.Count == 0)
                return null;

            for (int i = 0; i < states.Count; i++)
            {
                if (states[i].GetStateID() == stateID)
                    return states[i];
            }
            return null;
        }

        /// <summary>
        /// Adds a State to previous state list if that state can Add to Stack is enabled
        /// </summary>
        /// <param name="state"></param>
        protected void AddToPreviousStates(IState state)
        {
            if (!state.AddToPreviousStack)
                return;

            if (previousStates.Contains(state))
            {
                int index = previousStates.FindIndex(x => x == state);
                int length = previousStates.Count - index;
                if (length > 0)
                    previousStates.RemoveRange(index, length - 1);
            }
            else
                previousStates.Add(state);
        }

        /// <summary>
        /// Goes to previous state if can go back is enabled
        /// </summary>
        public virtual void GoToPreviousState()
        {
            if (currentState.CanGoBack)
            {
                if (previousStates.Count - 1 >= 0)
                    ChangeState(previousStates[previousStates.Count - 1].GetStateID());
            }
        }

        /// <summary>
        /// Switches state for current state to New  State
        /// </summary>
        /// <param name="state"></param>
        public virtual void ChangeState(IState state)
        {
            if (state == null)
            {
                Log.Error("Changing State to null State is not allowed");
                return;
            }

            if (currentState == state)
            {
                Log.Error("trying to switch to same state");
                return;
            }

            if (currentState != null)
            {
                //Call DoBeforeLeaving function before leaving the current state.
                currentState.DoBeforeLeaving();

                //add current state to previous states.
                AddToPreviousStates(currentState);
            }

            //Set current state to new state.
            currentState = state;

            //event to let the listeners know new current state
            Utils.EventAsync(new GameEvents.UIManagerScreenChanged(currentState.GetStateID()));

            //Call DoBeforeEntering function to run before the UpdateState is called.
            currentState.DoBeforeEntering();
        }

        /// <summary>
        /// Changes to new State by State ID
        /// </summary>
        /// <param name="ID"></param>
        public virtual void ChangeState(int stateID)
        {
            IState toState = GetState(stateID);
            ChangeState(toState);
        }

        /// <summary>
        /// Updates the current state
        /// </summary>
        public virtual void Update()
        {
            if (currentState != null)
                currentState.UpdateState();
        }

        /// <summary>
        /// Release all states
        /// </summary>
        public virtual void Release()
        {
            for(int i=0;i<states.Count;i++)
                states[i].Release();

            states.Clear();
            currentState = null;
        }

    }
}