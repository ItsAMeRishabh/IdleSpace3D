﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace GS
{
    /// <summary>
    /// Common Utility functions which are frequently used in entire project
    /// </summary>
    public static class Utils
    {


        /// <summary>
        /// Shuffles the generic list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list"></param>
        public static void Shuffle<T>(this IList<T> list)
        {
            int n = list.Count;
            System.Random rnd = new System.Random();
            while (n > 1)
            {
                int k = (rnd.Next(0, n) % n);
                n--;
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }

        /// <summary>
        /// Adds IEnumerable type to current one.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target"></param>
        /// <param name="source"></param>
        public static void AddRange<T>(this ICollection<T> target, IEnumerable<T> source)
        {
            if (target == null)
                throw new ArgumentNullException(target.ToString());
            if (source == null)
                throw new ArgumentNullException(source.ToString());
            foreach (var element in source)
                target.Add(element);
        }

        // Convert an object to a byte array
        public static byte[] ObjectToByteArray(System.Object obj)
        {
            if (obj == null)
                return null;

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, obj);

            return ms.ToArray();
        }

        // Convert a byte array to an Object
        public static System.Object ByteArrayToObject(byte[] arrBytes)
        {
            MemoryStream memStream = new MemoryStream();
            BinaryFormatter binForm = new BinaryFormatter();
            memStream.Write(arrBytes, 0, arrBytes.Length);
            memStream.Seek(0, SeekOrigin.Begin);
            System.Object obj = (System.Object)binForm.Deserialize(memStream);

            return obj;
        }



        /// <summary>
        /// Short form to get the Event manager instance
        /// </summary>
        public static EventManager EM
        {
            get
            {
                return EventManager.Instance;
            }
        }

        /// <summary>
        /// Triggers the Event Synchronously(Direct callstack)
        /// </summary>
        /// <param name="gameEvent"></param>
        public static void EventSync(GameEvent gameEvent)
        {
            EventManager.Instance.TriggerEvent(gameEvent);
        }

        /// <summary>
        /// Adds Event to queue and processed in Update
        /// </summary>
        /// <param name="gameEvent"></param>
        public static void EventAsync(GameEvent gameEvent)
        {
            EventManager.Instance.QueueEvent(gameEvent);
        }

        /// <summary>
        /// Parses time in string format to return in System.DateTime format
        /// </summary>
        /// <param name="date"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static DateTime ParseDateTime(string date, string time, string datePattern, string timePattern)
        {

            DateTime _date;
            if (!DateTime.TryParseExact(date, datePattern, null, System.Globalization.DateTimeStyles.AdjustToUniversal, out _date))
                _date = DateTime.Now;

            DateTime _time;
            if (!DateTime.TryParseExact(time, timePattern, null, System.Globalization.DateTimeStyles.AdjustToUniversal, out _time))
                _time = DateTime.Now;

        
            DateTime finalDate = new DateTime(_date.Year, _date.Month, _date.Day, _time.Hour, _time.Minute, _time.Second);

            return finalDate;
        }

        /// <summary>
        /// Gets current device time
        /// </summary>
        /// <param name="dateTime"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static DateTime GetCurrentTime(string dateTime, string pattern)
        {
            DateTime outDate;
            if (!DateTime.TryParseExact(dateTime, pattern, null, System.Globalization.DateTimeStyles.None, out outDate))
                outDate = DateTime.Now;

            return outDate;
        }

        /// <summary>
        /// Using MiniJson
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static Dictionary<string, System.Object> ConvertStringToJsonNode(string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                // Empty Data, returning null
                return null;
            }
            Dictionary<string, System.Object> dict = MiniJSON.Json.Deserialize(data) as Dictionary<string, System.Object>;

            return dict;
        }

    }

    
}
