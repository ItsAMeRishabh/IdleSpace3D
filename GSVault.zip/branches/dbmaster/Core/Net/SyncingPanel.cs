using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

namespace GS.Net
{
    public class SyncingPanel : MonoBehaviour
    {
        [HideInInspector]
        public static SyncingPanel instance = null;
        [HideInInspector]
        public static bool isSyncing = false;

        [SerializeField]
        private Image image;
        [SerializeField]
        private TextMeshProUGUI message;
        [SerializeField]
        private float rotationSpeed = 3;

        public void Init()
        {
            if (instance == null)
            {
                instance = this;
                HidePopUp();
                DontDestroyOnLoad(gameObject);
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void Update()
        {
            image.transform.Rotate(new Vector3(0, 0, rotationSpeed * Time.deltaTime));
        }

        public void ShowPopUp()
        {
            if (NetworkUtils.OfflineReady)
            {
                gameObject.SetActive(true);
                isSyncing = true;
                NetworkUtils.IsBackBlocked = true;
            }
            else
            {
                HidePopUp();
            }
        }

        public void HidePopUp()
        {
            isSyncing = false;
            NetworkUtils.IsBackBlocked = false;
            gameObject.SetActive(false);
        }
    }
}
