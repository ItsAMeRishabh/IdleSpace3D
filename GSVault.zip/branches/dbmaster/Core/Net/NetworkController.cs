﻿using StompHelper;
using System;
using System.Collections.Generic;

namespace GS.Net
{
    /// <summary>
    /// This class listens all base Network Events and can able to create websocket instance
    /// </summary>
    public class NetworkController : IController
    {
        /// <summary>
        /// Refernce to websocket instance
        /// </summary>
        protected  IWebSocket webSocket;

        public virtual void Initialize()
        {

        }

        public virtual void RegisterListener()
        {
            
        }

        public virtual void Release()
        {
            
        }

        public virtual void UnRegisterListener()
        {
            
        }

        public virtual void Update()
        {
            if (webSocket != null)
                webSocket.Update();
            
        }

        /// <summary>
        /// Creates Web Socket and Assigns callbacks
        /// </summary>
        /// <param name="url"></param>
        protected virtual void CreateWebSocket(string url, string userID, bool isStompFormat) //, System.Action<string> OnOpen, System.Action<string> OnClose, System.Action<string> OnError, System.Action<string> OnMessage)
        {
            webSocket = new GSWebSocket();

            RegisterSocketCallbacks();

            webSocket.Create(url, userID);
        }

		/// <summary>
		/// Creates Web Socket and Assigns callbacks
		/// </summary>
		/// <param name="url"></param>
		protected virtual void CreateWebSocket(string url)
		{
			webSocket = new GSWebSocket();

			RegisterSocketCallbacks();

			webSocket.Create(url, null);
		}


		/// <summary>
		/// This method is used to register callbacks to websocket
		/// NOTE:: this method is to be called after creation of websocket
		/// </summary>
		protected void RegisterSocketCallbacks()
        {
            webSocket.RegisterCallback(SocketCallbacks.OnOpen, OnOpen);
            webSocket.RegisterCallback(SocketCallbacks.OnClose, OnClose);
            webSocket.RegisterCallback(SocketCallbacks.OnError, OnError);
            webSocket.RegisterCallback(SocketCallbacks.OnMessage, OnMessage);
        }

        /// <summary>
        /// Upgrades websocket to stomp protocol on first time calling this method.
        /// Send message in stomp format
        /// </summary>
        /// <param name="command"></param>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <param name="callback"></param>
        public void StompMessage(StompClientCommand command, Dictionary<string, string> data, string key, Action<string> callback)
        {
            if(webSocket != null)
                webSocket.StompMessage(command, data, key, callback);
        }

		public void SendMessage(String message)
        {
            webSocket.SendMessage(message);
        }
        #region web socket callbacks

        /// <summary>
        /// Callback to On Websocket Open Connection
        /// </summary>
        /// <param name="message"></param>
        public virtual void OnOpen(string message)
        {
            Log.Print("Websocket Opened ::" + message, LogFilter.Network);
        }

        /// <summary>
        /// On Closing Websocket callback
        /// </summary>
        /// <param name="reason"></param>
        public virtual void OnClose(string reason)
        {
            Log.Print("Closed WebSocket Reason :: " + reason, LogFilter.Network);
        }


        /// <summary>
        /// Callback for OnReceive message to WebSocket
        /// </summary>
        /// <param name="message"></param>
        public virtual void OnMessage(string message)
        {
            Log.Print("Message Recieved :: " + message, LogFilter.Network);
        }

        /// <summary>
        /// Callback for On error received to Web Socket
        /// </summary>
        /// <param name="error"></param>
        public virtual void OnError(string error)
        {
            Log.Error("Websocket Error :: " + error);
        }

        #endregion
    }
}
