﻿using GS.Data.Encryption;
using Newtonsoft.Json;
using System.IO;

namespace GS.Data.Saving
{
    public class EncryptedTxtSavingSystem : ISavingSystem
    {
        private IEncryptionSystem encryptionSystem;

        public EncryptedTxtSavingSystem(IEncryptionSystem encryptionSystem)
        {
            this.encryptionSystem = encryptionSystem;
        }

        public T Load<T>(string fileName, params JsonConverter[] jsonConverters) where T : class
        {
            if (!File.Exists(fileName))
            {
                return null;
            }

            T data = null;
            using (StreamReader file = File.OpenText(fileName))
            {
                string _data = file.ReadToEnd();
                if (encryptionSystem.Decrypt(ref _data))
                {
                    data = JsonConvert.DeserializeObject<T>(_data, new JsonSerializerSettings
                    {
                        Converters = jsonConverters
                    });
                }
            }

            return data;
        }

        public void Save(string fileName, object data, params JsonConverter[] jsonConverters)
        {
            if (!Directory.Exists(Path.GetDirectoryName(fileName)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(fileName));
            }

            using (var file = File.Create(fileName))
            {
                string _json = JsonConvert.SerializeObject(data, new JsonSerializerSettings
                {
                    Converters = jsonConverters
                });
                _json = encryptionSystem.Encrypt(_json);
                byte[] _data = System.Text.Encoding.UTF8.GetBytes(_json);
                file.Write(_data, 0, _data.Length);
            }

            // Log.Print($"Data Saved: {fileName}", LogFilter.Data);
        }
    }
}
