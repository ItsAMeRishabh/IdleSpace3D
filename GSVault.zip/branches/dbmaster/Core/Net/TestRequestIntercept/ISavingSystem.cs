﻿using Newtonsoft.Json;

namespace GS.Data.Saving
{
    public interface ISavingSystem
    {
        void Save(string fileName, object data, params JsonConverter[] jsonConverters);
        T Load<T>(string fileName, params JsonConverter[] jsonConverters) where T : class;
    }
}