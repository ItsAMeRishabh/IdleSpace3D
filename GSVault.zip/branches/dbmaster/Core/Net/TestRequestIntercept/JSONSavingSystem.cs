﻿using Newtonsoft.Json;
using System.IO;

namespace GS.Data.Saving
{
    public class JSONSavingSystem : ISavingSystem
    {
        public T Load<T>(string fileName, params JsonConverter[] jsonConverters) where T : class
        {
            if (!File.Exists(fileName))
            {
                return null;
            }

            T data;
            using (StreamReader file = File.OpenText(fileName))
            {
                JsonSerializer serializer = new JsonSerializer();
                data = (T)serializer.Deserialize(file, typeof(T));
            }

            return data;
        }

        public void Save(string fileName, object data, params JsonConverter[] jsonConverters)
        {
            using (var file = File.CreateText(fileName))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, data);
            }

            Log.Print($"Data Saved: {fileName}", LogFilter.Data);
        }
    }
}
