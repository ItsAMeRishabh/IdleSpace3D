﻿using GS.Data.Encryption;
using GS.Data.Saving;
using GS.Net.Transactions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace GS.Net.Interceptor
{
    [System.Serializable]
    public class RequestInfo
    {
        public string url;
        public string data;
        public bool isPost;
        public string transactionID;
    }

    [System.Serializable]
    public class ProcessedTransaction
    {
        public string url;
        public string response;
        public string request;
        public DateTime saveDate;
    }

    public class RequestInterceptor<TPacketType> where TPacketType : Enum
    {
        private string savePath;
        private Queue<KeyValuePair<string, RequestInfo>> requestQueue;
        private ISavingSystem savingSystem;

        public RequestInterceptor(IEncryptionSystem encryptionSystem)
        {
            savingSystem = new EncryptedTxtSavingSystem(encryptionSystem);

            savePath = SavingSystemConfigSO.Instance.GetFulRequestFileName;

            requestQueue = savingSystem.Load<Queue<KeyValuePair<string, RequestInfo>>>(savePath);

            if (requestQueue == null)
            {
                requestQueue = new Queue<KeyValuePair<string, RequestInfo>>();
            }
            else
            {
                savingSystem.Save(savePath, requestQueue);
            }
        }

        public void PushToTop(string url, string transactionId, string data = "", bool isPost = false)
        {
            var transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            if (transaction.IsImportant || requestQueue.Count < SavingSystemConfigSO.Instance.requestQueueLength)
            {
                var requestList = requestQueue.ToList();
                requestList.Insert(0, new KeyValuePair<string, RequestInfo>(transactionId, new RequestInfo
                {
                    data = data,
                    url = url,
                    isPost = isPost,
                    transactionID = transactionId
                }));

                requestQueue = new Queue<KeyValuePair<string, RequestInfo>>(requestList);
            }

            SaveData();
        }

        public void EnqueueRequest(string url, string transactionId, string data = "", bool isPost = false)
        {
            var transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            if (transaction.IsImportant || requestQueue.Count < SavingSystemConfigSO.Instance.requestQueueLength)
            {
                requestQueue.Enqueue(new KeyValuePair<string, RequestInfo>(transactionId, new RequestInfo {
                    data = data,
                    url = url,
                    isPost = isPost,
                    transactionID = transactionId
                }));
            }

            SaveData();
        }

        public KeyValuePair<string, RequestInfo> GetAndRemoveRequest(string trancsactionID)
        {
            var convertedList = requestQueue.ToList();
            var returnRequest = convertedList.First(request => request.Key == trancsactionID);
            
            convertedList.Remove(returnRequest);
            requestQueue = new Queue<KeyValuePair<string, RequestInfo>>(convertedList);
            return returnRequest;
        }

        public KeyValuePair<string, RequestInfo> GetQueuedRequest()
        {
            var q = requestQueue.Dequeue();
            SaveData();
            return q;
        }

        public int Count
        {
            get => requestQueue.Count;
        }

        /// <summary>
        /// Saves the data into a local file.
        /// </summary>
        public void SaveData()
        {
            savingSystem.Save(savePath, requestQueue);
        }
    }

    public class SaveResponseEvent : GameEvent
    {
        public string transactionID;
        public string response;
        public string url;
        public string data;

        public SaveResponseEvent(string transactionID, string response, string url, string data)
        {
            this.transactionID = transactionID;
            this.response = response;
            this.url = url;
            this.data = data;
        }
    }


    public class ResponseInterceptor<TPacketType> where TPacketType : Enum
    {
        public static ResponseInterceptor<TPacketType> instance;
        
        private Dictionary<string, string> transactionHistory;
        private ISavingSystem savingSystem;
        private string savePath;

        public ResponseInterceptor(IEncryptionSystem encryptionSystem)
        {
            instance = this;

            EventManager.Instance.AddListener<SaveResponseEvent>(SaveResponse);

            savingSystem = new EncryptedTxtSavingSystem(encryptionSystem);

            savePath = Path.Combine(Application.persistentDataPath, SavingSystemConfigSO.Instance.responseFileName);

            // pull data from local
            transactionHistory = savingSystem.Load<Dictionary<string, string>>(savePath);
            if (transactionHistory == null)
            {
                transactionHistory = new Dictionary<string, string>();
            }
        }

        ~ResponseInterceptor()
        {
            EventManager.Instance.RemoveListener<SaveResponseEvent>(SaveResponse);
        }

        public void SaveResponse(SaveResponseEvent saveResponseEvent)
        {
            SaveResponse(saveResponseEvent.transactionID, saveResponseEvent.response, saveResponseEvent.url, saveResponseEvent.data);
        }

        public void SaveResponse(string transactionID, string response, string url, string data, bool saveLocal = true)
        {
            var transaction = BaseTransactionsHolder<TPacketType>.Get(transactionID);

            if (transactionHistory.ContainsKey(transactionID))
            {
                BaseResponseFetcher responseFetcher = (BaseResponseFetcher) JsonConvert.DeserializeObject(transactionHistory[transactionID], transaction.ResponseDefination.GetResponseFetcher());
                responseFetcher.SaveResponse(response, transactionID, data, url);
                transactionHistory[transactionID] = JsonConvert.SerializeObject(responseFetcher);
            }
            else
            {

                BaseResponseFetcher responseFetcher = (BaseResponseFetcher) Activator.CreateInstance(transaction.ResponseDefination.GetResponseFetcher());
                responseFetcher.SaveResponse(response, transactionID, data, url);
                transactionHistory.Add(transactionID, JsonConvert.SerializeObject(responseFetcher));
            }

            if (saveLocal)
            {
                //saving the data locally
                savingSystem.Save(savePath, transactionHistory);
            }
        }

        public void ForceSave()
        {
            savingSystem.Save(savePath, transactionHistory);
        }

        public string GetTransactionResponse(string transactionId, string url, string currentRequest = null)
        {
            IBaseTransaction targetTransaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);

            if (!targetTransaction.IsGeneratorOnly && transactionHistory.ContainsKey(transactionId))
            {
                var transactions = transactionHistory[transactionId];
                IResponseFetcher responseFetcher = (IResponseFetcher) JsonConvert.DeserializeObject(transactions, targetTransaction.ResponseDefination.GetResponseFetcher());
                return responseFetcher.GetResponse(transactionId, currentRequest, url);
            }
            else
            {
                IBaseResponseDefination currentResponse = targetTransaction.ResponseDefination.GetResponse(currentRequest);
                if (currentResponse == null)
                {
                    return null;
                }

                currentResponse.PacketType = targetTransaction.PacketType;
                return Newtonsoft.Json.JsonConvert.SerializeObject(currentResponse);
            }
        }
    }
}
