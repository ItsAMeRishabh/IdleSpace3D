﻿using WebSocketSharp;
using System;
using StompHelper;
using System.Collections.Generic;
using GS.GameEvents;

namespace GS.Net
{
    /// <summary>
    /// Web Socket Helper class Implementation 
    /// </summary>
    public class GSWebSocket : IWebSocket
    {

        #region private data types

        public class CallbackSet
        {
            public Action<string> callback;
            public string body;

            public CallbackSet(Action<string> callback, string body)
            {
                this.callback = callback;
                this.body = body;
            }
        }

        private Action<string> onOpenCallbacks, onCloseCallbacks, onErrorCallbacks, onMessageCallbacks;
        private WebSocket webSocket;

        private List<CallbackSet> callSets = new List<CallbackSet>();
        #endregion


        /// <summary>
        /// Call the method to register for socket callbacks based on event types
        /// Note :: This needs to be done before we create a websocket 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="action"></param>
        public void RegisterCallback(SocketCallbacks type, Action<string> action)
        {
            switch (type)
            {
                case SocketCallbacks.OnOpen:
                    onOpenCallbacks += action;
                    break;
                case SocketCallbacks.OnClose:
                    onCloseCallbacks += action;
                    break;
                case SocketCallbacks.OnMessage:
                    onMessageCallbacks += action;
                    break;
                case SocketCallbacks.OnError:
                    onErrorCallbacks += action;
                    break;
            }
        }

        /// <summary>
        /// Disconnects from the server
        /// </summary>
        public void Close()
        {
            if (webSocket != null && webSocket.IsAlive)
            {
                webSocket.Close();
            }
        }

        /// <summary>
        /// Creates a Web socket , registers events and establishes connection to server
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public bool Create(string url, string userID)
        {
            if (webSocket == null || !webSocket.IsAlive)
            {
                Log.Print("Creating Websocket : " + url, LogFilter.Network);
                webSocket = new WebSocket(url);

                RegisterWebEvents();
                webSocket.Connect();
            }

            return true;
        }

        //Action<bool> stompUpgrade = null;
        public void StompUpgrade(Dictionary<string, string> data, Action<bool> notification)
        {
            
        }

        /// <summary>
        /// Stomp Message
        /// </summary>
        /// <param name="command"></param>
        /// <param name="data"></param>
        /// <param name="StompUpgrade"></param>
        public void StompMessage(StompClientCommand command, Dictionary<string, string> data, string key = null, Action<string> callback = null)
        {
            if (!IsAlive())
                return;

            StompMessageSerializer serializer = new StompMessageSerializer();

            StompMessage msg = new StompMessage(command.ToString());

            if (data != null)
            {
                foreach(KeyValuePair<string, string> item in data)
                {
                    if (item.Key.Equals("Body"))
                    {
                        msg.SetBody(item.Value);
                    }
                    else 
                    {
                        msg[item.Key] = item.Value;
					}
                }
            }

            string sendData = serializer.Serialize(msg);

			webSocket.Send(sendData);

        }

        /// <summary>
        /// Registers Web Events with respect to the web socket
        /// </summary>
        private void RegisterWebEvents()
        {
            if (webSocket != null)
            {
                webSocket.OnOpen += OnOpen;
                webSocket.OnClose += OnClose;
                webSocket.OnError += OnError;
                webSocket.OnMessage += OnMessage;
            }
        }

        #region Web socket callbacks

        /// <summary>
        /// Callback after the connection is established
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnOpen(object sender, EventArgs e)
        {
			Utils.EventSync(new RunOnUnityMainThreadEvent(() =>
			{
				onOpenCallbacks(e.ToString()); // ("Success");
			}));			
        }

        /// <summary>
        /// Callback after the connection with the server is closed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnClose(object sender, CloseEventArgs e)
        {
			Utils.EventSync(new RunOnUnityMainThreadEvent(() =>
			{
				onCloseCallbacks(e.Reason);
			}));
        }

        /// <summary>
        /// Callback when any error is recieved
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnError(object sender, ErrorEventArgs e)
        {
			Utils.EventSync(new RunOnUnityMainThreadEvent(() =>
			{
				onErrorCallbacks(e.Message);
			}));			
        }

        /// <summary>
        /// The Message recieved from server
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnMessage(object sender, MessageEventArgs e)
        {
            Utils.EventSync(new RunOnUnityMainThreadEvent(() => 
            {
				onMessageCallbacks(e.Data);
			}));
        }
        #endregion

        /// <summary>
        /// Send Message to the server
        /// </summary>
        /// <param name="message"></param>
        public void SendMessage(string message)
        {
            if (webSocket != null && webSocket.IsAlive)
            {
                webSocket.Send(message);
            }
        }

        public bool IsAlive()
        {
            return webSocket.IsAlive;
        }

        public bool IsNull()
        {
            return webSocket == null;
        }

        public void Update()
        {
            if(callSets.Count > 0)
            {
                CallbackSet set = callSets[0];
                callSets.RemoveAt(0);
                set.callback(set.body);
            }
        }
    }
}
