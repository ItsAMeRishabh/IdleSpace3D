using UnityEngine;

namespace GS.Net.Interceptor
{
    public class RecentFetcher : BaseResponseFetcher
    {
        public string Data;

        public override string GetResponse(string transactionID, string request, string url)
        {
            return Data;
        }

        public override void SaveResponse(string response, string transactionID, string request, string url)
        {
            Data = response;
        }
    }
}
