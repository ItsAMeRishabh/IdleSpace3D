﻿using System;

namespace GS.Net
{
    /// <summary>
    /// Interface for engine specific web request class
    /// </summary>
    public interface IWebRequest
    {
        /// <summary>
        /// Downloads content from given URL.
        /// Returns progress of download and returns string in response
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>

        void Get(string url, string key, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback);
        
        /// <summary>
        /// Uploads a file
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        void Post(string url, string key, string data, Action<string, string, string> onDownloadCompletedCallback, Action<float> progressCallback);

        /// <summary>
        /// Updates a data
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        void Update(string url, string key, string data, Action<string, string, string> onDownloadCompletedCallback, Action<float> progressCallback);

        /// <summary>
        /// Downloads content from given URL.
        /// Returns progress of download and returns string in response
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        void Delete(string url, string key, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback);

        /// <summary>
        /// Download a file
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        void Download(string url, string key, string data, Action<string, byte[], string> onDownloadCompletedCallback, Action<float,string> progressCallback);
    }

}