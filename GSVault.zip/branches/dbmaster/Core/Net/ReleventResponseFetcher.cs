using GS.Net.Transactions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using Random = Unity.Mathematics.Random;

namespace GS.Net.Interceptor
{
    public class MatchResponse
    {
        public ProcessedTransaction response;
        public int score;
    }

    public class ReleventResponseFetcher<TPacketType> : BaseResponseFetcher
        where TPacketType : Enum
    {
        public List<ProcessedTransaction> transactions = new List<ProcessedTransaction>();
        private Random rand;

        public ReleventResponseFetcher()
        {
            rand = new Random();
            rand.InitState();
        }

        public override string GetResponse(string transactionID, string currentRequestData, string url)
        {
            var transaction = BaseTransactionsHolder<TPacketType>.Get(transactionID);

            transactions = transactions.OrderByDescending(t => t.saveDate).ToList();
            List<MatchResponse> matchScores = new List<MatchResponse>();
            int highMatchScore = -1;

            if (string.IsNullOrEmpty(currentRequestData))
            {
                var possibleTransactions = transactions.Where(transaction => transaction.url == url).ToList();

                return possibleTransactions[UnityEngine.Random.Range(0, possibleTransactions.Count)].response;
            }

            foreach (var localTransaction in transactions)
            {
                //Dictionary<string, RES> response = JsonConvert.DeserializeObject<Dictionary<string, RES>>(localTransaction.response);
                Dictionary<string, object> savedRequestDict = JsonConvert.DeserializeObject<Dictionary<string, object>>(localTransaction.request);
                Dictionary<string, object> currentRequestDict = JsonConvert.DeserializeObject<Dictionary<string, object>>(currentRequestData);

                bool isCrutialFlag = true;
                MatchResponse matchScore = new MatchResponse { response = localTransaction, score = -1 };

                foreach (var attribute in transaction.requestAttributes)
                {
                    if (attribute.isCrutial)
                    {
                        if (!UnityEngine.Object.Equals(savedRequestDict[attribute.name], currentRequestDict[attribute.name]))
                        {
                            isCrutialFlag = false;
                            break;
                        }
                    }
                    else
                    {
                        if (UnityEngine.Object.Equals(savedRequestDict[attribute.name], currentRequestDict[attribute.name]))
                        {
                            matchScore.score++;
                        }
                    }
                }

                if (isCrutialFlag)
                {
                    matchScores.Add(matchScore);

                    if (highMatchScore < matchScore.score)
                    {
                        highMatchScore = matchScore.score;
                    }
                }
            }

            if (matchScores.Count != 0)
            {
                var maxMatchedResponses = matchScores.Where(score => score.score == highMatchScore).ToList();

                if (maxMatchedResponses.Count != 0)
                {
                    //if (maxMatchedResponses.Count == 1)
                    //{
                    //    return maxMatchedResponses[0].response.response;
                    //}

                    var randMatchedResponse = maxMatchedResponses[rand.NextInt(0, maxMatchedResponses.Count)];

                    return randMatchedResponse.response.response;
                }
            }

            return JsonConvert.SerializeObject(transaction.ResponseDefination.GetResponse(currentRequestData));
        }

        public override void SaveResponse(string response, string transactionID, string request, string url)
        {
            var transaction = BaseTransactionsHolder<TPacketType>.Get(transactionID);
            transactions.Add(new ProcessedTransaction { response = response, request = request, url = url, saveDate = DateTime.UtcNow });

            if (transactions.Count > transaction.ResponseHistoryLength)
            {
                transactions.RemoveAt(0);
            }
        }
    }
}
