﻿using GS.Net.Interceptor;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;

namespace GS.Net.Transactions
{
    /// <summary>
    /// Interface for Generalizing DefaultResponses
    /// </summary>
    public interface IBaseResponeOperatorDefination
    {
        IBaseResponseDefination GetResponse(string request);
        ProcessedTransaction GetRecentTransaction(List<ProcessedTransaction> transactions);
        Type GetResponseFetcher();
    }

    [System.Serializable]
    public abstract class BaseResponseOperatorDefination<T, U> : ScriptableObject, IBaseResponeOperatorDefination where T : IBaseResponeOperatorDefination where U : IBaseResponseDefination, new ()
    {
        public List<U> defaultResponses;

        #region Data Generator Method

        protected virtual BaseDataGenerator<U> DataGenerator => new BaseDataGenerator<U>();
        public List<string> methodNames => DataGenerator.methodRegistry.Select(d => d.Key).ToList();

        [MethodPicker] public string targetMethod = "None"; 
        [FetcherPicker] public string targetFetcher = "GS.Net.Interceptor.ReleventResponseFetcher";

        #endregion

        public Type GetFetcherType()
        {
            return FetcherHolder.GetType(targetFetcher);
        }

        public ProcessedTransaction GetRecentTransaction(List<ProcessedTransaction> transactions)
        {
            return transactions.OrderByDescending(t => t.saveDate).FirstOrDefault();
        }

        public IBaseResponseDefination GetResponse(string request)
        {
            if(targetMethod == "None")
            {
                if (defaultResponses.Count == 0)
                {
                    return null;
                }

                System.Random rand = new System.Random();
                int idx = rand.Next(0, defaultResponses.Count - 1);
                return defaultResponses[idx];
            }

            return DataGenerator.methodRegistry[targetMethod](request);
        }

        public Type GetResponseFetcher()
        {
            return FetcherHolder.GetType(targetFetcher);
        }
    }

    [System.Serializable] public class ResponseOperatorEvent : UnityEvent<IBaseResponseDefination> { }
}