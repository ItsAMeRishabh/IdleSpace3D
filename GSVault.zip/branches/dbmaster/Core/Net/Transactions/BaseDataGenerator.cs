﻿using GS.Net.Transactions;
using System;
using System.Collections.Generic;

namespace GS.Net.Transactions
{
    public interface IGenerator
    {
        Dictionary<string, Func<string, IBaseResponseDefination>> methodRegistry { get; }
    }

    [System.Serializable]
    public class BaseDataGenerator<T> : IGenerator where T : IBaseResponseDefination, new()
    {
        public virtual Dictionary<string, Func<string, IBaseResponseDefination>> methodRegistry => new Dictionary<string, Func<string, IBaseResponseDefination>>() { { nameof(Excute), Excute } };

        public virtual IBaseResponseDefination Excute(string request)
        {
            return new T();
        }
    }
}
