﻿namespace GS.Net.Transactions
{
    [System.Serializable]
    public struct RequestAttribute
    {
        [ReadOnly] public string name;
        [ReadOnly] public string assemblyQualifiedName;
        public bool isCrutial;

        public object GetValue(string data)
        {
            Newtonsoft.Json.Linq.JObject jboject = Newtonsoft.Json.Linq.JObject.Parse(data);
            return jboject[name].ToObject(System.Type.GetType(assemblyQualifiedName));
        }

        public object GetValue(Newtonsoft.Json.Linq.JObject jboject)
        {
            return jboject[name].ToObject(System.Type.GetType(assemblyQualifiedName));
        }
    }
}