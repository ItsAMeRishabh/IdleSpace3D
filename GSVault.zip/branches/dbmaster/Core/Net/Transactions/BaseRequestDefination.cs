﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace GS.Net.Transactions
{
    /// <summary>
    /// Interface for Generalizing RequestDefinations
    /// </summary>
    public interface IBaseRequestDefination
    {
        /// <summary>
        /// Variable collection of inherited class.
        /// </summary>
        /// 
        string UserId { get; set; }
        int PacketType { get; }
        int PacketCounterId { get; }
        int BuildVersion { get; set; }
        List<string> variableNames { get; }
        DateTime TimeStamp { get; set; }
        bool IsOffline { get; set; }
    }

    [System.Serializable]
    public abstract class BaseRequestDefination<T> : IBaseRequestDefination where T : IBaseRequestDefination
    {
        public string userId = "";
        public int packetType;
        public int packetCounterId;
        public int buildVersion;
        public long timeStamp;
        public bool isOffline;

        [JsonIgnore] public string className => typeof(T).Name;
        [JsonIgnore] public virtual List<string> variableNames => new List<string>();
        [JsonIgnore]
        public string UserId 
        { 
            get => userId;
            set => userId = value;
        }
        [JsonIgnore]
        public int BuildVersion 
        { 
            get => buildVersion; 
            set => buildVersion = value;
        }

        [JsonIgnore] int IBaseRequestDefination.PacketType => packetType;

        [JsonIgnore] int IBaseRequestDefination.PacketCounterId => packetCounterId;

        [JsonIgnore]
        public DateTime TimeStamp
        {
            get
            {
                DateTimeOffset resultOffset = DateTimeOffset.FromUnixTimeMilliseconds(timeStamp);
                return resultOffset.UtcDateTime;
            }
            set
            {
                DateTimeOffset dateTimeOffset = new DateTimeOffset(value);
                timeStamp = dateTimeOffset.ToUnixTimeMilliseconds();
            }
        }

        [JsonIgnore]
        public bool IsOffline
        {
            get => isOffline;
            set => isOffline = value;
        }
    }
}