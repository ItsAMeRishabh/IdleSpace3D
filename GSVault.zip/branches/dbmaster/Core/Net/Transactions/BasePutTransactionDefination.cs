﻿using GS.Net.Interceptor;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GS.Net.Transactions
{
    [System.Serializable]
    public class BasePutTransactionDefination<REQ, RES, ROD, TD, PT> : ScriptableObject, IBaseTransaction 
        where REQ : IBaseRequestDefination, new() 
        where RES : IBaseResponseDefination, new() 
        where ROD : ScriptableObject, IBaseResponeOperatorDefination, new() 
        where TD : ScriptableObject, IBaseTransaction, new()
        where PT : struct, System.Enum
    {
        [ReadOnly] public string transactionID;
        public string path;
        public ROD responseOperator;
        public bool canAutomate = true;
        public bool isQueueable;
        public bool isImportant;
        public bool isStackable;
        public bool isGeneratorOnly = false;
        public ResponseDelay responseDelayConfig;
        public int responseHistoryLength = 10;
        public float requestTimeoutTimer = -1;

        public string Path => path;
        public System.Type RequestType => typeof(REQ);
        public System.Type ResponseType => typeof(RES);
        public bool CanAutomate { get => canAutomate; }
        public bool IsImportant { get => isImportant; }
        public bool IsQueueable { get => isQueueable; }
        public bool IsStackable { get => isStackable; }
        public int ResponseHistoryLength { get => responseHistoryLength; }
        public bool IsGeneratorOnly => isGeneratorOnly;
        public string TransactionID { get => transactionID; set => transactionID = value; }
        public int PacketType
        {
            get
            {
                if (System.Enum.TryParse<PT>(TransactionID, out PT gamePacketType))
                {
                    return System.Convert.ToInt32(gamePacketType);
                }

                return 0;
            }
        }

        public IBaseResponeOperatorDefination ResponseDefination { get => responseOperator; }

        /// <summary>
        /// List of variable attributes [Caution : Never manually manipulate the size of this list as it is auto populated]
        /// </summary>
        [Tooltip("List of variable attributes [Caution : Never manually manipulate the size of this list as it is auto populated]"), Space] public List<RequestAttribute> attributes;
        public List<RequestAttribute> requestAttributes => attributes;

        public float RequestTimeoutTimer => requestTimeoutTimer;

        [Button(nameof(Refresh_Attributes))] public string validate;

        public virtual void Refresh_Attributes()
        {
            #if UNITY_EDITOR
                attributes = new List<RequestAttribute>();
                System.Reflection.BindingFlags bindingAtr = System.Reflection.BindingFlags.DeclaredOnly | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public;

                foreach (System.Reflection.FieldInfo field in typeof(REQ).GetFields(bindingAtr))
                {
                    var newAttribute = new RequestAttribute()
                    {
                        name = field.Name,
                        assemblyQualifiedName = field.FieldType.AssemblyQualifiedName,
                    };

                    attributes.Add(newAttribute);
                }
            #endif
        }

        public void SelfBind(ref Dictionary<System.Type, IBaseTransaction> transactionsTable, ref Dictionary<string, System.Type> transactionsTypeTable)
        {
            try
            {
                transactionsTypeTable.Add(transactionID, typeof(TD));
                transactionsTable.Add(typeof(TD), this);
            }
            catch (System.Exception e)
            {
                Log.Error($"{e.Message} - {transactionID}");
            }
        }

        public void SelfUnBind<T>(ref Dictionary<System.Type, IBaseTransaction> transactionsTable) where T : IBaseTransaction
        {
            transactionsTable.Remove(typeof(T));
        }

        public void GenerateResponseOperator(string path)
        {
#if UNITY_EDITOR
            var asset = CreateInstance<ROD>();
            responseOperator = asset;
            UnityEditor.AssetDatabase.CreateAsset(asset, path + typeof(ROD).Name + ".asset");
#endif
        }

        //private class MatchResponse
        //{
        //    public ProcessedTransaction response;
        //    public int score;
        //}
    }
}