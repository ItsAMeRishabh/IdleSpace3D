﻿using System.Collections.Generic;

namespace GS.Net.Transactions
{
    public interface IBaseTransaction
    {
        string TransactionID { get; set; }
        string Path { get; }
        System.Type RequestType { get; }
        System.Type ResponseType { get; }
        List<RequestAttribute> requestAttributes { get; }
        int PacketType { get; }
        bool CanAutomate { get; }
        bool IsQueueable { get; }
        bool IsImportant { get; }
        bool IsStackable { get; }
        bool IsGeneratorOnly { get; }
        int ResponseHistoryLength { get; }
        float RequestTimeoutTimer { get; }
        IBaseResponeOperatorDefination ResponseDefination { get; }
        void SelfBind(ref Dictionary<System.Type, IBaseTransaction> transactionsTable, ref Dictionary<string, System.Type> transactionsTypeTable);
        void SelfUnBind<T>(ref Dictionary<System.Type, IBaseTransaction> transactionsTable) where T : IBaseTransaction;
        void GenerateResponseOperator(string path);
        void Refresh_Attributes();
    }

    [System.Serializable]
    public struct ResponseDelay
    {
        public float delay;
        public float delayOffset;

        public float GetRandomDelay()
        {
            return UnityEngine.Random.Range(delay, delay + delayOffset);
        }
    }
}