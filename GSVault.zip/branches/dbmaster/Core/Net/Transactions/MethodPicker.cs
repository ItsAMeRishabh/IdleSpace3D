﻿using UnityEngine;

namespace GS.Net.Transactions
{
    public class MethodPicker : PropertyAttribute
    {
        public MethodPicker()
        {

        }
    }
}
