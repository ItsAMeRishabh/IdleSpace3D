﻿using UnityEngine;

namespace GS.Net.Transactions
{
    public class BaseDataGeneratorDefination<T> : ScriptableObject where T : class, IBaseResponseDefination
    {
        public virtual void GetValue(IBaseResponseDefination refObj)
        {

        }

        protected T GetTypecastedValue(IBaseResponseDefination refObj)
        {
            return (refObj as T);
        }
    };
}