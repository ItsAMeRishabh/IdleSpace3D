﻿using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace GS.Net.Transactions
{
    [CustomPropertyDrawer(typeof(MethodPicker))]
    public class MethodPickerDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            UnityEngine.Object target = property.serializedObject.targetObject;
            System.Type type = target.GetType();
            System.Reflection.PropertyInfo memberProperty = type.GetProperty("methodNames");

            List<string> names = (List<string>)memberProperty.GetValue(target);
            names.Add("None");
            List<string> stringListnames = names;
            int hightLightedIndex = Mathf.Max(Array.IndexOf(stringListnames.ToArray(), property.stringValue), 0);
            property.stringValue = stringListnames[EditorGUI.Popup(position, property.name, hightLightedIndex, stringListnames.ToArray())];
        }
    }
}