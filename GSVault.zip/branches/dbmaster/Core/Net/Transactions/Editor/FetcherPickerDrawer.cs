using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace GS.Net.Transactions
{
    [CustomPropertyDrawer(typeof(FetcherPicker))]
    public class FetcherPickerDrawer : PropertyDrawer
    {
        public static List<string> names = null;

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (names == null)
            {
                FetcherHolder.GetFetcherList(names =>
                {
                    FetcherPickerDrawer.names = names;
                });
                EditorGUI.PropertyField(position, property, label);
            }
            else
            {
                List<string> stringListnames = names;
                int hightLightedIndex = Mathf.Max(
                    Array.IndexOf(stringListnames.ToArray(), property.stringValue),
                    0
                );
                property.stringValue = stringListnames[
                    EditorGUI.Popup(
                        position,
                        property.name,
                        hightLightedIndex,
                        stringListnames.ToArray()
                    )
                ];
            }
        }
    }
}
