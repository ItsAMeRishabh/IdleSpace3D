﻿using UnityEditor;
using UnityEngine;

namespace GS
{
    [CustomPropertyDrawer(typeof(ButtonAttribute))]
    public class ButtonDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            ButtonAttribute buttonAttribute = attribute as ButtonAttribute;
            string methodName = buttonAttribute.MethodName;
            System.Object target = property.GetParent();
            System.Type type = target.GetType();
            System.Reflection.MethodInfo method = type.GetMethod(methodName);
            
            if (method == null)
            {
                target = property.serializedObject.targetObject;
                target = target.GetType();
                method = type.GetMethod(methodName);
            }

            if (method == null)
            {
                GUI.Label(position, "Method could not be found. Is it public?");
                return;
            }

            if (method.GetParameters().Length > 0)
            {
                GUI.Label(position, "Method cannot have parameters.");
                return;
            }

            if (GUI.Button(position, method.Name))
            {
                method.Invoke(target, null);
            }
        }
    }
}