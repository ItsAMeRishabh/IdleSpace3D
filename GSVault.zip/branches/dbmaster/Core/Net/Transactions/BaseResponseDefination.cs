﻿using GS.Net.Interceptor;
using System.Collections.Generic;
using System.Linq;

namespace GS.Net.Transactions
{
    /// <summary>
    /// Interface for Generalizing ResponeDefinations
    /// </summary>
    public interface IBaseResponseDefination
    {
        ResponseStatus Status { get; }
        int PacketType { get; set; }
        string Message { get; }
        bool HasResponseSucceeded { get; }
        bool IsCached { get; set; }
    }

    [System.Serializable]
    public abstract class BaseResponseDefination<T> : IBaseResponseDefination where T : IBaseResponseDefination
    {
        public ResponseStatus status;
        public int packetType;
        public int packetCounterId;
        public string message;
        public bool isCached = false;

        public bool IsCached
        {
            get => isCached;
            set { isCached = value; }
        }

        public ResponseStatus Status => status;
        public int PacketType
        {
            get => packetType;
            set { packetType = value; }
        }
        public string Message => message;
        public bool HasResponseSucceeded => Status == ResponseStatus.Success;
    }

    public enum ResponseStatus
    {
        Success, 
        Failed,
        TimeOut,
        InvalidFormat,
        UnAuthorized,
        NotSupportedVersion
    }
}