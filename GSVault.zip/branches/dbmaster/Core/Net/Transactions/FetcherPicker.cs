using UnityEngine;

namespace GS.Net.Transactions
{
    public class FetcherPicker : PropertyAttribute
    {
        public FetcherPicker()
        {

        }
    }
}
