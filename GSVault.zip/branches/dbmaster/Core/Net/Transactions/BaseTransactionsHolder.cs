﻿using GS.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GS.Net.Transactions
{
    public class BaseTransactionsHolder<E> : ScriptableObject
        where E : Enum
    {
        public string definationsStoragePath =
            "Assets/MusicTrack/Scripts/Common/Transactions/Transactions/TransactionObjects/Objects/";
        public string operatorDefinationsStoragePath =
            "Assets/MusicTrack/Scripts/Common/Transactions/Transactions/TransactionObjects/ResponseOperators/";
        public List<ScriptableObject> transactionsObjects = new List<ScriptableObject>();
        public static Dictionary<Type, IBaseTransaction> transactionsTable;
        public static Dictionary<string, Type> transactionTypeTable;
        public static Dictionary<Type, IBaseTransaction> TransactionsTable => transactionsTable;

        public static void Initialize()
        {
#if USE_ADDRESSABLES
            Utils.EventSync(
                new LoadScriptableObjectEvent(
                    string.Empty,
                    "TransactionHolder",
                    config =>
                    {
                        BaseTransactionsHolder<E> transactionsHolder =
                            (BaseTransactionsHolder<E>)config;
                        transactionsHolder.ValidateRegistry();

                        FetcherHolder.Initialize();

                        Log.Print("Transaction Holder Loaded", LogFilter.Game);
                    }
                )
            );
#else
            Resources
                .Load<BaseTransactionsHolder<E>>(nameof(BaseTransactionsHolder<E>))
                .ValidateRegistry();
            FetcherHolder.Initialize();
            Log.Print("Transaction Holder Loaded", LogFilter.Game);
#endif
        }

        [ContextMenu("Validate")]
        public virtual void ValidateRegistry()
        {
            Log.Print(nameof(BaseTransactionsHolder<E>), LogFilter.Network);

            transactionsTable = new Dictionary<Type, IBaseTransaction>();
            transactionTypeTable = new Dictionary<string, Type>();
            foreach (var item in transactionsObjects)
            {
                ((IBaseTransaction)item).SelfBind(ref transactionsTable, ref transactionTypeTable);
            }
        }

        [ContextMenu("Update")]
        public virtual void UpdateTransactionIDs()
        {
#if UNITY_EDITOR
            foreach (int i in Enum.GetValues(typeof(E)))
            {
                string name = Enum.ToObject(typeof(E), i).ToString() + "Transaction";
                var transactionConfig = transactionsObjects
                    .Where(t => t.name.Equals(name))
                    .FirstOrDefault();
                if (transactionConfig == null)
                {
                    continue;
                }
                ((IBaseTransaction)transactionConfig).TransactionID = Enum.ToObject(typeof(E), i)
                    .ToString();
                UnityEditor.EditorUtility.SetDirty(transactionConfig);
            }
            UnityEditor.AssetDatabase.SaveAssets();
#endif
        }

        public static Z Get<Z>()
            where Z : class, IBaseTransaction
        {
            IBaseTransaction result;
            if (TransactionsTable.TryGetValue(typeof(Z), out result))
            {
                return result as Z;
            }

            return null;
        }

        public static IBaseTransaction Get(string packetType)
        {
            IBaseTransaction result = null;
            if (transactionTypeTable != null && !transactionTypeTable.ContainsKey(packetType))
            {
                Log.Print(packetType, LogFilter.Network);
            }

            if (TransactionsTable.TryGetValue(transactionTypeTable[packetType], out result))
            {
                return result;
            }

            return null;
        }

        [ContextMenu("Populate")]
        public virtual void Populate()
        {
#if UNITY_EDITOR
            var type = typeof(IBaseTransaction);
            var types = AppDomain.CurrentDomain
                .GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .Where(p => type.IsAssignableFrom(p) && p.IsClass && !p.IsGenericType)
                .ToList();

            Dictionary<string, ScriptableObject> lookup = transactionsObjects.ToDictionary(
                p => p.name,
                p => p
            );

            foreach (var item in types)
            {
                if (!lookup.ContainsKey(item.FullName))
                {
                    var asset = CreateInstance(item);
                    ((IBaseTransaction)asset).GenerateResponseOperator(
                        operatorDefinationsStoragePath
                    );
                    ((IBaseTransaction)asset).Refresh_Attributes();
                    UnityEditor.AssetDatabase.CreateAsset(
                        asset,
                        definationsStoragePath + item.FullName + ".asset"
                    );
                    transactionsObjects.Add(asset);
                }
            }
            UnityEditor.AssetDatabase.SaveAssets();
            UpdateTransactionIDs();
#endif
        }
    }
}
