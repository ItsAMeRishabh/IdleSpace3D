﻿using GS.Net.Interceptor;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GS.Net.Transactions
{
    [System.Serializable]
    public class BaseDeleteTransactionDefination<RES, ROD, TD, PT> : ScriptableObject, IBaseTransaction
        where RES : IBaseResponseDefination, new()
        where ROD : ScriptableObject, IBaseResponeOperatorDefination, new()
        where TD : ScriptableObject, IBaseTransaction, new()
        where PT : struct, System.Enum
    {
        public string transactionID;
        public string path;
        public ROD responseOperator;
        public bool canAutomate = true;
        public ResponseDelay responseDelayConfig;
        public int responseHistoryLength = 10;
        public bool isGeneratorOnly = false;
        public float requestTimeoutTimer;

        public string Path => path;
        public System.Type RequestType => typeof(string);
        public System.Type ResponseType => typeof(RES);

        public bool CanAutomate { get => canAutomate; }
        public bool IsImportant => false;
        public bool IsQueueable => false;
        public bool IsStackable => false;
        public bool IsGeneratorOnly => isGeneratorOnly;
        public int PacketType
        {
            get
            {
                if (System.Enum.TryParse<PT>(TransactionID, out PT gamePacketType))
                {
                    return System.Convert.ToInt32(gamePacketType);
                }

                return 0;
            }
        }

        public string TransactionID { get => transactionID; set => transactionID = value; }
        public int ResponseHistoryLength { get => responseHistoryLength; }
        public IBaseResponeOperatorDefination ResponseDefination { get => responseOperator; }
        public List<RequestAttribute> requestAttributes => new List<RequestAttribute>();

        public float RequestTimeoutTimer => requestTimeoutTimer;

        public void GenerateResponseOperator(string path)
        {
#if UNITY_EDITOR
            var asset = CreateInstance<ROD>();
            responseOperator = asset;
            UnityEditor.AssetDatabase.CreateAsset(asset, path + typeof(ROD).Name + ".asset");
#endif
        }

        public void SelfBind(ref Dictionary<System.Type, IBaseTransaction> transactionsTable, ref Dictionary<string, System.Type> transactionsTypeTable)
        {
            try
            {
                transactionsTypeTable.Add(transactionID, typeof(TD));
                transactionsTable.Add(typeof(TD), this);
            }
            catch (System.Exception e)
            {
                Log.Error(e.Message);
            }
        }

        public void SelfUnBind<T>(ref Dictionary<System.Type, IBaseTransaction> transactionsTable) where T : IBaseTransaction
        {
            transactionsTable.Remove(typeof(T));
        }

        public void Refresh_Attributes() { }
    }
}
