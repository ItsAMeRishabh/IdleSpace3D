using GS.Net.Transactions;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Net.Interceptor
{
    public interface IResponseFetcher
    {
        string GetResponse(string transactionID, string request, string url);
        void SaveResponse(string response, string transactionID, string request, string url);
    }

    public abstract class BaseResponseFetcher : IResponseFetcher
    {
        public abstract string GetResponse(string transactionID, string request, string url);
        public abstract void SaveResponse(string response, string transactionID, string request, string url);
    }
}
