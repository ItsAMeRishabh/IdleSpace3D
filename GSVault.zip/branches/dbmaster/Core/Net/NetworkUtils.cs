﻿using GS;
using GS.Data.Encryption;
using GS.Net;
using GS.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityWebRequest = UnityEngine.Networking.UnityWebRequest;

public abstract class NetworkUtils : SingleTon<NetworkUtils>
{
    public static string OfflineReadyTxt = "OfflineReady";
    public const string LASTONLINEKEY = "Last Seen Online";

    [SerializeField]
    private float connectTimeCountdownMax = 5;
    private static bool isConnected = true;
    private static bool previousConnected = true;
    public static bool AllowForceCheck = false;
    private static bool stopCheck = false;
    private static DateTime globaltimer;
    public static DateTime lastLoginTime { get; private set; }

    //public abstract IEncryptionSystem apiEncryption = new APIEncryption(
    //    () => SavingSystemConfigSO.Instance.offlineModeEncryptionKey
    //);
    public abstract IEncryptionSystem apiEncryption { get; }

    public static Action NetworkConnectionStatus;
    public static Action OnGlobalTimeFetched;
    public static bool IsSendingOfflineData = false;
    public static Action<bool> OnSendingOfflineChanged;
    public static bool IsBackBlocked = false;
    public static bool isTimeFromOffline = false;
    public string runtimeConnectionTesterLink { private get; set; }

    /// <summary>
    /// Returns the last time the player was online
    /// </summary>
    public static DateTime LastOnline
    {
        get
        {
            string value = PlayerPrefs.GetString(LASTONLINEKEY, "");
            if (string.IsNullOrEmpty(value))
            {
                return DateTime.UtcNow;
            }

            if (DateTime.TryParse(value, out DateTime time))
            {
                return time;
            }

            return DateTime.UtcNow;
        }
        set { PlayerPrefs.SetString(LASTONLINEKEY, value.ToString()); }
    }

    public string ConnectionTesterLink
    {
        get
        {
            if (!string.IsNullOrEmpty(runtimeConnectionTesterLink))
            {
                return runtimeConnectionTesterLink;
            }

            return SavingSystemConfigSO.Instance.connectionTesterLink;
        }
    }

    public static bool OfflineReady
    {
        get => PlayerPrefs.GetInt(OfflineReadyTxt, 0) != 0;
        set => PlayerPrefs.SetInt(OfflineReadyTxt, value ? 1 : 0);
    }

    public static bool IsConnected
    {
        get
        {
            if (routine == null)
            {
                Instance.CheckInternetConnection(isConnected);
            }
            return isConnected;
        }
        set { isConnected = value; }
    }

    public static bool StopCheck
    {
        get => stopCheck;
        set
        {
            stopCheck = value;
            if (!stopCheck && !IsConnected)
            {
                Instance.CheckInternetConnection(isConnected);
            }
        }
    }

    public static bool IsGlobalTimeFetched;

    public static DateTime Getglobaltime
    {
        get
        {
            DateTime Newdatetime = globaltimer.AddSeconds(Time.realtimeSinceStartup);
            return Newdatetime;
        }
    }

    static Coroutine routine = null;
    public static DateTime lastCheckedOnline;
    private SyncingPanel syncingPanel = null;

    private void Awake()
    {
        IsGlobalTimeFetched = false;
        globaltimer = DateTime.UtcNow;
    }

    private IEnumerator Start()
    {
        DoNotDestroyOnLoad = true;
#if USE_ADDRESSABLES
        AddressableHandler.Instantiate(
            "SyncingCanvas",
            null,
            gameobject =>
            {
                syncingPanel = gameobject.GetComponent<SyncingPanel>();
                syncingPanel.Init();
            }
        );
#else
        syncingPanel = Instantiate(Resources.Load<SyncingPanel>("SyncingCanvas"));
        syncingPanel.Init();
#endif
        lastCheckedOnline = LastOnline;
        yield return CheckNetworkAvailability();
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
    }

    public void CheckInternetConnection(bool isConnected = true)
    {
        NetworkUtils.isConnected = isConnected;
        if (!isConnected)
        {
            if (routine == null)
            {
                routine = StartCoroutine(CheckNetworkAvailability());
            }
            else
            {
                StartCoroutine(ForceCheckInternet());
            }
        }
    }

    public void OnApplicationFocus(bool focus)
    {
        StartCoroutine(ForceCheckInternet());
    }

    public IEnumerator GetGlobalTime()
    {
        UnityWebRequest request = UnityWebRequest.Get(ConnectionTesterLink);
        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            DateTime requestHeaderTime = DateTime.Parse(request.GetResponseHeader("Date"));
;
            string time = request.downloadHandler.text;
            if (apiEncryption.Decrypt(ref time))
            {
                globaltimer = DateTimeUtils.UnixTimeStampToDateTime(Convert.ToDouble(time));
            }
            else
            {
                globaltimer = requestHeaderTime;
            }
            Log.Print($"Server Time: {time}", LogFilter.Network);
            Log.Print($"Header Time: {requestHeaderTime.ToUniversalTime()}", LogFilter.Network);
            Log.Print($"Global Time: {globaltimer.ToUniversalTime()}", LogFilter.Network);

            if (requestHeaderTime.RoundToSecond() != globaltimer.RoundToSecond())
            {
                long ht = requestHeaderTime.RoundToSecond().ToTimeStamp();
                long gt = globaltimer.RoundToSecond().ToTimeStamp();

                Log.Print($"Server Time is not matching {ht - gt}", LogFilter.Error);
            }

            isTimeFromOffline = false;
            IsGlobalTimeFetched = true;
            OnGlobalTimeFetched?.Invoke();
        }
        else
        {
            globaltimer = DateTime.Now;
            IsGlobalTimeFetched = true;
            isTimeFromOffline = true;
            OnGlobalTimeFetched?.Invoke();
            Log.Print($"local Time: {globaltimer}", LogFilter.Network);
        }
        // StopAllCoroutines();
    }

    public IEnumerator CheckNetworkAvailability(Action callback = null)
    {
        //Debug.Log("Checking Net");
        do
        {
            if (StopCheck)
            {
                break;
            }

            if (!IsGlobalTimeFetched)
            {
                yield return GetGlobalTime();
            }

            yield return ForceCheckInternet(callback);
            yield return new WaitForSeconds(connectTimeCountdownMax);

            yield return null;
        } while (!IsConnected);

        routine = null;
    }

    public static IEnumerator WaitUntilSyncComplete(IEnumerator enumerator)
    {
        yield return new WaitUntil(() => !SyncingPanel.isSyncing);
        yield return enumerator;
    }

    public IEnumerator ForceCheckInternet(Action callback = null)
    {
        if (!AllowForceCheck && isConnected)
        {
            callback?.Invoke();
            yield break;
        }

        UnityWebRequest request = UnityWebRequest.Get(ConnectionTesterLink);
        yield return request.SendWebRequest();
        isConnected = request.result != UnityWebRequest.Result.ConnectionError;

        string body = request.downloadHandler.text;
        if (isConnected && !string.IsNullOrEmpty(body) && apiEncryption.Decrypt(ref body))
        {
            long resultLong;
            if (long.TryParse(body, out resultLong))
            {
                DateTimeOffset resultOffset = DateTimeOffset.FromUnixTimeMilliseconds(resultLong);
                lastCheckedOnline = resultOffset.UtcDateTime;
            }
        }

        if (previousConnected != isConnected)
        {
            NetworkConnectionStatus?.Invoke();
            previousConnected = isConnected;
        }

        if (callback != null)
        {
            callback.Invoke();
        }

    }
}
