using GS.Data;
using GS.Net.Interceptor;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GS.Net.Transactions
{
    [CreateAssetMenu()]
    public class FetcherHolder : ScriptableObject
    {
        public List<FetcherData> data = new List<FetcherData>();
        private static Dictionary<string, Type> registory = null;

        public static Dictionary<string, Type> Registory
        {
            get
            {
                if (registory == null)
                {
#if USE_ADDRESSABLES
                    Utils.EventSync(
                        new LoadScriptableObjectEvent(
                            string.Empty,
                            "FetcherHolder",
                            config =>
                            {
                                ((FetcherHolder)config).Refresh();
                            }
                        )
                    );
#else
                    Resources.Load<FetcherHolder>("FetcherHolder").Refresh();
#endif
                }

                return registory;
            }
        }

        public static void Initialize(Action action = null)
        {
#if USE_ADDRESSABLES
            AddressableHandler.LoadAsset<FetcherHolder>(
                "FetcherHolder",
                config =>
                {
                    config.Refresh();
                    action?.Invoke();
                }
            );
#else
            Resources.Load<FetcherHolder>("FetcherHolder").Refresh();
#endif
        }

        public static Type GetType(string name)
        {
            if (Registory.ContainsKey(name))
            {
                return Registory[name];
            }

            return null;
        }

        [ContextMenu("Refresh")]
        private void Refresh()
        {
            registory = new Dictionary<string, Type>();
            foreach (var ele in data)
            {
                registory.Add(ele.FetcherID, JsonConvert.DeserializeObject<Type>(ele.FetcherType));
            }
        }

        public static void GetFetcherList(Action<List<string>> callback)
        {
            Initialize(() =>
            {
                callback?.Invoke(Registory.Keys.ToList());
            });
        }

        [ContextMenu("UpdateList")]
        public void UpdateList()
        {
#if UNITY_EDITOR
            var type = typeof(BaseResponseFetcher);
            var types = AppDomain.CurrentDomain
                .GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .Where(p => type.IsAssignableFrom(p) && p.FullName != type.FullName)
                .ToList();

            data.Clear();
            foreach (var fetcherType in types)
            {
                data.Add(
                    new FetcherData
                    {
                        FetcherID = fetcherType.FullName,
                        FetcherType = JsonConvert.SerializeObject(fetcherType)
                    }
                );
            }

            UnityEditor.EditorUtility.SetDirty(this);
#endif
        }
    }

    [System.Serializable]
    public class FetcherData
    {
        [ReadOnly]
        public string FetcherID;

        [ReadOnly]
        public string FetcherType;
    }
}
