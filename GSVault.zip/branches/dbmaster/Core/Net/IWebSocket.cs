﻿using System;

namespace GS.Net
{
    /// <summary>
    ///  Socket call back types
    /// </summary>
    public enum SocketCallbacks
    {
        OnOpen, OnClose, OnError, OnMessage
    }

    /// <summary>
    /// Interface for all Websocket type classes
    /// </summary>
    public interface IWebSocket
    {
        /// <summary>
        /// Create websocket here
        /// </summary>
        /// <param name="url"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        bool Create(string url, string userID);

        /// <summary>
        /// Close websocket here
        /// </summary>
        void Close();

        /// <summary>
        /// Send Message using websocket instance 
        /// </summary>
        /// <param name="message"></param>
        void SendMessage(string message);

        /// <summary>
        /// Register your websocket callback with corresponding type
        /// </summary>
        /// <param name="type"></param>
        /// <param name="action"></param>
        void RegisterCallback(SocketCallbacks type, Action<string> action);

        /// <summary>
        /// Is Websocket alive or not
        /// </summary>
        /// <returns></returns>
        bool IsAlive();

        /// <summary>
        /// Is websocket instance is created or not
        /// </summary>
        /// <returns></returns>
        bool IsNull();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <param name="callback"></param>
        void StompMessage(StompHelper.StompClientCommand command, System.Collections.Generic.Dictionary<string, string> data, string key, Action<string> callback);


        void Update();
    }
}
