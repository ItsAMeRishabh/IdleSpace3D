#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace GS.Generator
{
    public static class TransactionGenerator
    {
        private static Texture2D scriptIcon = (
            EditorGUIUtility.IconContent("cs Script Icon").image as Texture2D
        );

        [MenuItem("Assets/Create/GSVault/Network/Transaction C# Script", false, 89)]
        public static void GenerateTransactionConfigScript()
        {
            string templetePath = GS.ScriptGenerator.GetTemplatePath("GS_Transaction");
            GS.ScriptGenerator.CreateFromTemplate(
                "Transaction.cs",
                templetePath,
                "",
                scriptIcon,
                ""
            );
        }

        [MenuItem("Assets/Create/GSVault/Network/ResponseOperator C# Script", false, 89)]
        public static void GenerateResponseOperatorConfigScript()
        {
            string templetePath = GS.ScriptGenerator.GetTemplatePath("GS_ResponseOperator");
            GS.ScriptGenerator.CreateFromTemplate(
                "ResponseOperator.cs",
                templetePath,
                "",
                scriptIcon,
                ""
            );
        }
    }
}
#endif
