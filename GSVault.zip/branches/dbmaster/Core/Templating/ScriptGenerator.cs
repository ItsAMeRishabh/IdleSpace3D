using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace GS
{
    public static class ScriptGenerator
    {
        public static void GenerateEnum(string fullPath, string namespaceTarget, List<string> enums)
        {
            string body = string.Empty;

            for (int i = 0; i < enums.Count; i++)
            {
                body += enums[i];
                if (i < enums.Count - 1)
                {
                    body += ",\n\t\t";
                }
            }

            CreateScript(fullPath, GetTemplatePath("Custom_EnumTemplate"), namespaceTarget, body);
        }

        public static string GetTemplatePath(string templateName)
        {
#if UNITY_EDITOR
            string[] guids = UnityEditor.AssetDatabase.FindAssets($"{templateName}.cs");
            if (guids.Length == 0)
            {
                Debug.LogWarning($"{templateName}.cs.txt not found in asset database");
                return string.Empty;
            }
            return UnityEditor.AssetDatabase.GUIDToAssetPath(guids[0]);
#else
            return "";
#endif
        }

        public static Object CreateScript(
            string pathName,
            string templatePath,
            string namespaceTarget,
            string body = ""
        )
        {
#if UNITY_EDITOR
            string className = Path.GetFileNameWithoutExtension(pathName)
                .Replace(" ", string.Empty);
            string templateText = string.Empty;

            UTF8Encoding encoding = new UTF8Encoding(true, false);

            if (File.Exists(templatePath))
            {
                StreamReader reader = new StreamReader(templatePath);
                templateText = reader.ReadToEnd();
                reader.Close();

                templateText = templateText.Replace("#CLASSNAME#", className);
                templateText = templateText.Replace("#NAMESPACE#", namespaceTarget);
                templateText = templateText.Replace("#NOTRIM#", string.Empty);
                templateText = templateText.Replace("#BODY#", body);

                StreamWriter writer = new StreamWriter(Path.GetFullPath(pathName), false, encoding);
                writer.Write(templateText);
                writer.Close();

                UnityEditor.AssetDatabase.ImportAsset(pathName);
                return UnityEditor.AssetDatabase.LoadAssetAtPath(pathName, typeof(Object));
            }
            else
            {
                Debug.LogError($"The template file was not found: {templatePath}");
                return null;
            }
#else
            return null;
#endif
        }

        public static void CreateFromTemplate(
            string initialName,
            string templatePath,
            string namespaceTarget,
            Texture2D scriptIcon,
            string body
        )
        {
#if UNITY_EDITOR
            DoCreateCodeFile action = ScriptableObject.CreateInstance<DoCreateCodeFile>();
            action.namespaceTarget = namespaceTarget;
            action.body = body;

            UnityEditor.ProjectWindowUtil.StartNameEditingIfProjectWindowExists(
                0,
                action,
                initialName,
                scriptIcon,
                templatePath
            );
#endif
        }

#if UNITY_EDITOR
        /// Inherits from EndNameAction, must override EndNameAction.Action
        internal class DoCreateCodeFile : UnityEditor.ProjectWindowCallback.EndNameEditAction
        {
            public string namespaceTarget;
            public string body;

            public override void Action(int instanceId, string pathName, string resourceFile)
            {
                Object o = GS.ScriptGenerator.CreateScript(
                    pathName,
                    resourceFile,
                    namespaceTarget,
                    body
                );
                UnityEditor.ProjectWindowUtil.ShowCreatedAsset(o);
            }
        }
#endif
    }
}
