﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Transactions;
using UnityEngine;
using UnityEngine.UI;

namespace GS.UI
{
    /// <summary>
    /// Handles 'Highlight UI elements' (eg: tutorail's etc.,)
    /// </summary>
    public class UIScreenTutorial<TSettingType> : MonoBehaviour
        where TSettingType : struct, Enum
    {
        /// <summary>
        /// Pointing Arrow spawing side
        /// </summary>
        public enum ArrowPointingSide
        {
            None,
            Auto,
            Left,
            Right,
            Top,
            Bottom,
            TopLeft,
            TopRight,
            BottomLeft,
            BottomRight
        }

        /// <summary>
        /// Controls flow of multiple tutorial objects
        /// </summary>
        public enum ShowType
        {
            InCurrentFlow,
            OnNextSceneLaunch
        }

        /// <summary>
        /// Where Tap has to be considered.
        /// </summary>
        public enum TapType
        {
            OnObject,
            AnywhereOnScreen,
            OnlyOKButton
        }

        [System.Serializable]
        public class TutorialButtonInfo
        {
            [Header("This is for having multiple tutorial for same button in different scenarios")]
            public string playerPrefID;
            public GameObject tutorialButton;
            [Header("For 3D dummy tutorial buttons, it will be helpful")]
            public bool hasToBeDisabledOnTutorialCompleted;
            public ShowType showType;
            public ArrowPointingSide arrowPointingSide = ArrowPointingSide.Auto;
            [TextArea]
            public string highlightMessage;

            [Header("Tutorial for this object will start after these many frames delay")]
            public int delayInFrames = 0;

            public TapType tapType;

            // ------------------------ OnClick Listners ------------------------
            [Serializable]
            public class ButtonClickedEvent : UnityEngine.Events.UnityEvent { }
            // Event delegates triggered on click.
            [SerializeField]
            public ButtonClickedEvent m_OnClick = new ButtonClickedEvent();


            // ------------------------ ResumeTutorial ------------------------
            [Serializable]
            public class TutorialReadyEvent : UnityEngine.Events.UnityEvent<Action<bool>> { }
            [Header("Provides 'Tutorial Resume(bool)' method, when Tutorial is ready to start")]
            [Header("Parameter, True -> Resumes, Flase -> Stops Tutorial")]
            [Header("Helpful when we need to hold tutorial begin untill some action done by user")]
            [Header("If it is empty then, Tutorial will start automatically")]
            [SerializeField]
            public TutorialReadyEvent m_NotifyOnTutorialReady = new TutorialReadyEvent();


            public void OnTutorialCompleted()
            {
                // As tutorial ended, check tutorial object has to be disabled.
                if (hasToBeDisabledOnTutorialCompleted)
                {
                    if (tutorialButton != null)
                        tutorialButton.SetActive(false);
                }

                // Destroy tutorial helper classes
                if(m_OnClick != null && m_OnClick.GetPersistentEventCount() != 0)
                {
                    UnityEngine.Object scriptObj = m_OnClick.GetPersistentTarget(0);
                    var scriptRef = scriptObj as MonoBehaviour;
                    if (scriptRef != null)
                        scriptRef.enabled = false;

                    //if (scriptObj != null)
                    //    Destroy(scriptObj);
                }

                // Destroy tutorial helper classes
                if (m_NotifyOnTutorialReady != null && m_NotifyOnTutorialReady.GetPersistentEventCount() != 0)
                {
                    UnityEngine.Object scriptObj = m_NotifyOnTutorialReady.GetPersistentTarget(0);
                    var scriptRef = scriptObj as MonoBehaviour;
                    if (scriptRef != null)
                        scriptRef.enabled = false;
                }
            }
        }

        
        #region Variables

        [Header("These are required components")]
        public Canvas canvasHolder;
        public GameObject pointingArrowPrefab;
        public GameObject messageBoxPrefab;

        
        [Header("Provide Tutorial GameObjects Info")]
        public TutorialButtonInfo[] tutorialGameObjects;

        string playerPrefKeyPrefix = "Tuto_";

        /// <summary>
        /// True, if tutorial started atleast once.
        /// </summary>
        bool isTutorialStartedInCurrentSession;

        /// <summary>
        /// Used in 'Update()' method to callSetUp
        /// </summary>
        bool canCallSetUpTutorial;

        /// <summary>
        /// Holds Array Index of current TutorialButtonInfo
        /// </summary>
        sbyte currentActiveTutorialButtonIndex;


        /// <summary>
        /// Holds TutorialPanel
        /// </summary>
        GameObject tutorialPanel;

        // ----------------------------- Message Box auto Size adjustments -----------------------------
        byte msgBoxAutoAdjustFrameCounter;
        RectTransform arrowRectTrans, msgBoxRectTrans;
        Vector2 msgBoxAutoAdjustSidevector;

        #endregion Variables


        protected virtual void Start()
        {
            isTutorialStartedInCurrentSession = false;
            msgBoxAutoAdjustFrameCounter = 0;

            startTutorial();
        }

        protected virtual void Update()
        {
            // Check MsgBox adjustment required/not.
            if (msgBoxAutoAdjustFrameCounter > 0)
            {
                msgBoxAutoAdjustFrameCounter--;

                if (msgBoxAutoAdjustFrameCounter == 0)
                {
                    // Adjust messageBox position after auto size adjusting by text length done.
                    msgBoxRectTrans.anchoredPosition = arrowRectTrans.anchoredPosition + (msgBoxAutoAdjustSidevector * arrowRectTrans.GetHeight()) + (msgBoxAutoAdjustSidevector * new Vector2(msgBoxRectTrans.GetWidth() / 2, msgBoxRectTrans.GetHeight() / 2));
                }
            }

            if (canCallSetUpTutorial)
            {
                if (tutorialGameObjects[currentActiveTutorialButtonIndex].delayInFrames > 0)
                    tutorialGameObjects[currentActiveTutorialButtonIndex].delayInFrames--;
                else
                {
                    canCallSetUpTutorial = false;
                    setUpTutorial();
                }
            }
        }

        /// <summary>
        /// Starts Tutorial by looping through 'TutorialsButtonsInfo' array.
        /// </summary>
        protected virtual void startTutorial() //(int tutorialButtonIndex)
        {
            //currentActiveTutorialButtonIndex = -1;
            currentActiveTutorialButtonIndex = checkAnyPendingTutorials();

            // If there are no pending Tutorials, return from here.
            if (currentActiveTutorialButtonIndex == -1)
            {
                // As we are done with showing tutorials in current session.Disbale this monobehaviour
                this.enabled = false;

                return;
            }

            isTutorialStartedInCurrentSession = true;

            // ------------------ 
            // Here we need to check weather we can start tutorial/ we should give that control to outside
            // ------------------ 
            if (tutorialGameObjects[currentActiveTutorialButtonIndex].m_NotifyOnTutorialReady != null &&
                tutorialGameObjects[currentActiveTutorialButtonIndex].m_NotifyOnTutorialReady.GetPersistentEventCount() != 0)
            {
                // As getNotified action is not empty (means they want control before starting current Tutorial), 
                // notify them with 'action' to 'startTutorial'
                tutorialGameObjects[currentActiveTutorialButtonIndex].m_NotifyOnTutorialReady.Invoke(ResumeTutorial);
            }
            else
            {
                // As out side class is not expecting control, we can resumeTutorial.
                ResumeTutorial(true);
            }
        }

        /// <summary>
        /// SetUps tutorial by creating necessary elements(clones)
        /// </summary>
        protected virtual void setUpTutorial()
        {
            try
            {
                // Creating Tutorial Panel
                createTutorialPanel();

                // Adding BackGround to Tutorial Panel
                addBackGroundImage(tutorialPanel, 4, 2, 11, 220);

                //BoundTestFunction();

                TutorialButtonInfo tutorialButtonInfo = tutorialGameObjects[currentActiveTutorialButtonIndex];

                // Cloning Required Tutorial Button
                GameObject clonedObject = checkParentsAndCloneThem(tutorialButtonInfo);

                // Creating Pointing Arrow
                Vector2 sideVector = Vector2.zero;
                GameObject clonedArrow = createPointingArrow(clonedObject, tutorialButtonInfo, out sideVector);

                // Creating Message Box
                createMessageBox(sideVector, clonedArrow, tutorialButtonInfo);

                assignTapCallback(clonedObject, tutorialButtonInfo);
            }
            catch(Exception e)
            {
                Log.Error(this + ", got exception in setUpTutorial(). Exception: " + e);
                endTutorial(true);
            }
        }

        /// <summary>
        /// Ends tutorial.
        /// 1. Destorys TutorialPanel so that all Instantiated clones will be destroyed
        /// 2. calls StartTutorial again
        /// </summary>
        protected virtual void endTutorial(bool isTutorialCompleted) //TutorialButtonInfo tutorialButtonInfo) //(int tutorialButtonIndex)
        {
            // Get current user profile ID
            int currentProfileId = 0;
            // TODO : 
            //Utils.EventAsync(new GS.Events.UserProfile.GetCurrentUserProfileBasicInfo((info) => { currentProfileId = info.profileID; }));

            if (isTutorialCompleted)
                Utils.EventSync(new GS.GameEvents.Save.SaveManagerEventBool(playerPrefKeyPrefix + currentProfileId + "_" + tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.name + tutorialGameObjects[currentActiveTutorialButtonIndex].playerPrefID, true));

            // As this tutorial is ended either by smooth/forcefully, pass this info to class
            tutorialGameObjects[currentActiveTutorialButtonIndex].OnTutorialCompleted();

            //Destroy(currentActiveTutorialButton);
            Destroy(tutorialPanel);

            // Incrementing index before checking nextTutorial in current script queue, as we completed tutorial for current tutorial button
            currentActiveTutorialButtonIndex++;

            // Check
            startTutorial();
        }

        /// <summary>
        /// Checks are there any pending tutorials in current flow, if found returns 'array index' of gameObject in TutorialsButtonsInfo.
        /// Returns '-1' if not found
        /// </summary>
        /// <returns></returns>
        protected virtual sbyte checkAnyPendingTutorials()
        {
            //for (sbyte i = 0; i < tutorialGameObjects.Length; i++)
            for (sbyte i = currentActiveTutorialButtonIndex; i < tutorialGameObjects.Length; i++)
            {
                // Making sure to reset before event call.
                // Assiging 'True' as default value, otherwise if callBack not invoked then, Tutorial will be showen each time.
                bool tempIsCurrentButtonTutorialCompleted = true;

                // Get current user profile ID
                int currentProfileId = 0;
                // TODO : 
                // Utils.EventAsync(new GS.Events.UserProfile.GetCurrentUserProfileBasicInfo((info) => { currentProfileId = info.profileID; }));
                
                //Utils.EventAsync(new GameEvents.PlayerPrefs.SaveManagerEventBool(playerPrefBool_Callback, playerPrefKeyPrefix + tutorialGameObjects[i].tutorialButton.name, false));
                Utils.EventSync(new GS.GameEvents.Save.SaveManagerEventBool(result => tempIsCurrentButtonTutorialCompleted = result, playerPrefKeyPrefix + currentProfileId + "_" + tutorialGameObjects[i].tutorialButton.name + tutorialGameObjects[i].playerPrefID, false));

                if (!tempIsCurrentButtonTutorialCompleted)
                {
                    // Check current Tutorial element can be shown in current flow
                    if (tutorialGameObjects[i].showType == ShowType.InCurrentFlow)
                    {
                        // As we can show in current flow,
                        return i;
                    }
                    else
                    {
                        if (isTutorialStartedInCurrentSession)
                            // As we can't show in current flow in current flow,
                            return -1;
                        else
                            // As this is fresh current flow, we can send index value, otherwise this show type will never be called out
                            return i;
                    }
                }
                else
                {
                    // This tutorial completed already, pass this info to class
                    tutorialGameObjects[currentActiveTutorialButtonIndex].OnTutorialCompleted();
                }
            }

            return -1;
        }

        /// <summary>
        /// Starts/Stops tutorial based on boolean input
        /// True -> Resumes tutorial
        /// False -> Stops tutorial
        /// </summary>
        /// <param name="resumeTutorial"></param>
        void ResumeTutorial(bool resumeTutorial)
        {
            bool canShowTutorials = true;

            if (System.Enum.TryParse<TSettingType>("Tutorial", out TSettingType tutorial))
            {
                // Get gameSettings value of 'TutorialsEnabled' key
                Utils.EventSync(new GameEvents.GetSettingEvent(System.Convert.ToInt32(tutorial), (valPairs) => { canShowTutorials = ((int)valPairs == 1) ? true : false; }, 1));

                // Check Tutorials can be shown/not.
                // This check has to be performed here, otherwise if user enables tutorial in between(eg inside ingame scene),
                // tutorials has to be displayed from there.
                if (canShowTutorials && resumeTutorial)
                {
                    canCallSetUpTutorial = true;
                }
                else
                    // As this is ended by outside class, passing 'false'
                    endTutorial(false);
            }
        }


        #region Tutorial Panel

        protected void createTutorialPanel()
        {
            // Create GameObject for tutorialPanel
            tutorialPanel = new GameObject("TutorialPanel", typeof(RectTransform));
            tutorialPanel.transform.SetParent(this.transform);

            // Make this Bg strecth entire canvas
            RectTransform rectTransform = tutorialPanel.GetComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);

            // Set Scale
            tutorialPanel.transform.localScale = new Vector3(1, 1, 1);

            // Set Size
            //rectTransform.sizeDelta = new Vector2(0, 0);
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;

            // Set it as last child element, so that this will draw on current Main UIPanel
            tutorialPanel.transform.SetAsLastSibling();
        }

        #endregion Tutorial Panel


        #region Clone Tutorial Button

        protected GameObject checkParentsAndCloneThem(TutorialButtonInfo tutorialButton)
        {
            if (tutorialButton == null || tutorialButton.tutorialButton == null)
            {
                Log.Error(this + " - Either TutorialButtonInfo/TutorialButton is null. Can't clone TutorialButton");
                return null;
            }

            bool isRootTransform = false;
            List<GameObject> parents = new List<GameObject>(4);
            GameObject obj = tutorialButton.tutorialButton;

            // Add Given object to list first
            parents.Add(obj);

            // Searching for parents and add them to list
            Transform t = obj.transform;
            while (!isRootTransform)
            {
                t = t.parent;
                if(UnityEngine.Object.ReferenceEquals(t, this.transform))
                    isRootTransform = true;
                else
                    parents.Add(t.gameObject);
            }

            GameObject lastCreatedObject = tutorialPanel;
            bool isPreviousCloneLayoutElement = false;

            // We have parents, now make their clones
            for (int i= parents.Count-1; i>=0 ; i--)
            {
                GameObject cloneObj = new GameObject(parents[i].name, typeof(RectTransform));
                

                //newParent.transform.SetParent(lastCreatedObject.transform);

                RectTransform realRectTrans = parents[i].transform as RectTransform;
                RectTransform cloneRectTrans = cloneObj.transform as RectTransform;

                cloneRectTrans.SetParent(lastCreatedObject.transform as RectTransform);

                cloneRectTrans.anchoredPosition = realRectTrans.anchoredPosition;
                cloneRectTrans.anchorMin = realRectTrans.anchorMin; // new Vector2(0, 0);
                cloneRectTrans.anchorMax = realRectTrans.anchorMax; // new Vector2(1, 1);

                // Set Scale
                cloneRectTrans.localScale = realRectTrans.localScale; // new Vector3(1, 1, 1);

                // Set Size
                cloneRectTrans.offsetMin = realRectTrans.offsetMin; // Vector2.zero;
                cloneRectTrans.offsetMax = realRectTrans.offsetMax; // Vector2.zero;


                if (isPreviousCloneLayoutElement)
                {
                    // Create sibilings
                    int sibilingCount = realRectTrans.parent.childCount;

                    // '-1' because already required gameObject is cloned and added
                    for (int j = 0; j < sibilingCount - 1; j++)
                    {
                        GameObject.Instantiate(cloneObj, cloneRectTrans.parent);
                    }

                    cloneRectTrans.SetSiblingIndex(realRectTrans.GetSiblingIndex());
                }


                isPreviousCloneLayoutElement = AddLayOutElementsIfAny(realRectTrans.gameObject, cloneObj);

                

                lastCreatedObject = cloneObj;
            }


            // Creating required Tutorial Object now
            GameObject requiredCloneObj = GameObject.Instantiate(obj, lastCreatedObject.transform);
            RectTransform requiredCloneRectTrans = requiredCloneObj.transform as RectTransform;

            // Make this element strecth entire cloned object
            requiredCloneRectTrans.anchorMin = new Vector2(0, 0);
            requiredCloneRectTrans.anchorMax = new Vector2(1, 1);

            // Set Scale
            requiredCloneRectTrans.localScale = new Vector3(1, 1, 1);

            // Set Size
            requiredCloneRectTrans.offsetMin = Vector2.zero;
            requiredCloneRectTrans.offsetMax = Vector2.zero;

            return requiredCloneObj;
        }

        protected bool AddLayOutElementsIfAny(GameObject actualObj, GameObject cloneObj)
        {
            bool isLayoutElement = false;

            LayoutGroup[] layoutsArray = actualObj.GetComponents<LayoutGroup>();

            
            for (int i=0; i<layoutsArray.Length; i++)
            {
                isLayoutElement = true;

                if (layoutsArray[i] is VerticalLayoutGroup)
                    cloneObj.AddComponent<VerticalLayoutGroup>().GetCopyOf(layoutsArray[i]);

                else if (layoutsArray[i] is HorizontalLayoutGroup)
                    cloneObj.AddComponent<HorizontalLayoutGroup>().GetCopyOf(layoutsArray[i]);

                else if (layoutsArray[i] is GridLayoutGroup)
                    cloneObj.AddComponent<GridLayoutGroup>().GetCopyOf(layoutsArray[i]);
            }

            return isLayoutElement;
        }

        #endregion Clone Tutorial Button


        #region Pointing Arrow

        GameObject createPointingArrow(GameObject clonedObj, TutorialButtonInfo btnInfo, out Vector2 sideVector)
        {
            // Create GameObject for tutorialPanel
            GameObject pointingArrowClone = GameObject.Instantiate(pointingArrowPrefab, tutorialPanel.transform);
            RectTransform rectTransform = pointingArrowClone.GetComponent<RectTransform>();

            Quaternion pointingArrowRotation = Quaternion.identity;

            RectTransform clonedRectTransform = clonedObj.transform as RectTransform;
            Vector2 idealClonedPiviot = Vector2.zero;

            //Vector2 sideVector = Vector2.zero;
            sideVector = Vector2.zero;

            switch (btnInfo.arrowPointingSide)
            {
                case ArrowPointingSide.Left:
                    pointingArrowRotation = Quaternion.Euler(0, 0, -90);
                    idealClonedPiviot = new Vector2(0, 0.5f);
                    sideVector = new Vector2(-1, 0);
                    break;
                case ArrowPointingSide.Right:
                    pointingArrowRotation = Quaternion.Euler(0, 0, 90);
                    idealClonedPiviot = new Vector2(1, 0.5f);
                    sideVector = new Vector2(1, 0);
                    break;
                case ArrowPointingSide.Top:
                    pointingArrowRotation = Quaternion.Euler(0, 0, 180);
                    idealClonedPiviot = new Vector2(0.5f, 1);
                    sideVector = new Vector2(0, 1);
                    break;
                case ArrowPointingSide.Bottom:
                    pointingArrowRotation = Quaternion.Euler(0, 0, 0);
                    idealClonedPiviot = new Vector2(0.5f, 0);
                    sideVector = new Vector2(0, -1);
                    break;
                case ArrowPointingSide.TopLeft:
                    pointingArrowRotation = Quaternion.Euler(0, 0, 225);
                    idealClonedPiviot = new Vector2(0, 1);
                    sideVector = new Vector2(-1, 1);
                    break;
                case ArrowPointingSide.TopRight:
                    pointingArrowRotation = Quaternion.Euler(0, 0, 135);
                    idealClonedPiviot = new Vector2(1, 1);
                    sideVector = new Vector2(1, 1);
                    break;
                case ArrowPointingSide.BottomLeft:
                    pointingArrowRotation = Quaternion.Euler(0, 0, -45);
                    idealClonedPiviot = new Vector2(0, 0);
                    sideVector = new Vector2(-1, -1);
                    break;
                case ArrowPointingSide.BottomRight:
                    pointingArrowRotation = Quaternion.Euler(0, 0, 45);
                    idealClonedPiviot = new Vector2(1, 0);
                    sideVector = new Vector2(1, -1);
                    break;
                default:
                    Log.Error(this + " - ArrowPointingSide case not defined, " + btnInfo.arrowPointingSide);
                    break;
            }

            // Setting pivot of cloned object to required side
            Vector2 clonedObjPivotBackup = clonedRectTransform.pivot;
            clonedRectTransform.pivot = idealClonedPiviot;
            Vector3 inverseTransformPosition = canvasHolder.GetComponent<RectTransform>().InverseTransformPoint(clonedObj.transform.position);

            // Reseeting back cloned object piviot
            clonedRectTransform.pivot = clonedObjPivotBackup;

            // Set Anchored Position
            rectTransform.anchoredPosition = inverseTransformPosition;

            // Set Pivot of Arrow
            rectTransform.pivot = new Vector2(0.5f, 1.0f);

            // Set Rotation of Arrow
            rectTransform.localRotation = pointingArrowRotation;

            /*
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);

            // Set Scale
            pointingArrowClone.transform.localScale = new Vector3(1, 1, 1);

            // Set Size
            //rectTransform.sizeDelta = new Vector2(0, 0);
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
            */

            // Set it as last child element, so that this will draw on current Main UIPanel
            pointingArrowClone.transform.SetAsLastSibling();

            //createMessageBox(sideVector, rectTransform, btnInfo);
            return pointingArrowClone;
        }

        #endregion Pointing Arrow


        #region MessageBox

        void createMessageBox(Vector2 sideVector, GameObject clonedArrow, TutorialButtonInfo btnInfo)
        {
            if (clonedArrow == null)
            {
                Log.Error(this + " - Cloned Aroow GameObject is null, so can't create messageBox");
                return;
            }

            RectTransform pointingArrowRectTransform = clonedArrow.GetComponent<RectTransform>();

            GameObject clonedMsgBox = GameObject.Instantiate(messageBoxPrefab, tutorialPanel.transform);
            RectTransform rectTransform = clonedMsgBox.GetComponent<RectTransform>();

            // Set Pivot of Arrow
            rectTransform.pivot = new Vector2(0.5f, 0.5f);

            

            // Set Size
            rectTransform.sizeDelta = new Vector2(100, 100);

            // Assign Text Message
            Text msgText = clonedMsgBox.GetComponentInChildren<Text>(true);
            if (msgText != null && btnInfo != null)
                msgText.text = btnInfo.highlightMessage;

            // Assign 'Disable Tutorial' toggle listner
            GameObject temp = clonedMsgBox.transform.FindChildGameObject("DisableTutorial", true);
            if (temp != null)
            {
                Toggle disableToggle = temp.GetComponentInChildren<Toggle>(true);
                if (disableToggle != null)
                {
                    Toggle t = disableToggle;

                    // Assign 'onValueChanged' listner
                    disableToggle.onValueChanged.AddListener((bool val) =>
                                                                            {
                                                                                if (val)
                                                                                {
                                                                                    // As user clicked on disable tutorial, end current tutorial
                                                                                    endTutorial(true);
                                                                                }
                                                                            });
                }
            }

            // Set Anchored Position
            rectTransform.anchoredPosition = pointingArrowRectTransform.anchoredPosition + (sideVector * pointingArrowRectTransform.GetHeight()) + (sideVector * new Vector2(rectTransform.GetWidth() / 2, rectTransform.GetHeight() / 2));

            msgBoxRectTrans = rectTransform;
            arrowRectTrans = pointingArrowRectTransform;
            msgBoxAutoAdjustSidevector = sideVector;

            // To use in 'Update()'
            msgBoxAutoAdjustFrameCounter = 2;
        }

        #endregion MessageBox


        #region Others

        /// <summary>
        /// 1. Add's image component if not present on this gameObject
        /// 2. Changes color if image
        /// </summary>
        /// <param name="r"></param>
        /// <param name="g"></param>
        /// <param name="b"></param>
        /// <param name="a"></param>
        /// <returns>Image Component/Null if not found or unable to created</returns>
        protected Image addBackGroundImage(GameObject obj, byte r, byte g, byte b, byte a)
        {
            if (obj == null)
                return null;

            // Add Image to current gameObject
            Image bg = obj.transform.GetOrAddComponent<Image>();
            // Change color of it to make actual panel look like greyedOut.
            bg.color = new Color32(r, g, b, a);

            return bg;
        }

        #endregion Others


        void assignTapCallback(GameObject clonedObj, TutorialButtonInfo tutorialButtonInfo)
        {
            if(clonedObj == null || tutorialButtonInfo == null)
            {
                Log.Error(this + " - Either clonedObj/tutorialButtonInfo is null. Can't add Tap callback");
                return;
            }

            Button b;

            switch (tutorialButtonInfo.tapType)
            {
                case TapType.OnObject:
                    b = clonedObj.transform.GetComponentInChildren<Button>();
                    if (b != null)
                    {
                        b.onClick.AddListener(() =>
                                                   {
                                                       if (tutorialButtonInfo.m_OnClick != null)
                                                           tutorialButtonInfo.m_OnClick.Invoke();

                                                       Log.Print(this + " - Invoked tutorial element action", LogFilter.GameEvent);
                                                       OnClick();
                                                   });
                    }
                    break;

                case TapType.AnywhereOnScreen:
                    b = tutorialPanel.transform.GetOrAddComponent<Button>();
                    if (b != null)
                    {
                        b.onClick.AddListener(() =>
                                                    {
                                                        if (tutorialButtonInfo.m_OnClick != null)
                                                            tutorialButtonInfo.m_OnClick.Invoke();

                                                        Log.Print(this + " - Clicked on tutorial panel", LogFilter.GameEvent);
                                                        OnClick();
                                                    });
                    }
                    break;

                case TapType.OnlyOKButton:
                    // Assign 'OK button' & button listner
                    GameObject tempOk = tutorialPanel.transform.FindChildGameObject("OK_Tutorial", true);
                    if (tempOk != null)
                    {
                        // Making sure this OK button is active
                        tempOk.SetActive(true);

                        b = tempOk.GetComponent<Button>();
                        if (b != null)
                        {
                            b.onClick.AddListener(() =>
                                                        {
                                                            //if (tutorialButtonInfo.m_OnClick != null)
                                                            //    tutorialButtonInfo.m_OnClick.Invoke();

                                                            Log.Print(this + " - Clicked on OK button", LogFilter.GameEvent);
                                                            OnClick();
                                                        });
                        }
                    }
                    break;
            }
        }

        void OnClick() //(TutorialButtonInfo tutorialButtonInfo) //(Button b)
        {
            //Debug.LogError("HIP HIP HIP");

            endTutorial(true);
        }


        #region Testing Region

        /// <summary>
        /// Internal TestFunction
        /// </summary>
        void BoundTestFunction()
        {
            /*
            RectTransform actualRectTransform = tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform as RectTransform;
            Transform actualTransform = tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform;

            Bounds b;
            
            Debug.LogError("sizeDelata : " +actualRectTransform.sizeDelta);

            b = RectTransformUtility.CalculateRelativeRectTransformBounds(transform, tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform);
            Debug.LogError("bbbb : " + b);

            Bounds c = RectTransformUtility.CalculateRelativeRectTransformBounds(tutorialPanel.transform, tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform);
            Debug.LogError("cccc : " + c);

            Bounds d = RectTransformUtility.CalculateRelativeRectTransformBounds(tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform, tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform);
            Debug.LogError("dddd : " + d);

            Bounds e = RectTransformUtility.CalculateRelativeRectTransformBounds(tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform.parent, tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform);
            Debug.LogError("eeee : " + e);

            Bounds f = RectTransformUtility.CalculateRelativeRectTransformBounds(tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform);
            Debug.LogError("ffff : " + f);

            Rect g = RectTransformUtility.PixelAdjustRect(tutorialGameObjects[currentActiveTutorialButtonIndex].tutorialButton.transform as RectTransform, canvasHolder);
            Debug.LogError("gggg : " + g.center);

            // -----------------------------------------
            Vector3[] corners1 = new Vector3[4];
            actualRectTransform.GetWorldCorners(corners1);

            for (int i = 0; i < 4; i++)
            {
                corners1[i] = canvasHolder.GetComponent<RectTransform>().InverseTransformPoint(corners1[i]);
                Debug.LogError(corners1[i]);
            }


            //Vector3[] corners2 = new Vector3[4];
            //actualRectTransform.GetLocalCorners(corners2);

            //for (int i = 0; i < 4; i++)
            //{
            //    corners2[i] = canvasHolder.GetComponent<RectTransform>().InverseTransformPoint(corners2[i]);
            //    Debug.LogError(corners2[i]);
            //}

            Vector3[] corners3 = new Vector3[4];
            //actualRectTransform.transform.GetLocalCorners(corners3);

            //for (int i = 0; i < 4; i++)
            {
                //corners3[0] = canvasHolder.GetComponent<RectTransform>().InverseTransformPoint(actualRectTransform.transform.position);
                //Debug.LogError(corners3[0]);
                //GameObject pointingArrowClone3 = new GameObject("PA3", typeof(RectTransform));
                //pointingArrowClone3.transform.SetParent(this.transform);
                //(pointingArrowClone3.transform as RectTransform).anchoredPosition = corners3[0];


                //Vector2 v2 = RectTransformUtility.WorldToScreenPoint(Camera.main ,corners3[0]);
                //Debug.LogError(v2);

                //v2 = RectTransformUtility.WorldToScreenPoint(Camera.main, actualRectTransform.transform.position);
                //Debug.LogError(v2);
                //pointingArrowClone = new GameObject("PA2", typeof(RectTransform));
                //pointingArrowClone.transform.SetParent(tutorialPanel.transform);
                //pointingArrowClone.transform.localPosition = v2;

                //Vector2 localPoint;
                //if (RectTransformUtility.ScreenPointToLocalPointInRectangle(tutorialPanel.transform as RectTransform, v2, Camera.main, out localPoint))
                //    Debug.LogError("Hip Hip : " + localPoint);


                //Vector2 pos = actualRectTransform.transform.position;  // get the game object position
                //Vector2 viewportPoint = Camera.main.WorldToViewportPoint(pos);  //convert game object position to VievportPoint
                //// set MIN and MAX Anchor values(positions) to the same position (ViewportPoint)
                //GameObject pointingArrowClone3 = new GameObject("PA3", typeof(RectTransform));
                //pointingArrowClone3.transform.SetParent(this.transform);
                //(pointingArrowClone3.transform as RectTransform).anchorMin = localPoint; // viewportPoint;
                //(pointingArrowClone3.transform as RectTransform).anchorMax = localPoint; // viewportPoint;
            }
            */
        }

        #endregion Testing Region
    }
}