﻿
using System;
using GS.Events;

namespace GS
{
    namespace UI
    {
        /// <summary>
        /// Manages all UI Screens using StateMachine
        /// </summary>
        public class UIStateMachine : StateMachine
        {
            protected Action<int> screenChangeAction;
            
            public IPopUP popUp;

            /// <summary>
            /// Adding Listeners here
            /// </summary>
            public override void Initialize()
            {
                base.Initialize();
                Utils.EM.AddListener<Events.BackKeyPressed>(OnBackKeyListener);
            }

            /// <summary>
            /// Sets common popup prefab
            /// </summary>
            /// <param name="popUp"></param>
            public virtual void SetPopUp(IPopUP popUp)
            {
                this.popUp = popUp;
            }

            /// <summary>
            /// Screen Changed callback from UI Controller
            /// </summary>
            /// <param name="screenChangeAction"></param>
            public  void SetScreenChangedCallback(Action<int> screenChangeAction)
            {
                this.screenChangeAction = screenChangeAction;
            }
           

            /// <summary>
            /// Adds UI Screen to UI state machine
            /// </summary>
            /// <param name="s"></param>
            public override void AddState(IState s)
            {
                base.AddState(s);
                s.DoBeforeLeaving();    
            }

            /// <summary>
            /// Listener for Back Key Pressed Event
            /// </summary>
            /// <param name="backKeyEvent"></param>
            private void OnBackKeyListener(BackKeyPressed backKeyEvent)
            {
                if (popUp != null && popUp.IsEnabled())
                    popUp.OnBackKeyPressed();
                else
                    GoToPreviousState();
            }

            /// <summary>
            /// Calling back Action on Screen Changed
            /// </summary>
            /// <param name="state"></param>
            public override void ChangeState(IState state)
            {
                base.ChangeState(state);
                if(screenChangeAction != null)
                   screenChangeAction(state.GetStateID());
            }

            /// <summary>
            /// Removing Listeners here
            /// </summary>
            public override void Release()
            {
                base.Release();
                Utils.EM.RemoveListener<Events.BackKeyPressed>(OnBackKeyListener);
            }


        }
    }
}
