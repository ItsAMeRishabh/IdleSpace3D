﻿
using GS.GameConsts;
using GS.UI;
using System;

namespace GS
{
    namespace Events
    {
        /// <summary>
        /// This event will be raised if Escape button pressed in Windows or back key pressed in Android
        /// </summary>
        public class BackKeyPressed : GameEvent
        {

        }

        /// <summary>
        /// Raise this event if common popup is required in any event
        /// </summary>
        public class UIPopUPEvent : GameEvent
        {
            public string title;
            public string message;
            public object[] titleParam;
            public object[] messageParam;
            public System.Action cancelEvent;
            public System.Action yesEvent;
            public System.Action noEvent;
            public ISprite icon;
            public UIPopupType type;
            public float timeToClose;
            public UIPopUpPrefabType uIPopUpPrefabType;
            public bool localize = true;
            /// <summary>
            /// Info with Close button without IMAGE
            /// </summary>
            /// <param name="title"></param>
            /// <param name="message"></param>
            /// <param name="cancelEvent"></param>
            public UIPopUPEvent(string title, string message, System.Action cancelEvent, object[] titleParam = null,object[] messageParam = null, bool _localize = true)
            {
                this.title = title;
                this.message = message;
                this.titleParam = titleParam;
                this.messageParam = messageParam;
                this.cancelEvent = cancelEvent;
                this.type = UIPopupType.Info;
                localize = _localize;
            }

            public UIPopUPEvent(string title, System.Action yesEvent, System.Action closeEvent, UIPopUpPrefabType uIPopUpPrefabType)
            {
                this.title = title;
                this.yesEvent = yesEvent;
                this.type = UIPopupType.Info;
                this.cancelEvent = closeEvent;
                this.uIPopUpPrefabType = uIPopUpPrefabType;
            }

            /// <summary>
            /// Prompt with Close button without IMAGE and without message
            /// </summary>
            /// <param name="title"></param>
            /// <param name="message"></param>
            /// <param name="cancelEvent"></param>
            public UIPopUPEvent(string title, System.Action yesEvent)
            {
                this.title = title;
                this.yesEvent = yesEvent;
                this.type = UIPopupType.Prompt;

            }

            /// <summary>
            /// Prompt with YES/NO buttons and without image.
            /// </summary>
            /// <param name="title"></param>
            /// <param name="message"></param>
            /// <param name="cancelEvent"></param>
            public UIPopUPEvent(string title, string message, System.Action yesEvent, System.Action noEvent,bool _localize= true)
            {
                this.title = title;
                this.message = message;
                this.yesEvent = yesEvent;
                this.noEvent = noEvent;
                this.type = UIPopupType.Prompt;
                localize = _localize;
            }

            /// <summary>
            /// Prompt with YES/NO buttons and with image.
            /// </summary>
            /// <param name="title"></param>
            /// <param name="message"></param>
            /// <param name="cancelEvent"></param>
            public UIPopUPEvent(string title, string message, ISprite icon, System.Action yesEvent, System.Action noEvent)
            {
                this.title = title;
                this.icon = icon;
                this.message = message;
                this.yesEvent = yesEvent;
                this.noEvent = noEvent;
                this.type = UIPopupType.Prompt;
            }
        }
    }
    
}
