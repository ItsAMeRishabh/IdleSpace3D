﻿using System;

namespace GS.UI
{
    /// <summary>
    /// Sprite interface 
    /// </summary>
    public interface ISprite
    {

    }
}
