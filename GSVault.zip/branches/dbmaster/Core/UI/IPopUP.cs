﻿
using GS.Events;
using GS.GameConsts;
using System;

namespace GS.UI
{
    /// <summary>
    /// Popup interface 
    /// </summary>
    public interface IPopUP
    {
        bool IsEnabled();

        void OnBackKeyPressed();

        void ShowPopUp(UIPopUPEvent uIPopUPEvent);
    }
}
