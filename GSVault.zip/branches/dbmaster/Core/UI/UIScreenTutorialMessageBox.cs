﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace GS.UI
{
    public class UIScreenTutorialMessageBox<TSettingType> : MonoBehaviour
        where TSettingType : struct, System.Enum
    {

        // Use this for initialization
        public virtual void Start()
        {

            ///Register call backs for Toggles available in the message box....
            Toggle[] toggles = GetComponentsInChildren<Toggle>(true);
            foreach (Toggle toggle in toggles)
            {
                Toggle t = toggle;

                // First call this method before assigning onValueChanged listner
                SetToggleValue(t);

                // Second assign 'onValueChanged' listner
                toggle.onValueChanged.AddListener((bool val) => OnValueChange(t, val));
            }
        }

        public void OnValueChange(Toggle t, bool isOn)
        {
            if(t.name.Equals("DisableTutorial"))
            {
                if (System.Enum.TryParse<TSettingType>("Tutorial", out TSettingType tutorialPacketType))
                {
                    // We need (!isOn) because here it is representing 'isTutorialEnabled' toggle
                    Utils.EventAsync(new GameEvents.SetSettingEvent(Convert.ToInt32(tutorialPacketType), (!isOn) ? 1 : 0));
                }
            }
        }

        public void SetToggleValue(Toggle t)
        {
            if (t.name.Equals("DisableTutorial"))
            {
                bool isTutorialsEnabled = false;

                if (System.Enum.TryParse<TSettingType>("Tutorial", out TSettingType tutorialPacketType))
                {
                    // Get gameSettings 'tutorial enabled' key value.
                    Utils.EventSync(new GameEvents.GetSettingEvent(Convert.ToInt32(tutorialPacketType), (obj) => { isTutorialsEnabled = ((int)obj == 1) ? true : false; }, 0));
                }

                t.isOn = !isTutorialsEnabled;
            }
        }

    }
}