﻿

using System;

namespace GS
{
    namespace GameEvents
    {

        public class GetSettingEvent : GameEvent
        {
            public int key;
            public Action<object> callback;
            public object defaultValue;

            public GetSettingEvent(int key, Action<object> callback, object defaultValue = null)
            {
                this.key = key;
                this.callback = callback;
                this.defaultValue = defaultValue;
            }
        }

        public class SetSettingEvent : GameEvent
        {
            public int key;
            public object val;

            public SetSettingEvent(int key, object val)
            {
                this.key = key;
                this.val = val;
            }
        }

        /// <summary>
        /// Changes GameState Event 
        /// </summary>
        public class ChangeGameState : GameEvent
        {
            public GameConsts.GameState gameState = GameConsts.GameState.NullState;

            public ChangeGameState(GameConsts.GameState gameState)
            {
                this.gameState = gameState;
            }

            public override string ToString()
            {
                return "GameState = " + gameState;
            }
        }

        /// <summary>
        /// Adds App Controller objects to GameManager
        /// </summary>
        public class AddAppController : GameEvent
        {
            public IController controller;
            public AddAppController(IController controller)
            {
                this.controller = controller;
            }

            public override string ToString()
            {
                return "Creating App Controller : " + controller;
            }
        }

        /// <summary>
        /// Adds Scene Controller objects to GameManager
        /// </summary>
        public class AddSceneController : GameEvent
        {
            public IController controller;
            public AddSceneController(IController controller)
            {
                this.controller = controller;
            }

            public override string ToString()
            {
                return "Creating Scene Controller : " + controller;
            }
        }

        public class SceneHandlerCompleteEvent : GameEvent
        {
            public int sceneName;

            public SceneHandlerCompleteEvent(int sceneName)
            {
                this.sceneName = sceneName;
            }

        }

        /// <summary>
        /// This event will be raised after data controller intialization completed
        /// </summary>
        public class DataInitializationDoneEvent : GameEvent
        {
            public bool success { get; private set; }

            public DataInitializationDoneEvent(bool isSuccess)
            {
                success = isSuccess;
            }
        }
    }
}
