﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialArrowAutoPosition : MonoBehaviour
{
    private RectTransform bottomArrow;
    private RectTransform topArrow;
    private RectTransform popUpRect;
    private RectTransform targetRect;
    private bool isTop;

    public void AutoPosition(GameObject targetObject, Vector2 offset)
    {
        if (popUpRect == null)
        {
            targetRect = targetObject.GetComponent<RectTransform>();
            popUpRect = gameObject.GetComponent<RectTransform>();
            bottomArrow = transform.GetChild(0).Find("BottomArrow").gameObject.GetComponent<RectTransform>();
            topArrow = transform.GetChild(0).Find("TopArrow").gameObject.GetComponent<RectTransform>();
        }

        isTop = (offset.y < 0) ? true : false;

        topArrow.gameObject.SetActive(isTop);
        bottomArrow.gameObject.SetActive(!isTop);

        float popUpHalfWidth = popUpRect.rect.width * 0.5f;
        popUpHalfWidth -= 50;
        offset.x = Mathf.Clamp(offset.x, -popUpHalfWidth, popUpHalfWidth);
        offset.y = 0;

        if (isTop)
        {
            topArrow.anchoredPosition -= offset;
            topArrow.localEulerAngles = (offset.x < 0) ? new Vector3(0, 180) : Vector3.zero;
        }
        else
        {
            bottomArrow.anchoredPosition -= offset;
            bottomArrow.localEulerAngles = (offset.x < 0) ? Vector3.zero : new Vector3(0, 180);
        }
    }
}
