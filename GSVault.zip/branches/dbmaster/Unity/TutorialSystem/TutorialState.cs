﻿using System;
using System.Collections.Generic;

namespace GS
{
    [Serializable]
    public class TutorialState
    {
        public string stateId;
        public List<TutorialAction> actions = new List<TutorialAction>();
        public List<EndActionListener> listeners = new List<EndActionListener>();
        public string exitStateId;

     
        public void OnEnter()
        {
            if (actions != null)
            {
                for (int i = 0; i < actions.Count; i++)
                {
                    var action = actions[i];

                    action?.OnEnter();
                }
            }

            if (listeners != null)
            {
                for (int i = 0; i < listeners.Count; i++)
                {
                    var listener = listeners[i];

                     listener?.OnEnter();
                }
            }
        }

        public void OnExit(bool isForceStop = false)
        {
            if (actions != null)
            {
                for (int i = 0; i < actions.Count; i++)
                {
                    var action = actions[i];

                    action?.OnExit();
                }
            }

            if (listeners != null)
            {
                for (int i = 0; i < listeners.Count; i++)
                {
                    var listener = listeners[i];
                    listener?.OnExit();
                }
            }

            if(!isForceStop)
                TutorialManager.Instance.CompleteState(stateId, exitStateId);
        }



        public void Update()
        {
            if (actions != null)
            {
                for (int i = 0; i < actions.Count; i++)
                {
                    var action = actions[i];

                    action?.Update();
                }
            }

            if (listeners != null)
            {
                for (int i = 0; i < listeners.Count; i++)
                {
                    var action = listeners[i];

                    if (action && action.IsCompleted)
                    {
                        // Overrrding the endlistener exitid, if not configured 
                        if (!string.IsNullOrEmpty(action.overrideStateId))
                            exitStateId = action.overrideStateId;

                        OnExit();
                        break;
                    }
                    else
                        action?.Update();
                }
            }
        }
    }
}