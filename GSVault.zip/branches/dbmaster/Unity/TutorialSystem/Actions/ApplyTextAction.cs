﻿
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    /// <summary>
    /// This action can be used to apply text to target object
    /// </summary>
    public class ApplyTextAction : BaseAction
    {
        public TargetGUID targetTextObject;
        public string childName = string.Empty;
        public string text;

        Dictionary<TextMeshProUGUI, string> PreviousTextMeshValues = new Dictionary<TextMeshProUGUI, string>();
        Dictionary<Text, string> PreviousTextValues = new Dictionary<Text, string>();

        public override void OnEnter()
        {
            base.OnEnter();

            FindTarget(targetTextObject.id);
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);

            var targetGameObject = targetObject.gameObject;
            if (childName != null && !childName.Equals(string.Empty))
            {
                GameObject childObject = null;
                var childNameSplits = childName.Split('/');
                if (childNameSplits.Length > 0)
                {
                    foreach (var child in childNameSplits)
                    {
                        if (childObject == null)
                        {
                            childObject = targetGameObject.transform.FindChildGameObject(child, true);
                        }
                        else
                        {
                            childObject = childObject.transform.FindChildGameObject(child, true);
                        }
                    }
                }
                else
                {
                    childObject = targetObject.transform.FindChildGameObject(childName, true);
                }
                targetGameObject = childObject;
            }

            if (targetObject != null)
            {
                var textMesh = targetGameObject.GetComponent<TextMeshProUGUI>();

                if (textMesh != null)
                {
                    textMesh.text = text;
                    PreviousTextMeshValues[textMesh] = textMesh.text;
                }
                else // if text mesh componenet not found , searching for Text component
                {
                    var textGO = targetGameObject.GetComponent<Text>();

                    if (textGO != null)
                    {
                        PreviousTextValues[textGO] = textGO.text;
                        textGO.text = text;
                    }
                }
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            targetTextObject = targetGUID;
            text = tutorialObject.Message;
            if (attributes.ContainsKey(nameof(childName)))
            {
                childName = attributes[nameof(childName)];
            }
        }

        public override void OnExit()
        {
            base.OnExit();

            foreach (var it in PreviousTextValues)
            {
                it.Key.text = it.Value;
            }

            foreach (var it in PreviousTextMeshValues)
            {
                it.Key.text = it.Value;
            }
        }
    }
}
