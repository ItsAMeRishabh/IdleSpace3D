﻿
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    /// <summary>
    /// Highlights list of GameObjects under the target parent GameObject 
    /// </summary>
    public class HighlightChildAction : BaseAction
    {
        public TargetGUID parentTarget;
        public bool disableAllButons = false;
        public List<string> childNames = new List<string>();

        private List<TutorialTarget> highlightableObjects = new List<TutorialTarget>();
        private TutorialTarget parentObject;
        private Dictionary<string, Transform> parentMap = new Dictionary<string, Transform>();
        private Dictionary<string, int> layerMap = new Dictionary<string, int>();


        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);

            for (int i = 0; i < childNames.Count; i++)
            {
                GameObject childObject = null;
                var childNameSplits = childNames[i].Split('/');
                if (childNameSplits.Length > 0)
                {
                    foreach (var child in childNameSplits)
                    {
                        if (childObject == null)
                        {
                            childObject = targetObject.transform.FindChildGameObject(child, true);
                        }
                        else
                        {
                            childObject = childObject.transform.FindChildGameObject(child, true);
                        }
                    }
                }
                else
                {
                    childObject = targetObject.transform.FindChildGameObject(childNames[i], true);
                }
                var go = childObject;
                if (go != null)
                    highlightableObjects.Add(go.transform.GetOrAddComponent<TutorialTarget>());
            }
            foreach (var obj in highlightableObjects)
            {
                int layerOff = highlightableObjects.FindIndex(s => s == obj);

                if (obj.IsUI)
                {
                    parentMap.Add(obj.UniqueID, obj.transform.parent);
                }
                else
                {
                    layerMap.Add(obj.UniqueID, obj.gameObject.layer);
                    obj.gameObject.layer = TutorialManager.Instance.TutorialLayer;
                }
                obj.SetLayer(100 + layerOff);

                if (disableAllButons)
                {
                    var buttons = obj.GetComponentsInChildren<Button>();
                    foreach (var button in buttons)
                    {
                        button.interactable = false;
                    }
                }
            }
        }

        public override void OnEnter()
        {
            showTint = true;
            highlightableObjects.Clear();
            base.OnEnter();
            parentMap.Clear();
            layerMap.Clear();
            FindTarget(parentTarget.id);
        }

        public override void OnExit()
        {
            base.OnExit();
            foreach (var obj in highlightableObjects)
            {
                if (disableAllButons)
                {
                    var buttons = obj.GetComponentsInChildren<Button>();
                    foreach (var button in buttons)
                    {
                        button.interactable = true;
                    }
                }

                obj.SetLayer(0);
                if (!obj.IsUI)
                    obj.gameObject.layer = layerMap[obj.UniqueID];
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            parentTarget = targetGUID;
            disableAllButons = TutorialManager.Instance.StringToBool(tutorialObject.DisableAllButtons);
            childNames.Add(tutorialObject.Message);
        }
    }
}