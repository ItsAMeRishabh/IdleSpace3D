﻿
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    /// <summary>
    /// This action can be used to Enable/Disabled the target objects
    /// </summary>
    public class EnableTargetAction : BaseAction
    {
        public List<TargetGUID> enableTargetsList = new List<TargetGUID>();
        public List<TargetGUID> disableTargetList = new List<TargetGUID>();
        Dictionary<GameObject, bool> PreviousActiveValues = new Dictionary<GameObject, bool>();

        public override void OnEnter()
        {
            base.OnEnter();

            FindTargets(enableTargetsList.ToArray());
            FindTargets(disableTargetList.ToArray());
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);


            if (enableTargetsList.Find(s => s.id == targetObject.UniqueID) != null)
            {
                if (targetObject != null)
                {
                    PreviousActiveValues[targetObject?.gameObject] = targetObject.gameObject.activeSelf;
                    targetObject.gameObject.SetActive(true);
                }
            }
            else if(disableTargetList.Find(s => s.id == targetObject.UniqueID) != null)
            {
                PreviousActiveValues[targetObject?.gameObject] = targetObject.gameObject.activeSelf;
                targetObject?.gameObject.SetActive(false);
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID();
            targetGUID.id = tutorialObject.TargetID;

            if (TutorialManager.Instance.StringToBool(tutorialObject.EnableTarget))
            {
                enableTargetsList.Add(targetGUID);
            }
            else
            {
                disableTargetList.Add(targetGUID);
            }
        }

        public override void OnExit()
        {
            base.OnExit();
            foreach (var it in PreviousActiveValues)
            {
                it.Key.SetActive(it.Value);
            }
        }
    }
}
