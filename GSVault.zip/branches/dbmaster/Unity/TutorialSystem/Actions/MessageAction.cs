﻿using GS;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    public enum MessageBoxPosition
    {
        Top,
        TopLeft,
        Left,
        BottomLeft,
        Bottom,
        BottomRight,
        Right,
        TopRight,
    }


    public class MessageAction : BaseAction
    {

        [Tooltip("For making stretchable message box 1.Add Content size fitter and set Horizontal = Unconstrained and Vertical = Preffered Size " +
        "2. Add Layout Component and set Minimum width , Minimum Height and Flexible height for stretching Vertically " +
        "Add this to text containing gameobject")]

        public AssetID asset;
        public MessageBoxPosition anchorPosition;

        public Vector3 offset;

        public TargetGUID target;

        public string title;
        public string message;

        TutorialMessageBox messageBox;

        public override void OnEnter()
        {
            showTint = true;
            base.OnEnter();
            GameObject goPrefab = TutorialManager.Instance.FindPrefabById(asset.id);
            if (goPrefab != null)
            {
                var go = GameObject.Instantiate(goPrefab);
                if (go != null)
                {
                    go.transform.parent = TutorialManager.Instance.GetCanvas().transform;
                    go.transform.localScale = Vector3.one;
                    go.transform.position = Vector3.zero;

                    messageBox = go.GetComponent<TutorialMessageBox>();
                    if (messageBox)
                    {
                        //SetupMessageBox(go);//change this
                        FindTarget(target.id);
                    }
                }
            }
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);
            //SetupMessageBox(targetObject.transform.position);
            SetupMessageBox(targetObject.gameObject);
        }

        private void SetupMessageBox(GameObject targetPosition)
        {
            if (messageBox)
            {
                messageBox.SetMessage(title, message);
                messageBox.ResizeBox(targetPosition, anchorPosition, offset);
                //messageBox.SetPosition(targetPosition, horizontal, vertical, offset);
            }
        }

        public override void OnExit()
        {
            base.OnExit();
            Destroy(messageBox.gameObject);
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            AssetID assetID = new AssetID { id = tutorialObject.Asset };
            asset = assetID;
            target = targetGUID;
            title = tutorialObject.Title;
            message = tutorialObject.Message;
            offset = TutorialManager.Instance.StringToVector3(tutorialObject.Offset);
        }
    }
}
