﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    /// <summary>
    /// Scrolls to target child object
    /// </summary>
    public class TargetScrollAction : BaseAction
    {
        public TargetGUID target;
        public string childName;
        public bool anchorBottom;
        public bool disableScroll = false;

        private RectTransform childRect;
        private RectTransform viewPortTransform;
        private ScrollRect scrollRect;
        private RectTransform scrollTransform;
        private RectTransform contentRect;

        public override void OnEnter()
        {
            base.OnEnter();
            FindTarget(target.id);
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);
            scrollRect = targetObject.gameObject.GetComponent<ScrollRect>();
            scrollTransform = scrollRect.transform as RectTransform;
            contentRect = scrollRect.content;
            GetViewPort();
            var childObject = targetObject.transform.FindChildGameObject(childName, true);
            if (childObject != null)
            {
                childRect = childObject?.GetComponent<RectTransform>();
                CenterOnItem(childRect);
                CenterOnTopOrBottom();
            }
            
            scrollRect.enabled = !disableScroll;
        }

        public override void OnExit()
        {
            base.OnExit();
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            target = targetGUID;
            if (attributes.ContainsKey(nameof(childName).ToLower()))
            {
                childName = attributes[nameof(childName).ToLower()];
            }

            if (attributes.ContainsKey(nameof(disableScroll).ToLower()))
            {
                disableScroll = TutorialManager.Instance.StringToBool(attributes[nameof(disableScroll).ToLower()]);
            }
            anchorBottom = TutorialManager.Instance.StringToBool(tutorialObject.SpecialFlag);
        }

        public void CenterOnItem(RectTransform target)
        {

            var itemCenterPositionInScroll = GetWorldPointInWidget(scrollTransform, GetWidgetWorldPoint(target));
            var targetPositionInScroll = GetWorldPointInWidget(scrollTransform, GetWidgetWorldPoint(viewPortTransform));
            var difference = targetPositionInScroll - itemCenterPositionInScroll;
            difference.z = 0f;

            if (!scrollRect.horizontal)
            {
                difference.x = 0f;
            }
            if (!scrollRect.vertical)
            {
                difference.y = 0f;
            }

            var normalizedDifference = new Vector2(
                difference.x / (contentRect.rect.size.x - scrollTransform.rect.size.x),
                difference.y / (contentRect.rect.size.y - scrollTransform.rect.size.y));

            var newNormalizedPosition = scrollRect.normalizedPosition - normalizedDifference;
            if (scrollRect.movementType != ScrollRect.MovementType.Unrestricted)
            {
                newNormalizedPosition.x = Mathf.Clamp01(newNormalizedPosition.x);
                newNormalizedPosition.y = Mathf.Clamp01(newNormalizedPosition.y);
            }

            scrollRect.normalizedPosition = newNormalizedPosition;
        }

        private void GetViewPort()
        {
            if (viewPortTransform == null)
            {
                var mask = scrollRect.GetComponentInChildren<Mask>(true);
                if (mask)
                {
                    viewPortTransform = mask.rectTransform;
                }
                if (viewPortTransform == null)
                {
                    var mask2D = scrollRect.GetComponentInChildren<RectMask2D>(true);
                    if (mask2D)
                    {
                        viewPortTransform = mask2D.rectTransform;
                    }
                }
            }
        }
        private Vector3 GetWidgetWorldPoint(RectTransform target)
        {
            //pivot position + item size has to be included
            var pivotOffset = new Vector3(
                (0.5f - target.pivot.x) * target.rect.size.x,
                (0.5f - target.pivot.y) * target.rect.size.y,
                0f);
            var localPosition = target.localPosition + pivotOffset;
            return target.parent.TransformPoint(localPosition);
        }
        private Vector3 GetWorldPointInWidget(RectTransform target, Vector3 worldPoint)
        {
            return target.InverseTransformPoint(worldPoint);
        }

        private void CenterOnTopOrBottom()
        {
            float halfHeight = childRect.rect.height * 0.5f;
            float yPos = contentRect.anchoredPosition.y;
            yPos = (anchorBottom) ? yPos + halfHeight : yPos - halfHeight;
            contentRect.anchoredPosition = new Vector2(contentRect.anchoredPosition.x, yPos);
        }
    }
}
