﻿using System;
using UnityEngine;

namespace GS
{
    public class BaseAction : TutorialAction
    {
        protected bool showTint = false;

        public override void OnEnter()
        {
            base.OnEnter();
            var canvas = TutorialManager.Instance.GetCanvas();
            
            if (canvas != null)
            {
                if(showTint)
                    canvas.ShowTintBG(showTint);
            }
        }

       
        /// <summary>
        /// OnExiting this action
        /// </summary>
        public override void OnExit()
        {
            var canvas = TutorialManager.Instance.GetCanvas();

            if (canvas != null)
            {
                canvas.ShowTintBG(false);
            }
        }
    }
}
