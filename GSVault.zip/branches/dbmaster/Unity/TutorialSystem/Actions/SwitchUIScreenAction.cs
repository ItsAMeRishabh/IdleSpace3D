﻿
using System.Collections.Generic;

namespace GS
{
    /// <summary>
    /// Switch screen if your scene uses UIController class for transitioning between UI screens
    /// </summary>
    public class SwitchUIScreenAction : BaseAction
    {
        public int screenId;

        public override void OnEnter()
        {
            base.OnEnter();
            Utils.EventSync(new GameEvents.UIScreenEvent(screenId));
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            screenId = int.Parse(tutorialObject.Message);
        }
    }
}
