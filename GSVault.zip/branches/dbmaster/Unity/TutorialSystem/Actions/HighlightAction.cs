﻿
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    /// <summary>
    /// Highlights list of GameObjects 
    /// </summary>
    public class HighlightAction : BaseAction
    {
        /// <summary>
        /// Holds the list of targets to be highlighted
        /// </summary>
        private List<TutorialTarget> highlightableObjects = new List<TutorialTarget>();
        private Dictionary<string, int> layerMap = new Dictionary<string, int>();

        public bool disableAllButons = false;
        public bool applyLayerToChildren = true;
        public List<TargetGUID> targetIds = new List<TargetGUID>();

        private void SetLayer(GameObject gameObject, int layer, bool applyChildren = false)
        {
            gameObject.layer = layer;

            if (applyChildren)
            {
                foreach (Transform t in gameObject.transform)
                {
                    t.gameObject.layer = layer;
                }
            }
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);

            if (targetObject.IsUI)
            {
                // obj.transform.SetParent(TutorialManager.Instance.GetCanvas().transform);
            }
            else
            {
                layerMap.Add(targetObject.UniqueID, targetObject.gameObject.layer);
                SetLayer(targetObject.gameObject, TutorialManager.Instance.TutorialLayer, applyLayerToChildren);
            }

            targetObject.SetLayer(100);

            if (disableAllButons)
            {
                var button = targetObject.GetComponent<Button>();
                button.interactable = false;
            }

            if(!highlightableObjects.Contains(targetObject))
                highlightableObjects.Add(targetObject);

        }

        public override void OnEnter()
        {
            showTint = true;
            highlightableObjects.Clear();
            base.OnEnter();
            layerMap.Clear();
            FindTargets(targetIds.ToArray());
        }

        public override void OnExit()
        {
            base.OnExit();

            foreach (var obj in highlightableObjects)
            {
                if (obj != null)
                {
                    if (disableAllButons)
                    {
                        var button = obj.GetComponent<Button>();
                        if (button)
                            button.interactable = true;
                    }

                    obj.SetLayer(0);
                    if (!obj.IsUI)
                    {
                        SetLayer(obj.gameObject, layerMap[obj.UniqueID], applyLayerToChildren);
                    }
                }
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            targetIds.Add(targetGUID);
            disableAllButons = TutorialManager.Instance.StringToBool(tutorialObject.DisableAllButtons);
            applyLayerToChildren = TutorialManager.Instance.StringToBool(tutorialObject.SpecialFlag);
        }
    }
}