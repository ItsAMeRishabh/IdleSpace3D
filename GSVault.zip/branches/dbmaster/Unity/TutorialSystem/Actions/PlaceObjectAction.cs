﻿using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    public enum PlaceObjectKey
    {
        Text,
        TextMeshPro,
    }

    [System.Serializable]
    public class PlaceObjectInfo
    {
        public string childName;
        public PlaceObjectKey key;
        public string value1;
        public string value2;
    }

    public class PlaceObjectAction : BaseAction
    {
        public AssetID asset;
        public Vector3 offset = Vector3.zero;
        public TargetGUID targetObj;
        public string childName = string.Empty;
        public List<PlaceObjectInfo> keyPairs = new List<PlaceObjectInfo>();
        public bool isObjectAutoPosition = true;

        private GameObject objectToBePlaced;
        private Vector3 autoPositionOffset = Vector3.zero;

        public override void OnEnter()
        {
            showTint = true;
            base.OnEnter();
            // SpawnObject(targetObject.gameObject);
            GameObject prefabTemplate = TutorialManager.Instance.FindPrefabById(asset.id);

            if (prefabTemplate != null)
                objectToBePlaced = GameObject.Instantiate(prefabTemplate, TutorialManager.Instance.GetCanvas().transform);
            if(objectToBePlaced != null)
            {
                objectToBePlaced.transform.position = offset;
                ApplyKeyPairs(objectToBePlaced);
            }

            FindTarget(targetObj.id);
        }

        private void ApplyKeyPairs(GameObject parent)
        {
            foreach (var it in keyPairs)
            {
                GameObject childGo = parent.transform.FindChildGameObject(it.childName, true);
                if (childGo != null)
                {
                    switch (it.key)
                    {
                        case PlaceObjectKey.Text:
                            {
                                Text txt = childGo.GetComponent<Text>();
                                if (txt != null)
                                    txt.text = it.value1;
                            }
                            break;
                        case PlaceObjectKey.TextMeshPro:
                            {
                                TextMeshProUGUI txt = childGo.GetComponent<TextMeshProUGUI>();
                                if (txt != null)
                                {
                                    var localizecomponet = txt.gameObject.GetComponent<BaseUILocalization>();
                                    if (localizecomponet != null)
                                    {
                                        localizecomponet.UpdateKeyword(it.value1);
                                    }
                                    else
                                    {
                                        txt.SetText(it.value1);
                                    }
                                }
                            }
                            break;
                    }
                }
            }
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);
            GameObject targetObj = targetObject.gameObject;
            if (objectToBePlaced != null)
            {
                if (childName != null && !childName.Equals(string.Empty))
                {
                    GameObject childObject = null;
                    var childNameSplits = childName.Split('/');
                    if (childNameSplits.Length > 0)
                    {
                        foreach (var child in childNameSplits)
                        {
                            if (childObject == null)
                            {
                                childObject = targetObj.transform.FindChildGameObject(child, true);
                            }
                            else
                            {
                                childObject = childObject.transform.FindChildGameObject(child, true);
                            }
                        }
                    }
                    else
                    {
                        childObject = targetObj.transform.FindChildGameObject(childName, true);
                    }
                    targetObj = childObject;
                }

                var placedObjectTutorialTarget = objectToBePlaced.GetComponent<TutorialTarget>();
                if (placedObjectTutorialTarget != null)
                {
                    placedObjectTutorialTarget.SetLayer(102);
                }

                objectToBePlaced.transform.parent = targetObj.transform.parent;
                objectToBePlaced.transform.position = targetObj.transform.position;
                objectToBePlaced.transform.parent = TutorialManager.Instance.GetCanvas().transform;
                var rectTransform = objectToBePlaced.GetComponent<RectTransform>();

                if (isObjectAutoPosition)
                {
                    ObjectAutoPosition(targetObj.gameObject);
                }

                if (targetObject.IsUI)
                {
                    if(rectTransform != null)
                    {
                        rectTransform.localScale = Vector3.one;
                        rectTransform.localPosition += offset;
                    }
                    else
                    {
                        var camera = TutorialManager.Instance.Get3DCamera();

                        if(camera != null)
                        {
                            var pos = CanvasToWorldPosition(camera, targetObj.GetComponent<RectTransform>())/*+ offset*/;
                            objectToBePlaced.transform.position = pos;
                        }
                    }
                }
                else
                {
                    if (rectTransform != null)
                    {
                        rectTransform.localScale = Vector3.one;
                        rectTransform.anchoredPosition = WorldToCanvasPosition(objectToBePlaced.transform.parent.GetComponent<RectTransform>(), Camera.main, targetObj.transform.position);//  + offset;
                        Vector2 pos = rectTransform.anchoredPosition;
                        pos.x += offset.x;
                        pos.y += offset.y;

                        //targetObject.transform.position + offset;
                    }
                }

                TutorialArrowAutoPosition arrowAutoPos = objectToBePlaced.GetComponent<TutorialArrowAutoPosition>();
                if (arrowAutoPos != null)
                {
                    arrowAutoPos.AutoPosition(targetObj, offset + autoPositionOffset); // passing both offset , autoPosiotion and user offset
                }
                autoPositionOffset = Vector3.zero;
                offset = Vector3.zero;
            }
        }

        private Vector3 CanvasToWorldPosition(Camera camera, RectTransform rect)
        {
            var pos = camera.ViewportToWorldPoint(rect.position);
            return pos;
        }

        private Vector2 WorldToCanvasPosition(RectTransform canvas, Camera camera, Vector3 position)
        {
            //Vector position (percentage from 0 to 1) considering camera size.
            //For example (0,0) is lower left, middle is (0.5,0.5)
            Vector2 temp = camera.WorldToViewportPoint(position);

            //Calculate position considering our percentage, using our canvas size
            //So if canvas size is (1100,500), and percentage is (0.5,0.5), current value will be (550,250)
            temp.x *= canvas.sizeDelta.x;
            temp.y *= canvas.sizeDelta.y;

            //The result is ready, but, this result is correct if canvas recttransform pivot is 0,0 - left lower corner.
            //But in reality its middle (0.5,0.5) by default, so we remove the amount considering cavnas rectransform pivot.
            //We could multiply with constant 0.5, but we will actually read the value, so if custom rect transform is passed(with custom pivot) , 
            //returned value will still be correct.

            temp.x -= canvas.sizeDelta.x * canvas.pivot.x;
            temp.y -= canvas.sizeDelta.y * canvas.pivot.y;

            return temp;
        }

        public override void OnExit()
        {
            base.OnExit();
            childName = string.Empty;
            GameObject.Destroy(objectToBePlaced);
        }

        private void ObjectAutoPosition(GameObject targetObject)
        {
            
            RectTransform targetRect = targetObject.GetComponent<RectTransform>();
            Vector2 targetBounds = targetRect.rect.size;
            Vector2 targetCenter = targetRect.rect.center;
            float screenWidth = Screen.width;
            float screenHeight = Screen.height;
            var objectPlacedRectTransform = objectToBePlaced.GetComponent<RectTransform>();

            // y calculations
            float screenHalfHeight = screenHeight * 0.5f;
            float dividePoint = screenHeight * 0.25f;

            float objectYPoint = screenHalfHeight + objectPlacedRectTransform.anchoredPosition.y + targetCenter.y;

            autoPositionOffset.y = (targetBounds.y * 0.5f) + (objectPlacedRectTransform.rect.height * 0.5f);

            if (objectYPoint > dividePoint) // Top side
            {
                autoPositionOffset.y -= targetCenter.y;
                autoPositionOffset.y *= -1;
            }
            else
            {
                autoPositionOffset.y += targetCenter.y;
            }

            //x calculations
            float screenHalfWidth = screenWidth * 0.5f;
            float diff;
            float xPos = Mathf.Abs(objectPlacedRectTransform.anchoredPosition.x);
            float halfXBound = objectPlacedRectTransform.rect.width * 0.5f;

            diff = halfXBound - (screenHalfWidth - xPos);

            if (diff > 0)
            {
                if (objectPlacedRectTransform.anchoredPosition.x > 0)
                {
                    diff *= -1;
                }
                autoPositionOffset.x = diff;
            }

            objectPlacedRectTransform.localPosition += autoPositionOffset;           
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            childName = string.Empty;
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            targetObj = targetGUID;
            AssetID assetID = new AssetID { id = tutorialObject.Asset };
            asset = assetID;
            offset = TutorialManager.Instance.StringToVector3(tutorialObject.Offset);
            PlaceObjectInfo placeObjectInfo = new PlaceObjectInfo { childName = tutorialObject.Title, value1 = tutorialObject.Message, key = PlaceObjectKey.TextMeshPro };
            keyPairs.Add(placeObjectInfo);
            isObjectAutoPosition = TutorialManager.Instance.StringToBool(tutorialObject.SpecialFlag);
            if (attributes.ContainsKey(nameof(childName).ToLower()))
            {
                childName = attributes[nameof(childName).ToLower()];
            }
        }
    }
}