﻿

using System;
using UnityEngine;
using System.Collections.Generic;

namespace GS
{
   
    

    /// <summary>
    /// Base class for all Tutorial Actions 
    /// </summary>
    [System.Serializable]
    public class TutorialAction : ScriptableObject
    {
        /// <summary>
        /// On enetring into this Action
        /// </summary>
        public virtual void OnEnter()
        {
          
            
            
        }

        /// <summary>
        /// OnExiting this action
        /// </summary>
        public virtual void OnExit()
        {
           
        }


        /// <summary>
        /// this will be called every frame
        /// </summary>
        public virtual void Update()
        {
           
        }

        public void FindTarget(string targetId)
        {
            TutorialManager.Instance.FindTarget(targetId, OnTargetFound);
        }

        public void FindTargets(TargetGUID[] targetIds)
        {
            string[] ids = new string[targetIds.Length];
            for(int i=0;i<targetIds.Length;i++)
            {
                ids[i] = targetIds[i].id;
            }

            FindTargets(ids);
        }

        public void FindTargets(string[] targetIds)
        {
            TutorialManager.Instance.FindTargets(targetIds, OnTargetFound);
        }

        protected virtual void OnTargetFound(TutorialTarget targetObject)
        {

        }

        public virtual void Fill(TutorialObject tutorialObject, Dictionary<string,string> attributes)
        {

        }
    }
}