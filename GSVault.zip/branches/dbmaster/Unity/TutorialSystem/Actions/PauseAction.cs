﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    /// <summary>
    /// Pauses the Timescale on enter and resets back on exit
    /// </summary>
    public class PauseAction : BaseAction
    {
        private float previousTimeScale;

        public override void OnEnter()
        {
            base.OnEnter();

            previousTimeScale = Time.timeScale;
            Time.timeScale = 0.0f;
        }

        public override void OnExit()
        {
            base.OnExit();
            Time.timeScale = previousTimeScale;
        }
    }

}
