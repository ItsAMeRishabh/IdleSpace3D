﻿
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GS
{
    public class SwitchSceneAction : BaseAction
    {
        public string sceneName;

        public override void OnEnter()
        {
            base.OnEnter();

            // Switch Sene here
            SceneManager.LoadSceneAsync(sceneName);
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            sceneName = tutorialObject.Message;
        }
    }
}
