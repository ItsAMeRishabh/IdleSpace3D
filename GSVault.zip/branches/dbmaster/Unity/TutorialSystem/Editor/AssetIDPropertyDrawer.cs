﻿using GS;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

[CustomPropertyDrawer(typeof(GS.AssetID))]
public class AssetIDPropertyDrawer : PropertyDrawer
{
    bool isInitialized = false;
    private List<string> assetNames = new List<string>();
    
    private void Initialize()
    {
        var guids = AssetDatabase.FindAssets($"t:{typeof(TutorialSetupConfig)}");
        foreach (var t in guids)
        {
            var assetPath = AssetDatabase.GUIDToAssetPath(t);
            var asset = AssetDatabase.LoadAssetAtPath<TutorialSetupConfig>(assetPath);
            if (asset != null)
            {
                foreach (var name in asset.assets)
                {
                    assetNames.Add(name.id);
                }
            }
        }
        isInitialized  = true;
    }

    // Draw the property inside the given rect
    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        if (!isInitialized)
            Initialize();
        // EditorGUI.BeginProperty(position, label, property);

        EditorGUILayout.BeginHorizontal();
        var p = property.FindPropertyRelative(nameof(AssetID.id));

        EditorGUILayout.LabelField(property.displayName);
        int index = 0;
        for (int i=0;i< assetNames.Count;i++)
        {
            if(assetNames[i] == p.stringValue)
            {
                index = i;
                break;
            }
        }
        
        index = EditorGUILayout.Popup(index, assetNames.ToArray());
        p.stringValue = assetNames[index];
        EditorGUILayout.EndHorizontal();
    }

    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        return base.GetPropertyHeight(property, label);
    }
}
