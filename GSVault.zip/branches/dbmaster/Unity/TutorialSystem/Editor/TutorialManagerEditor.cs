﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace GS
{
    [CustomEditor(typeof(TutorialManager))]
    public class TutorialManagerEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            if (Application.isPlaying)
            {
                var manager = (TutorialManager)target;

                if(manager.IsTutorialActive)
                {
                    GUILayout.Label("Tutorial Started : " + manager.ActiveTutorialID);
                    GUILayout.Label("Current State : "+ manager.CurrentStateName);
                    GUILayout.Label("Old State : " + manager.PreviousStateName);
                }
                else
                {
                    GUILayout.Label("No Tutorial Active");
                }
                GUILayout.Label("Targets Detected : " + manager.TargetsCount);
            }
            base.OnInspectorGUI();
            Repaint();
        }
    }
}