﻿using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace GS.Tool
{
    public class StateNode
    {
        public TutorialState state;
        public Rect position;
        float pointSize = 12;
        public Rect fromPoint;
        public Rect toPoint;
        const float boxWidth = 250;
        const float boxHeight = 30;
        float rowHeight = 25;

        public List<Rect> actionPoints = new List<Rect>();
        public List<Rect> listenerPoints = new List<Rect>();

        public StateNode(TutorialState state, float x, float y)
        {
            this.state = state;
            int count = state.actions.Count;
            count += 1; // seperator
            count += state.listeners.Count;
            this.position = new Rect(x, y, boxWidth, boxHeight + count * rowHeight);
            fromPoint = new Rect(position.xMax - position.width * 0.5f - pointSize * 0.5f, position.y - pointSize * 0.5f, pointSize, pointSize);
            toPoint = new Rect(position.xMax - position.width * 0.5f - pointSize * 0.5f, position.y +position.height - pointSize * 0.5f, pointSize, pointSize);
            // fromPoint = new Rect(position.xMax - position.width * 0.5f - pointSize * 0.5f, position.y - pointSize * 0.5f, pointSize, pointSize);

            int actCount = 0;
            foreach (var act in state.actions)
            {
                Rect rect = new Rect(position.x + 5, position.y + 20 + actCount * rowHeight, position.width - 10, rowHeight);
                actCount++;
                actionPoints.Add(rect);
            }

            foreach (var act in state.listeners)
            {
                Rect rect = new Rect(position.x + 5, position.y + 25 + actCount * rowHeight, position.width - 10, rowHeight);
                listenerPoints.Add(rect);
                actCount++;
            }
        }

        public void OnGUI(GUIStyle style, GUIStyle actionStyle, GUIStyle leftStyle, GUIStyle rightStyle)
        {
            GUI.backgroundColor = Color.blue; 
            GUI.Box(fromPoint, "", leftStyle);
            GUI.backgroundColor = Color.blue;
            GUI.Box(toPoint, "", rightStyle);

            GUI.backgroundColor = Color.white;
            GUI.Box(position, state.stateId, style);

            GUI.backgroundColor = Color.gray;
            int count = 0;
            for (int i = 0; i < state.actions.Count; i++,count++)
            {
                if(actionPoints.Count > i && state.actions[i] != null)
                    GUI.Box(actionPoints[i], state.actions[i].name, actionStyle);
            }

            for(int i=0;i< listenerPoints.Count; i++)
            {
                var rect = listenerPoints[i];
                GUI.backgroundColor = Color.blue;
                var pointRect = GetListenerRect(rect);
                GUI.Box(pointRect, "", rightStyle);

                GUI.backgroundColor = Color.gray;
                if(state.listeners.Count > i && state.listeners[i] != null)
                    GUI.Box(rect, state.listeners[i].name, actionStyle);
                count++;
            }
        }

        public Rect GetListenerRect(Rect rect)
        {
            return new Rect(rect.xMax - pointSize * 0.5f, rect.center.y - pointSize * 0.5f, pointSize, pointSize);
        }
    }

    public class StateTransition
    {
        public Vector3 from;
        public Vector3 to;
        public bool isBezier = false;

        public StateTransition(Vector3 from, Vector3 to, bool isBezier = false)
        {
            this.from = from;
            this.to = to;
            this.isBezier = isBezier;
        }

        private void DrawBezier(Vector2 start, Vector2 end, Color color)
        {
            Handles.DrawBezier(start, end,
                 start - Vector2.left * 150f,
            end - Vector2.left * 250f,
            color,
            null,
            2f);
        }

        public void OnGUI()
        {
            if(isBezier)
                DrawBezier(from, to, Color.gray);
            else
                Handles.DrawLine(from, to);
            /* Handles.DrawBezier(from.toPoint.center, to.fromPoint.center,
                  from.toPoint.center - Vector2.left * 150f,
             to.fromPoint.center + Vector2.left * 150f,
             Color.white,
             null,
             2f);*/
        }
    }

    public class TutorialConfigWindow : EditorWindow
    {
        private TutorialSequenceConfig config = null;
        private Dictionary<string, StateNode> states = new Dictionary<string, StateNode>();
        private List<StateTransition> transitions = new List<StateTransition>();
        private Vector2 scrollPosition;

        //float xspacing = 50;
        float yspacing = 50;
        GUIStyle nodeStyle;
        GUIStyle leftNodeStyle;
        GUIStyle rightNodeStyle;
        GUIStyle actionStyle;


        public static void Open(TutorialSequenceConfig config)
        {
            TutorialConfigWindow window = GetWindow<TutorialConfigWindow>();
            window.Initialize(config);
            window.titleContent = new GUIContent("Tutorial");
        }

        private void OnEnable()
        {
            nodeStyle = new GUIStyle();
            nodeStyle.normal.background = EditorGUIUtility.Load("builtin skins/darkskin/images/animationeventbackground.png") as Texture2D;
            nodeStyle.border = new RectOffset(12, 12, 12, 12);
            nodeStyle.fontStyle = FontStyle.Bold;
            nodeStyle.normal.textColor = Color.white;
            nodeStyle.alignment = TextAnchor.UpperCenter;

            leftNodeStyle = new GUIStyle();
            leftNodeStyle.normal.background = EditorGUIUtility.Load("builtin skins/darkskin/images/btn left.png") as Texture2D;
            leftNodeStyle.border = new RectOffset(12, 12, 12, 12);

            rightNodeStyle = new GUIStyle();
            rightNodeStyle.normal.background = EditorGUIUtility.Load("builtin skins/darkskin/images/btn right.png") as Texture2D;
            rightNodeStyle.border = new RectOffset(12, 12, 12, 12);

            actionStyle = new GUIStyle();
            actionStyle.normal.background = EditorGUIUtility.Load("builtin skins/darkskin/images/pingbox.png") as Texture2D;
            actionStyle.border = new RectOffset(12, 12, 12, 12);
            actionStyle.normal.textColor = Color.gray;
            actionStyle.fontStyle = FontStyle.Italic;
            actionStyle.alignment = TextAnchor.MiddleCenter;

            Initialize(config);
        }

        public void Initialize(TutorialSequenceConfig config)
        {
            this.config = config;

            states.Clear();
            transitions.Clear();
            if (config != null && config.sequence != null)
            {
                float height = 0;
                for (int i = 0; i < config.sequence.states.Count; i++)
                {
                    var state = config.sequence.states[i];
                    var node = new StateNode(state, scrollPosition.x, scrollPosition.y + height);
                    height += node.position.height + yspacing;
                    states[state.stateId] = node;
                }

                foreach(var it in states)
                {
                    if(states.ContainsKey(it.Value.state.exitStateId))
                    transitions.Add(new StateTransition(it.Value.toPoint.center, states[it.Value.state.exitStateId].fromPoint.center, false));

                    int lCount = 0;
                    foreach (var listenerPoint in it.Value.listenerPoints)
                    {
                        if (it.Value.state.listeners.Count > lCount)
                        {
                            var listener = it.Value.state.listeners[lCount];
                            if (!string.IsNullOrEmpty(listener.overrideStateId) && states.ContainsKey(listener.overrideStateId)
                                && !it.Value.state.exitStateId.Equals(listener.overrideStateId))
                                transitions.Add(new StateTransition(it.Value.GetListenerRect(listenerPoint).center, states[listener.overrideStateId].fromPoint.center, true));
                            lCount++;
                        }
                    }
                }
            }
        }

        public void OnGUI()
        {
            DrawGrid(50, 0.3f, Color.gray);
            ProcessEvents(Event.current);
         
           

           // scrollPosition = EditorGUILayout.Begin();
            
            foreach (var it in transitions)
            {
                it.OnGUI();
            }

            foreach (var it in states)
            {
                it.Value.OnGUI(nodeStyle, actionStyle, leftNodeStyle, rightNodeStyle);
            }

            float windowWidth = 100;
            float windowHeight = Screen.height;
            Rect winRect = new Rect(Screen.width - windowWidth, 0, windowWidth, windowHeight);
            GUILayout.Window(1, winRect, WindowsCallback, "Actions");            
        }

        private void WindowsCallback(int id)
        {

        }

        private void DrawGrid(float gridSpacing, float gridOpacity, Color gridColor)
        {
            int widthDivs = Mathf.CeilToInt(position.width / gridSpacing);
            int heightDivs = Mathf.CeilToInt(position.height / gridSpacing);

            Handles.BeginGUI();
            Handles.color = new Color(gridColor.r, gridColor.g, gridColor.b, gridOpacity);

            Vector2 offset = Vector2.zero;//drag * 0.5f;
            Vector3 newOffset = new Vector3(offset.x % gridSpacing, offset.y % gridSpacing, 0);

            for (int i = 0; i < widthDivs; i++)
            {
                Handles.DrawLine(new Vector3(gridSpacing * i, -gridSpacing, 0) + newOffset, new Vector3(gridSpacing * i, position.height, 0f) + newOffset);
            }

            for (int j = 0; j < heightDivs; j++)
            {
                Handles.DrawLine(new Vector3(-gridSpacing, gridSpacing * j, 0) + newOffset, new Vector3(position.width, gridSpacing * j, 0f) + newOffset);
            }

            Handles.color = Color.white;
            Handles.EndGUI();
        }

        public void ProcessEvents(Event e)
        {
            switch (e.type)
            {
                case EventType.MouseDown:
                    break;
                case EventType.MouseDrag:
                    scrollPosition += e.delta;
                    Initialize(config);
                    GUI.changed = true;
                    break;
                case EventType.MouseUp:
                    
                    break;
            }
        }

        private void Update()
        {
            
            if(config == null)
            {
                config = Selection.activeObject as TutorialSequenceConfig;
                Initialize(config);
            }
            else
            {
                if (states.Count != config.sequence.states.Count)
                {
                    Initialize(config);
                }
                else
                {
                    foreach(var it in states)
                    {
                        /*if(it.Value.state.actions.Length != it.Value.actionPoints)
                        {
                            Initialize(config);
                        }*/
                    }
                }
            }
        }
    }
}
