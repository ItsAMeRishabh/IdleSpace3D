﻿using GS;
using GS.Tool;
using System.IO;
using UnityEditor;
using UnityEngine;
using System.Linq;
using System;
using System.Collections.Generic;

[CustomEditor(typeof(GS.TutorialSequenceConfig))]
public class TutorialConfigEditor : Editor
{
    public override void OnInspectorGUI()
    {
        GUILayout.BeginHorizontal("");

        if (GUILayout.Button("Visual"))
        {
            var config = (GS.TutorialSequenceConfig)target;
            TutorialConfigWindow.Open(config);
        }
        if (GUILayout.Button("Export"))
        {
            var config = (GS.TutorialSequenceConfig)target;
            var path = AssetDatabase.GetAssetPath(target);
            var outputPath = Path.ChangeExtension(path, ".txt");
            TutorialLoader.Save(outputPath, config.sequence);
            EditorUtility.DisplayDialog("Save As JSON", "Succesfully! Exported your tutorial at " + outputPath, "OK");
        }
        if(GUILayout.Button("Add Action"))
        {
            ActionCreateWindow.Open((GS.TutorialSequenceConfig)target);
        }

        GUILayout.EndHorizontal();
      

       
        base.OnInspectorGUI();
    }
}
