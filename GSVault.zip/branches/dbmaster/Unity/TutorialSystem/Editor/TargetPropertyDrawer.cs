﻿using GS;
using UnityEditor;
using UnityEngine;

[CustomPropertyDrawer(typeof(TargetGUID))]
public class TargetPropertyDrawer : PropertyDrawer
{ 
    // Draw the property inside the given rect
    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        // EditorGUI.BeginProperty(position, label, property);
        
        var p = property.FindPropertyRelative(nameof(TargetGUID.id));
        TutorialTarget target = null;
        float width = 120;
        Rect pos = new Rect(position.x, position.y, position.width - width + 10, position.height);
        var textValue = EditorGUI.TextField(pos, label, p.stringValue);

        Rect r = new Rect(position.x + position.width - width, position.y, width, position.height);
        target = EditorGUI.ObjectField(r, target, typeof(TutorialTarget), true) as TutorialTarget;
        if (target != null)
            p.stringValue = target.UniqueID;
        else
            p.stringValue = textValue;
        

        
       // EditorGUILayout.Space();
       // EditorGUILayout.Space();
    }

    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        return base.GetPropertyHeight(property, label);
    }
}
