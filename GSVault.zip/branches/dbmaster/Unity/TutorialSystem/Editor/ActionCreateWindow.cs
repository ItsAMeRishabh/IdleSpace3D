﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace GS
{
    public class ActionCreateWindow : EditorWindow
    {
        TutorialSequenceConfig config = null;
        private static List<BaseAction> actions;
        private static List<EndActionListener> listeners;

        public static void Open(TutorialSequenceConfig config)
        {
            ActionCreateWindow window = GetWindow<ActionCreateWindow>();
            window.titleContent = new GUIContent("Create an Action");
            window.Initialize(config);
        }

        private void Initialize(TutorialSequenceConfig config)
        {
            this.config = config;
        }

        private void OnEnable()
        {
            if (actions == null || listeners == null)
                FindActions();
        }

        private void FindActions()
        {
            actions = GetActions().ToList();
            listeners = GetEndListeners().ToList();
        }

        static IEnumerable<BaseAction> GetActions()
        {
            return AppDomain.CurrentDomain.GetAssemblies().SelectMany(assembly => assembly.GetTypes())
                    .Where(type => type.IsSubclassOf(typeof(BaseAction)))
            .Select(type => Activator.CreateInstance(type) as BaseAction);
        }

        static IEnumerable<EndActionListener> GetEndListeners()
        {
            return AppDomain.CurrentDomain.GetAssemblies().SelectMany(assembly => assembly.GetTypes())
                    .Where(type => type.IsSubclassOf(typeof(EndActionListener)))
            .Select(type => Activator.CreateInstance(type) as EndActionListener);
        }


        public void OnGUI()
        {
            if (actions == null || listeners == null || config == null)
                return;
           

            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical();
            GUILayout.Label("Actions");
            foreach (var action in actions)
            {
                if (GUILayout.Button(action.GetType().Name))
                {
                    var actionObject = ScriptableObject.CreateInstance(action.GetType());
                    actionObject.name = action.GetType().Name;
                    AssetDatabase.AddObjectToAsset(actionObject, config);
                    AssetDatabase.SaveAssets();
                }
            }

            GUILayout.EndVertical();

            GUILayout.BeginVertical();
            GUILayout.Label("End Listeners");
            foreach (var action in listeners)
            {
                if (GUILayout.Button(action.GetType().Name))
                {
                    var actionObject = ScriptableObject.CreateInstance(action.GetType());
                    actionObject.name = action.GetType().Name;
                    AssetDatabase.AddObjectToAsset(actionObject, config);
                    AssetDatabase.SaveAssets();
                }
            }

            GUILayout.EndVertical();

            GUILayout.EndHorizontal();

            GUILayout.Space(100);
            if (GUILayout.Button("Find New Actions"))
            {
                FindActions();
            }
        }
    }
}
