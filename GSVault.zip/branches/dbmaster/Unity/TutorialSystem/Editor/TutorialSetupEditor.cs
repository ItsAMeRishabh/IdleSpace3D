﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;


namespace GS
{
    [CustomEditor(typeof(TutorialSetupConfig), true)]
    public class TutorialSetupEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            var config = (TutorialSetupConfig)target;

            if (GUILayout.Button("Export Assets"))
            {
                SaveToFile(config.assets);

            }
            base.OnInspectorGUI();
        }

        public static void SaveToFile(TutorialAsset[] assets)
        {
            var content = new StringBuilder("ID,Description");
            foreach (var target in assets)
            {
                content.Append('\n').Append(target.id).Append(',').Append(target.description);
            }

            var folder = Application.dataPath;

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            var filePath = Path.Combine(folder, "TutorialAssets.csv");
            File.WriteAllText(filePath, content.ToString());
            AssetDatabase.SaveAssets();
        }
    }
}