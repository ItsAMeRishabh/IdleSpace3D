﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace GS
{
    public class GenerateTargetSheet 
    {
        [System.Serializable]
        public class TargetInfo
        {
            public string assetName;
            public string gameObjectName;
            public string targetGUID;
        }

        [MenuItem("Tools/ExportAllTutorialTargets")]
        public static void GenerateSheet()
        {
            List<TargetInfo> targetInfos = new List<TargetInfo>();

             List<EditorBuildSettingsScene> Scenes = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            List<string> scenePaths = Scenes.Select(scene => scene.path).ToList();
            foreach (string scenePath in scenePaths)
            {
                if (string.IsNullOrEmpty(scenePath))
                    continue;
                // Open a scene e.g. in single mode
                var currentScene = EditorSceneManager.OpenScene(scenePath);

                /* Do your calculation for currentScene */
                TutorialTarget[] targetsList = GameObject.FindObjectsOfType<TutorialTarget>();
                Debug.Log("<color=red>Scene Name->" + scenePath + "</color>");
                foreach (var item in targetsList)
                {
                    TargetInfo targetInfo = new TargetInfo();
                    targetInfo.assetName = currentScene.name;
                    targetInfo.gameObjectName = item.name;
                    targetInfo.targetGUID = item.UniqueID;
                    targetInfos.Add(targetInfo);
                    Debug.Log("Targets->" + item.UniqueID + " Name->" + item.name);
                }
                // Finally Close and remove the scene
                EditorSceneManager.CloseScene(currentScene, false);
            }
            // you might be doing changes to an asset you want to save when done
           

            #region Finding TutorialTargets from prefabs
            Debug.Log("Finding all Prefabs that have an Tutorial target Component...");
            //new[] { "Assets/Prefabs" }
            string[] guids = AssetDatabase.FindAssets("t:GameObject", new[] { "Assets/Prefabs" });

            string[] allAssetsInproject = AssetDatabase.GetAllAssetPaths();
            List<string> result = new List<string>();
            foreach (string s in allAssetsInproject)
            {
                if (s.Contains(".prefab")) result.Add(s);
            }
            foreach (var id in result)
            {
                Object[] objects = AssetDatabase.LoadAllAssetsAtPath(id);

                foreach (Object obj in objects)
                {
                    if (obj != null)
                    {
                        string type = obj.GetType().Name;
                        if (type == "TutorialTarget")
                        {
                            TutorialTarget tar = obj as TutorialTarget;
                            TargetInfo targetInfo = new TargetInfo();
                            targetInfo.assetName = id;
                            targetInfo.gameObjectName = tar.name;
                            targetInfo.targetGUID = tar.UniqueID;
                            targetInfos.Add(targetInfo);
                            Debug.Log("<color=yellow>" + tar.UniqueID + " name->" + tar.name + "</color>");
                        }
                    }
                }
            }
            #endregion
            SaveToFile(targetInfos);
        }

        public static string[] GetAllPrefabs()
        {
            string[] temp = AssetDatabase.GetAllAssetPaths();
            List<string> result = new List<string>();
            foreach (string s in temp)
            {
                if (s.Contains(".prefab")) result.Add(s);
            }
            return result.ToArray();
        }

        public static void SaveToFile(List<TargetInfo> targetInfos)
        {
            var content = new StringBuilder("AssetName,GameObjectName,TargetGUID");
            foreach (var target in targetInfos)
            {
                content.Append('\n').Append(target.assetName).Append(',').Append(target.gameObjectName).Append(',').Append(target.targetGUID);
            }

            var folder = Application.dataPath;

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            var filePath = Path.Combine(folder, "TargetInfo.csv");
            File.WriteAllText(filePath, content.ToString());
            AssetDatabase.SaveAssets();
        }
    }
}
