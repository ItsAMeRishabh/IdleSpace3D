﻿using System;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(GS.TutorialAction), true)]
public class TutorialActionEditor : Editor
{
    public override void OnInspectorGUI()
    {
        var action = (GS.TutorialAction)target;

        GUILayout.BeginHorizontal();
        if (action != null)
        {
            GUILayout.Label("Name:");
            var previousName = action.name;
            action.name = GUILayout.TextField(action.name);
            if(previousName != action.name)
            {
                AssetDatabase.Refresh();
            }
        }
        if (GUILayout.Button("Delete"))
        {
            
            if(action != null)
            {
                AssetDatabase.RemoveObjectFromAsset(action);
                AssetDatabase.SaveAssets();
            }
        }
        GUILayout.EndHorizontal();
        base.OnInspectorGUI();
    }
}
