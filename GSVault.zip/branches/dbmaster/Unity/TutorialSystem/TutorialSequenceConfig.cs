﻿using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    [System.Serializable]
    public class TutorialSequence
    {
        public bool enableSkipButton = false;
        public List<TutorialState> states;
    }

    [CreateAssetMenu(menuName = "Tutorial/SequenceConfig")]
    public class TutorialSequenceConfig : ScriptableObject
    {
        public TutorialSequence sequence;
    }
}
