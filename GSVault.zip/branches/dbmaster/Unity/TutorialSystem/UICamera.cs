﻿using System.Collections;
using UnityEngine;

namespace GS
{
    [RequireComponent(typeof(Camera))]
    public class UICamera : MonoBehaviour
    {
        private Camera uiCamera;
        public static UICamera Instance { get; private set; }
        public Camera CamObject { get { return uiCamera; } }
        private void Awake()
        {
            Instance = this;
            gameObject.layer = LayerMask.NameToLayer("UI");
            uiCamera = GetComponent<Camera>();
            //camera.clearFlags = CameraClearFlags.Depth;
            uiCamera.enabled = false;
            TutorialManager.Instance.GetCanvas().SetCamera(uiCamera);
        }

        private void Start()
        {
            uiCamera.enabled = true;
        }
    }
}
