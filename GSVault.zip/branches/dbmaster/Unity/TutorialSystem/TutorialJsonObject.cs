﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialJsonObject 
{
    public List<TutorialObject> rows = new List<TutorialObject>();
}

public class TutorialObject
{
    public string TutorialID;
    public string EnableSkipButton;
    public string IsFirstStep;
    public string Step;
    public string ActionListenerType;
    public string TargetName;
    public string TargetID;
    public string Message;
    public string EnableTarget;
    public string DisableAllButtons;
    public string SpecialFlag;
    public string Asset;
    public string Offset;
    public string Title;
    public string Attributes;
    public string CameraName;
    public string CameraID;
    public string ExitStep;
}
