﻿using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    [RequireComponent(typeof(Canvas))]
    public class TutorialCanvas : MonoBehaviour
    {
        public GameObject tintBG;
        
        private Button skipButton;

        private void Awake()
        {
            var buttonGo = transform.FindChildGameObject("skipButton", true);
            if(buttonGo != null)
            {
                skipButton = buttonGo.GetComponent<Button>();
                ShowSkipButton(false);
            }
        }

        void Start()
        {
            ShowTintBG(false);
        }

        void Update()
        {

        }

        public void ShowSkipButton(bool isActive)
        {
            skipButton?.gameObject.SetActive(isActive);
        }

        public void ShowTintBG(bool isActive)
        {
            tintBG.SetActive(isActive);
        }

        public void AddSkipButton(GameObject skipButtonPrefab)
        {
            if (skipButton != null)
            {
                Destroy(skipButton.gameObject);
                skipButton = null;
            }
            var skipGo = GameObject.Instantiate(skipButtonPrefab, transform);
            if(skipGo)
            {
                skipButton = skipGo.transform.GetOrAddComponent<Button>();
                skipButton.onClick.AddListener(() => { TutorialManager.Instance.ForceEndTutorial(); });
            }
        }

        public void SetTintColor(Color color)
        {
            if(tintBG != null)
                tintBG.GetComponent<Image>().color = color;
        }  
        
        
        public void SetResolution(Vector2 resolution)
        {
            CanvasScaler canvas = GetComponent<CanvasScaler>();
            if(canvas != null)
                canvas.referenceResolution= resolution;
        }

        public void SetCamera(Camera camera)
        {
            Canvas canvas = GetComponent<Canvas>();
            canvas.worldCamera = camera;
        }
    }
}