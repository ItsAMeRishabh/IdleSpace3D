﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using GS;
using System;
using System.Text.RegularExpressions;
using System.Linq;

namespace GS.Unity
{
    public class TutorialJsonOperator : SingleTon<TutorialJsonOperator>
    {
        private const string jsonFileName = "GameContent/TutorialDetails/NewTutorials/AllTutorialJsonData";
        private TutorialJsonObject tutorialJsonObject;
        private static Dictionary<string, TutorialSequence> tutorialSequencesMap = new Dictionary<string, TutorialSequence>();
        private Dictionary<string, string> attibutes = new Dictionary<string, string>();
        private string currentKey = string.Empty;

        private void Awake()
        {
            DoNotDestroyOnLoad = true;
        }

        void Start()
        {
            //tutorialSequencesMap.Clear();
            //tutorialJsonObject = new TutorialJsonObject();
            //tutorialJsonObject.rows = ReadJsonFromFile(jsonFileName);
            //SortRows();
            //FillData();
        }

        private List<TutorialObject> ReadJsonFromFile(string fileName)
        {
            TextAsset asset = Resources.Load<TextAsset>(fileName);
            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All, NullValueHandling = NullValueHandling.Ignore };
            return JsonConvert.DeserializeObject<List<TutorialObject>>(asset.text, jsonSerializerSettings);
        }

        private List<TutorialObject> ReadJsonFromString(string jsonString)
        {
            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All, NullValueHandling = NullValueHandling.Ignore };
            return JsonConvert.DeserializeObject<List<TutorialObject>>(jsonString, jsonSerializerSettings);
        }

        private void FillData()
        {
            string previousSequenceName = string.Empty;

            List<TutorialState> sequenceStates = new List<TutorialState>();
            TutorialSequence tutorialSequence;
            TutorialState state = new TutorialState();
            TutorialAction actionListnerObject = new TutorialAction();

            foreach (var row in tutorialJsonObject.rows)
            {
                if (row.TutorialID != previousSequenceName)
                {
                    tutorialSequence = new TutorialSequence();
                    currentKey = row.TutorialID;
                    tutorialSequencesMap.Add(currentKey, tutorialSequence);
                    tutorialSequence.states = new List<TutorialState>();
                    sequenceStates = tutorialSequence.states;
                    tutorialSequence.enableSkipButton = TutorialManager.Instance.StringToBool(row.EnableSkipButton);
                    previousSequenceName = row.TutorialID;
                }

                if (row.Step != state.stateId)
                {
                    state = new TutorialState();
                    state.stateId = row.Step;
                    state.exitStateId = row.ExitStep;
                    sequenceStates.Add(state);
                    actionListnerObject.name = string.Empty;
                }

                if (row.ActionListenerType != actionListnerObject.name)
                {
                    actionListnerObject = (TutorialAction)Activator.CreateInstance(GetTutorialObject(row.ActionListenerType));
                    actionListnerObject.name = row.ActionListenerType;
                    if (actionListnerObject is BaseAction)
                    {
                        state.actions.Add(actionListnerObject);
                    }
                    else
                    {
                        state.listeners.Add(actionListnerObject as EndActionListener);
                        if (!row.ExitStep.Equals(string.Empty) && !row.ExitStep.Equals(state.exitStateId))
                        {
                            state.listeners[state.listeners.Count - 1].overrideStateId = row.ExitStep;
                        }
                    }
                }
                BreakIntoAttributes(row.Attributes);
                actionListnerObject.Fill(row, attibutes);
            }
        }

        private Type GetTutorialObject(string key)
        {
            if (ActionListnerMap.ContainsKey(key))
            {
                return ActionListnerMap[key];
            }
            return null;
        }

        private void BreakIntoAttributes(string attributeJson)
        {
            attibutes.Clear();
            if (!string.IsNullOrEmpty(attributeJson))
            {
                string[] splitArray = Regex.Split(attributeJson, @"(?<!,[^(]+\([^)]+),");
                foreach (var item in splitArray)
                {
                    string[] keyValue = item.Split(':');
                    attibutes.Add(keyValue[0].ToLower(), keyValue[1]);
                }
            }
        }

        public TutorialSequence GetSequence(string jsonString)
        {
            if (jsonString.Equals(string.Empty))
            {
                return null;
            }
            tutorialSequencesMap.Clear();
            tutorialJsonObject = new TutorialJsonObject();
            tutorialJsonObject.rows = ReadJsonFromString(jsonString);
            SortRows();
            FillData();
            return tutorialSequencesMap[currentKey];
        }

        private void SortRows()
        {
            string firstStepName = tutorialJsonObject.rows.Where(i => i.IsFirstStep.ToUpper().Equals("TRUE")).Select(t => t.Step).FirstOrDefault().ToString();
            List<TutorialObject> sortedFirstStepList = tutorialJsonObject.rows.Where(i => i.Step == firstStepName).OrderBy(l => l.ActionListenerType).ToList();
            List<TutorialObject> sortedRestStepList = tutorialJsonObject.rows.Where(i => i.Step != firstStepName).OrderBy(l => l.Step).ThenBy(m => m.ActionListenerType).ToList();
            tutorialJsonObject.rows = sortedFirstStepList.Concat(sortedRestStepList).ToList();
        }

        public Dictionary<string, Type> ActionListnerMap = new Dictionary<string, Type>
    {
       {"ApplyTextAction"                ,typeof(ApplyTextAction)},
       {"EnableTargetAction"             ,typeof(EnableTargetAction)},
       {"HighlightAction"                ,typeof(HighlightAction)},
       {"HighlightChildAction"           ,typeof(HighlightChildAction)},
       {"MessageAction"                  ,typeof(MessageAction)},
       {"PauseAction"                    ,typeof(PauseAction)},
       {"PlaceObjectAction"              ,typeof(PlaceObjectAction)},
       {"SwitchSceneAction"              ,typeof(SwitchSceneAction)},
       {"SwitchUIScreenAction"           ,typeof(SwitchUIScreenAction)},
       {"ButtonClickListener"            ,typeof(ButtonClickListener)},
       {"EndActionListener"              ,typeof(EndActionListener)},
       {"KeyCodeListener"                ,typeof(KeyCodeListener)},
       {"SceneChangedListener"           ,typeof(SceneChangedListener)},
       {"SwipeListener"                  ,typeof(SwipeListener)},
       {"TapListener"                    ,typeof(TapListener)},
       {"Target3DClickListener"          ,typeof(Target3DClickListener)},
       {"TimerListener"                  ,typeof(TimerListener)},
       {"UITargetClickListener"          ,typeof(UITargetClickListener)},
       {"WaitForEventEndListener"        ,typeof(WaitForEventEndListener)},
       {"ButtonChildClickListener"       ,typeof(ButtonChildClickListener)},
       {"TargetScrollAction"             ,typeof(TargetScrollAction)}
    };
    }
}