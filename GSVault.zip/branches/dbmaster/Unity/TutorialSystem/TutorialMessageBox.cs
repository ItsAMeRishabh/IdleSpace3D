﻿using GS.UI;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    public enum HorizontalAlign
    {
        Left,
        Center,
        Right
    }

    public enum VerticalAlign
    {
        Top,
        Center,
        Bottom
    }

    public class TutorialMessageBox : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI messageText;
        [SerializeField] private TextMeshProUGUI titleText;

        private RectTransform rectTransform;

        private void Awake()
        {
            rectTransform = GetComponent<RectTransform>();

            var canvas = gameObject.GetComponent<Canvas>();
            if (canvas == null)
                canvas = gameObject.AddComponent<Canvas>();

            var raycaster = gameObject.GetComponent<GraphicRaycaster>();
            if (raycaster == null)
                gameObject.AddComponent<GraphicRaycaster>();

            canvas.overrideSorting = true;
            canvas.sortingOrder = 101;
        }

        public void SetMessage(string title, string message)
        {
            messageText.text = message;
            titleText.text = title;
        }


        IEnumerator ModifySize(GameObject target, MessageBoxPosition pivot, Vector2 offsetDist)
        {
            yield return new WaitForEndOfFrame();

            Vector2 boxSizeSS = messageText.rectTransform.sizeDelta;
            rectTransform.sizeDelta = boxSizeSS + new Vector2(Screen.width * 0.2f, Screen.height * 0.1f);
            boxSizeSS = rectTransform.sizeDelta;
            boxSizeSS /= 2;

            Vector2 targetSizeSS;

            Vector3 position;
            Vector3 posOffset = Vector3.zero;

            bool isUI = target.GetComponent<TutorialTarget>().IsUI;

            position = Camera.main.WorldToScreenPoint(target.transform.position);

            targetSizeSS = isUI ? target.GetComponent<RectTransform>().sizeDelta : CalculateScreenSize(target);
            targetSizeSS /= 2;

            Vector3 sizeOffset = boxSizeSS + targetSizeSS;
            switch (pivot)
            {
                case MessageBoxPosition.Top:

                    posOffset.y = (sizeOffset.y);

                    break;

                case MessageBoxPosition.TopLeft:

                    posOffset.x = -(sizeOffset.x);
                    posOffset.y = (sizeOffset.y);

                    break;

                case MessageBoxPosition.Left:

                    posOffset.x = -(sizeOffset.x);

                    break;

                case MessageBoxPosition.BottomLeft:

                    posOffset.x = -(sizeOffset.x);
                    posOffset.y = -(sizeOffset.y);


                    break;

                case MessageBoxPosition.Bottom:

                    posOffset.y = -(sizeOffset.y);

                    break;

                case MessageBoxPosition.BottomRight:

                    posOffset.x = (sizeOffset.x);
                    posOffset.y = -(sizeOffset.y);

                    break;

                case MessageBoxPosition.Right:

                    posOffset.x = (sizeOffset.x);

                    break;

                case MessageBoxPosition.TopRight:

                    posOffset.x = (sizeOffset.x);
                    posOffset.y = (sizeOffset.y);

                    break;

                default:

                    //Case Center will be the default case

                    break;

            }

            Vector3 screenPt = PositionToCanvas(position);

            screenPt += posOffset;

            rectTransform.anchoredPosition = screenPt;

            Vector3 localPos = rectTransform.localPosition;
            localPos.z = 0;
            rectTransform.localPosition = localPos;
        }



        Vector2 ScaledScreenPos(Vector3 screenPos, Vector2 refRes, float aspectRat)
        {
            float matchProp = Mathf.Lerp(refRes.x / Screen.width, refRes.y / Screen.height, aspectRat);
            screenPos *= matchProp;
            return new Vector2(screenPos.x, screenPos.y);
        }

        Vector3 PositionToCanvas(Vector3 screenPos)
        {
            CanvasScaler canvasScaler = TutorialManager.Instance.GetCanvas().GetComponent<CanvasScaler>();
            Vector2 refRes = canvasScaler.referenceResolution;
            float match = canvasScaler.matchWidthOrHeight;
            screenPos = ScaledScreenPos(screenPos, refRes, match);
            return screenPos;
        }

        Vector2 CalculateScreenSize(GameObject obj)
        {
            var bounds = obj.GetComponent<MeshRenderer>().bounds;
            Vector2 size;

            Vector2 min = Camera.main.WorldToScreenPoint(bounds.min);
            Vector2 max = Camera.main.WorldToScreenPoint(bounds.max);

            size = max - min;

            Log.Print("Size = " + size, LogFilter.Game);

            return size;

        }
        public void ResizeBox(GameObject target, MessageBoxPosition pivot, Vector2 offsetDist)
        {
            //Doing it in coroutine coz the UI updation will take a frame to happen
            StartCoroutine(ModifySize(target, pivot, offsetDist));
        }

        public void SetPosition(Vector3 parentPosition, HorizontalAlign horizontal, VerticalAlign vertical, Vector3 offset)
        {
            float x = 0.0f;
            float y = 0.0f;

            switch (horizontal)
            {
                case HorizontalAlign.Center:
                    x = 0.5f;
                    break;
                case HorizontalAlign.Right:
                    x = 1;
                    break;
                case HorizontalAlign.Left:
                    x = 0;
                    break;
            }

            switch (vertical)
            {
                case VerticalAlign.Center:
                    y = 0.5f;
                    break;
                case VerticalAlign.Top:
                    y = 1;
                    break;
                case VerticalAlign.Bottom:
                    y = 0;
                    break;
            }

            rectTransform.pivot = new Vector2(x, y);
            rectTransform.localPosition = parentPosition + offset;
        }
    }
}
