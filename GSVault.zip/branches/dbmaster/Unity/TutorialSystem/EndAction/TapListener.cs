﻿using GS.GameEvents;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    public class TapListener : EndActionListener
    {
        public float timer = 0.0f;
        public const float delayTime = 0.1f;

        public override void OnEnter()
        {
            Utils.EM.AddListener<TAPEvent>(OnTapListener);
            timer = 0.0f;
        }

        public override void OnExit()
        {
            base.OnExit();
            Utils.EM.RemoveListener<TAPEvent>(OnTapListener);
        }

        private void OnTapListener(TAPEvent e)
        {
            if(timer >= delayTime)
                CompleteAction();
        }

        public override void Update()
        {
            timer += Time.unscaledDeltaTime;
            base.Update();
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            timer = float.Parse(tutorialObject.Message);
        }
    }
}