﻿
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GS
{
    public class SceneChangedListener : EndActionListener
    {
        public string sceneName;

        public override void OnEnter()
        {
            base.OnEnter();
            SceneManager.sceneLoaded += (scene, mode) =>
            {
                if (sceneName == scene.name)
                    CompleteAction();
            };
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            sceneName = tutorialObject.Message;
        }
    }
}
