﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace GS
{
    public class ButtonChildClickListener : EndActionListener
    {
        public TargetGUID parentTarget;
        public List<string> childNames = new List<string>();

        private List<Button> childButtons = new List<Button>();
        private UnityAction callback;


        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);

            if (targetObject != null)
            {
                Button[] childs = targetObject.GetComponentsInChildren<Button>();
                childButtons.Clear();
                foreach (var click in childs)
                {
                    if (click && childNames.Contains(click.name))
                    {
                        click.onClick.AddListener(callback);
                        childButtons.Add(click);
                    }
                }
            }
        }

        public override void OnEnter()
        {
            base.OnEnter();
            callback = CompleteAction;

            FindTarget(parentTarget.id);
        }

        public override void OnExit()
        {
            base.OnExit();
            foreach (var ch in childButtons)
            {
                ch.onClick.RemoveListener(callback);
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            parentTarget = targetGUID;
            childNames.Add(tutorialObject.Message);
        }
    }
}
