﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    public class ButtonClickListener : EndActionListener
    {
        public TargetGUID buttonTarget;
        private UnityEngine.Events.UnityAction callback;
        private Button buttonObject;

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);
            if (targetObject != null)
            {
                buttonObject = targetObject.GetComponent<Button>();
                if (buttonObject)
                    buttonObject.onClick.AddListener(callback);
            }
        }

        public override void OnEnter()
        {
            base.OnEnter();
            callback = CompleteAction;
            FindTarget(buttonTarget.id);
        }

        public override void OnExit()
        {
            base.OnExit();
            buttonObject?.onClick.RemoveListener(callback);
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            buttonTarget = targetGUID;
        }
    }
}
