﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace GS
{
    public class Target3DClickListener : EndActionListener
    {
        [SerializeField] private TargetGUID target;

        [Header("Checks with Main camera. If empty")]
        [SerializeField] private TargetGUID camera;

        private Camera targetCamera;
        private TutorialTarget targetObject;


        public override void OnEnter()
        {
            base.OnEnter();

            targetCamera = Camera.main;
            FindTarget(target.id);
            FindTarget(camera.id);
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);

            if(targetObject.UniqueID == camera.id)
            {
                var c = targetObject.GetComponent<Camera>();
                if (c != null)
                    targetCamera = c;
            }
            else if(targetObject.UniqueID == target.id)
            {
                this.targetObject = targetObject;
            }
        }

        public override void Update()
        {
            base.Update();
            if (Input.GetMouseButtonUp(0))
            {
                if(targetObject != null && !targetObject.IsUI && targetCamera != null)
                {
                    RaycastHit hit;
                    Ray ray = targetCamera.ScreenPointToRay(Input.mousePosition);
                    if (Physics.Raycast(ray, out hit))
                    {
                        if (hit.collider != null)
                        {
                            if (targetObject.gameObject == hit.collider.gameObject)
                                CompleteAction();
                        }
                    }
                }
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            target = targetGUID;

            TargetGUID cameraGUID = new TargetGUID { id = tutorialObject.CameraID };
            camera = cameraGUID;
        }
    }
}
