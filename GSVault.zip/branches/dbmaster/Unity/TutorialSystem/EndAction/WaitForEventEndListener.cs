﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    /// <summary>
    /// Waiting for Event
    /// </summary>
    //[CreateAssetMenu(fileName = "WaitForEventEndListener", menuName = "EndListener/WaitForEventEndListener")]
    public class WaitForEventEndListener : EndActionListener
    {
        [Header("Make sure this event Name should be unique")]
        public string eventName;

        public override void OnEnter()
        {
            base.OnEnter();
            TutorialManager.Instance.EventCallBack += OnTutorialEvent;
        }

        public override void OnExit()
        {
            base.OnExit();
            TutorialManager.Instance.EventCallBack -= OnTutorialEvent;
        }

        protected void OnTutorialEvent(string eventName, GameObject gameObject)
        {
            if(this.eventName.Equals(eventName))
            {
                if (gameObject != null)
                {
                    var tutTarget = gameObject.transform.GetOrAddComponent<TutorialTarget>();
                    tutTarget.OverrideUniqueID(eventName);
                    TutorialManager.Instance.AddTarget(tutTarget);
                }

                CompleteAction();
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            eventName = tutorialObject.Title;
        }
    }
}