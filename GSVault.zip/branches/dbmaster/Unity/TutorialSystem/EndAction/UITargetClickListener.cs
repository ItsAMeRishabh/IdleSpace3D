﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;

namespace GS
{
    public class UITargetClickListener : EndActionListener
    {
        public TargetGUID target;
        public bool ignoreRaycastOnTarget = false;
        private TutorialTarget targetObject;

        public override void Update()
        {
            base.Update();
            if (Input.GetMouseButtonUp(0) && targetObject != null)
            {
                if (targetObject.IsUI)
                {
                    if (ignoreRaycastOnTarget)
                    {
                        CompleteAction();
                        return;
                    }
                    PointerEventData cursor = new PointerEventData(EventSystem.current);
                    cursor.position = Input.mousePosition;
                    List<RaycastResult> objectsHit = new List<RaycastResult>();
                    EventSystem.current.RaycastAll(cursor, objectsHit);

                    var res = objectsHit.FirstOrDefault();
                    if (res.isValid && res.gameObject == targetObject.gameObject)
                    {
                        CompleteAction();
                    }
                }
            }
        }

        public override void OnEnter()
        {
            base.OnEnter();
            FindTarget(target.id);
        }

        protected override void OnTargetFound(TutorialTarget targetObject)
        {
            base.OnTargetFound(targetObject);
            this.targetObject = targetObject;
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            TargetGUID targetGUID = new TargetGUID { id = tutorialObject.TargetID };
            target = targetGUID;
            ignoreRaycastOnTarget = TutorialManager.Instance.StringToBool(tutorialObject.SpecialFlag);
        }
    }
}
