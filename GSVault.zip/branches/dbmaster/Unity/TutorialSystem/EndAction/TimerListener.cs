﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    public class TimerListener : EndActionListener
    {
        public float maxTimeInSecs = 0;
        public bool UseUnScaled = true;

        private float timer = 0;

        public override void OnEnter()
        {
            base.OnEnter();
            timer = 0;
        }

        public override void Update()
        {
            timer += UseUnScaled ? Time.unscaledDeltaTime : Time.deltaTime;

            if (timer >= maxTimeInSecs)
            {
                CompleteAction();
            }
        }

        public override void OnExit()
        {
            base.OnExit();
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            maxTimeInSecs = float.Parse(tutorialObject.Title);
            UseUnScaled = TutorialManager.Instance.StringToBool(tutorialObject.SpecialFlag);
        }
    }
}