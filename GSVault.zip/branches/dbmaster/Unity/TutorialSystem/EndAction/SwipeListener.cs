﻿using GS.GameConsts;
using GS.GameEvents;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    public class SwipeListener : EndActionListener
    {
        public SwipeDirection directon = SwipeDirection.None;

        public override void OnEnter()
        {
            Utils.EM.AddListener<SwipeEvent>(OnSwipeListener);
        }

        public override void OnExit()
        {
            base.OnExit();
            Utils.EM.RemoveListener<SwipeEvent>(OnSwipeListener);
        }

        private void OnSwipeListener(SwipeEvent e)
        {
            if(e.swipeDirection == SwipeDirection.None || e.swipeDirection == directon)
                CompleteAction();
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            SwipeDirection swipeDirection = (SwipeDirection)System.Enum.Parse(typeof(SwipeDirection), tutorialObject.Message);
            directon = swipeDirection;
        }
    }
}