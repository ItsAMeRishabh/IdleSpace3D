﻿using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    public class KeyCodeListener : EndActionListener
    {
        public KeyCode key = KeyCode.None;
        public bool isKeyReleased = true;


        public override void Update()
        {
            if(isKeyReleased)
            {
                if(Input.GetKeyUp(key))
                {
                    CompleteAction();
                }
            }
            else
            {
                if(Input.GetKeyDown(key))
                {
                    CompleteAction();
                }
            }
        }

        public override void Fill(TutorialObject tutorialObject, Dictionary<string, string> attributes)
        {
            key = (KeyCode)System.Enum.Parse(typeof(KeyCode), tutorialObject.Message);
            isKeyReleased = TutorialManager.Instance.StringToBool(tutorialObject.SpecialFlag);
        }
    }
}