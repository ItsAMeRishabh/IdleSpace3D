﻿using System;
using UnityEngine;

namespace GS
{
    [Serializable]
    public class EndActionListener : TutorialAction
    {
        [Header("Optional, Overrides the State->ExitID")]
        public string overrideStateId;
        public bool IsCompleted { get; protected set; }
     
        public override void OnEnter()
        {
            base.OnEnter();
            IsCompleted = false;
        }

        public virtual void CompleteAction()
        {
            IsCompleted = true;
        }
    }
}
