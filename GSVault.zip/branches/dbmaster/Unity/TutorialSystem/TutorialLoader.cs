﻿using GS.SimpleJSON;
using Newtonsoft.Json;
//using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace GS
{
    public class TutorialLoader
    {

        public static TutorialSequence Load(string filePath)
        {
            TextAsset asset = Resources.Load<TextAsset>(filePath);

            TutorialSequence currentSequence = new TutorialSequence();// JsonUtility.FromJson<TutorialSequence>(asset.text);
            JSONNode jsonNode = JSON.Parse(asset.text);

            var statesNode = jsonNode[nameof(TutorialSequence.states)];

            var stateJson = statesNode.AsArray;

            currentSequence.states = new List<TutorialState>();
            for (int k = 0; k < stateJson.Count; k++)
            {
                TutorialState state = new TutorialState();
                currentSequence.states.Add(state);
                if (stateJson != null && k < stateJson.Count)
                {
                    var stJson = stateJson[k];

                    if (stJson != null)
                    {
                        state.stateId = stJson[nameof(TutorialState.stateId)];
                        state.exitStateId = stJson[nameof(TutorialState.exitStateId)];

                        var actionsJson = stJson[nameof(TutorialState.actions)];
                        if (actionsJson != null)
                            state.actions = GetActionsFromNode(actionsJson);
                        var listenerJson = stJson[nameof(TutorialState.listeners)];
                        if (listenerJson != null)
                        {
                            var listeners = GetActionsFromNode(listenerJson);

                            state.listeners = new List<EndActionListener>();
                            for (int i = 0; i < listeners.Count; i++)
                                state.listeners[i] = (EndActionListener)listeners[i];
                        }
                    }
                }
            }
            return currentSequence;
        }

        public static TutorialSequence LoadFromText(string text)
        {
            TutorialSequence sequence = null;
            if (!string.IsNullOrEmpty(text))
            {
                JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };
                sequence = JsonConvert.DeserializeObject<TutorialSequence>(text, settings);
            }
            return sequence;
        }

        public static TutorialSequence LoadFromJson(string filePath)
        {
            TextAsset asset = Resources.Load<TextAsset>(filePath);
            if (asset != null)
            {
                return LoadFromText(asset.text);
            }
            return null;
        }

        public static void Save(string filePath, TutorialSequence sequence)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Objects, ReferenceLoopHandling = ReferenceLoopHandling.Ignore };
            var jsonString = JsonConvert.SerializeObject(sequence, settings);

            StreamWriter writer = new StreamWriter(filePath, false);


            writer.Write(jsonString);
            writer.Close();
        }

        private static List<TutorialAction> GetActionsFromNode(JSONNode actionsJson)
        {
            List<TutorialAction> derivedActions = new List<TutorialAction>();
            var actionArray = actionsJson.AsArray;
            for (int i = 0; i < actionArray.Count; i++)
            {
                if (actionArray != null && i < actionArray.Count)
                {
                    var actionNode = actionArray[i];

                    if (actionNode != null)
                    {
                        /* var actionName = actionNode[nameof(TutorialAction.actionClassName)];

                         if (actionName != null)
                         {
                             Type classType = Type.GetType("GS." + actionName.Value);
                             var derivedAction = (TutorialAction)Activator.CreateInstance(classType);
                             derivedAction = derivedAction.LoadJson(actionArray[i].ToString());
                             derivedActions.Add(derivedAction);
                         }*/
                    }
                }
            }

            return derivedActions;
        }
    }
}
