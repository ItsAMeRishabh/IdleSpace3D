﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    [System.Serializable]
    public class TutorialAsset
    {
        public string id;
        public GameObject asset;
        public string description;
    }

    [CreateAssetMenu(fileName = "TutorialSetup", menuName = "Tutorial/TutorialSetup")]
    public class TutorialSetupConfig : ScriptableObject
    {
        public Vector2 canvasResolution = new Vector2(1080, 1920);
        public Color tintColor;
        public GameObject skipPrefab;
        public TutorialAsset[] assets;

        public GameObject GetAssetById(string id)
        {
            GameObject finalAsset = null;
            foreach (var asset in assets)
            {
                if (asset.id == id)
                {
                    finalAsset = asset.asset;
                    break;
                }
            }
            return finalAsset;
        }
    }
}
