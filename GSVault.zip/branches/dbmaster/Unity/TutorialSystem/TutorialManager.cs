using UnityEngine;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using System;
using GS.Unity;
using System.Collections;

namespace GS
{
    /// <summary>
    /// Holds the tutorial config file and manages the tutorials
    /// </summary>
    public class TutorialManager : SingleTon<TutorialManager>
    {
        private Dictionary<string, TutorialTarget> targets = new Dictionary<string, TutorialTarget>();
        private TutorialCanvas canvas;
        private Camera tutorial3DCamera;
        public Action<string> OnTutorialComplete;
        public Action<string> OnTutorialStart;
        private Dictionary<string, Action<TutorialTarget>> targetCallbacks = new Dictionary<string, Action<TutorialTarget>>();


        public Action<string, GameObject> EventCallBack { get; set; }
        public Action<string> OnStateExit;

        private Dictionary<string, TutorialState> states = new Dictionary<string, TutorialState>();
        TutorialSequence currentSequence = null;
        private TutorialState currentState = null;

        private Camera mainCamera;
        private TutorialSetupConfig setup;


        public bool IsTutorialActive { get; private set; }
        public string CurrentStateName { get { return currentState != null ? currentState.stateId : "N/A"; } }

#if UNITY_EDITOR
        public string PreviousStateName { get; set; }
        public int TargetsCount { get { return targets.Count; } }
#endif
        private GameObject canvasGo;
        private void Awake()
        {
            DoNotDestroyOnLoad = true;
#if UNITY_EDITOR
            PreviousStateName = "N/A";
#endif

            SceneManager.sceneUnloaded += OnSceneChange;
            setup = Resources.Load<TutorialSetupConfig>("TutorialSetup");
            GameObject tutorialPrefab = Resources.Load<GameObject>("TutorialUI");

            if (tutorialPrefab != null)
            {
                canvasGo = GameObject.Instantiate(tutorialPrefab);
                if (canvasGo != null)
                {
                    tutorial3DCamera = canvasGo.GetComponentInChildren<Camera>();
                    canvas = canvasGo.GetComponentInChildren<TutorialCanvas>();
                    canvasGo.transform.parent = transform;
                    if (setup != null)
                    {
                        canvas.SetTintColor(setup.tintColor);
                        canvas.SetResolution(setup.canvasResolution);
                    }

                    if (setup != null && setup.skipPrefab != null)
                        canvas.AddSkipButton(setup.skipPrefab);
                    else
                    {
                        GameObject go = Resources.Load<GameObject>("TutorialSkipButton");
                        if (go != null)
                            canvas.AddSkipButton(go);
                    }
                }
                canvasGo.SetActive(false);
            }
            mainCamera = Camera.main;
            UpdateCamera();
            
        }

        public int TutorialLayer => LayerMask.NameToLayer("Tutorial");

        public string ActiveTutorialID { get; set; }

        private void OnSceneChange(Scene arg0)
        {
            FindAllTargets();
        }

        private void FindAllTargets()
        {
            TutorialTarget[] targetObjects = GameObject.FindObjectsOfType<TutorialTarget>();
            foreach (var t in targetObjects)
            {
                AddTarget(t);
            }

            var canvasObjects = FindObjectsOfType<Canvas>();
            if (canvasObjects != null)
            {
                foreach (var c in canvasObjects)
                {
                    var targets = c.GetComponentsInChildren<TutorialTarget>(true);

                    AddTargets(targets);
                }
            }
        }

        /// <summary>
        /// It can be used to add targets externally which are inactive intially
        /// </summary>
        /// <param name="targets"></param>
        public void AddTargets(TutorialTarget[] targets)
        {
            foreach (var t in targets)
            {
                AddTarget(t);
            }
        }

        private IEnumerator Start()
        {
            // Find and add tutorial targets in scene
            var sceneTargets = FindObjectsOfType<TutorialTarget>();
            
            yield return null;
            AddTargets(sceneTargets);

            // Find inactive tutorial objects under canvas
            var canvasObjects = FindObjectsOfType<Canvas>();
            yield return null;
            if (canvasObjects != null)
            {
                foreach (var c in canvasObjects)
                {
                    if (c != null)
                    {
                        var targets = c.GetComponentsInChildren<TutorialTarget>(true);

                        AddTargets(targets);
                    }
                    yield return null;
                }
            }
        }

        private bool LoadTutorial(string tutorialName, string jsonData = "")
        {
            states.Clear();

            currentState = null;

            bool isSuccess = false;
            //TutorialSequenceConfig config = Resources.Load<TutorialSequenceConfig>(tutorialName);
            //string[] splits = tutorialName.Split('/');
            //string tutName = splits[splits.Length - 1];
            currentSequence = TutorialJsonOperator.Instance.GetSequence(jsonData);
            if (currentSequence == null)
            {
                jsonData = string.Empty;
                if (string.IsNullOrEmpty(jsonData))
                    currentSequence = TutorialLoader.LoadFromJson(tutorialName);
                else
                    currentSequence = TutorialLoader.LoadFromText(jsonData);
            }
            
            if (currentSequence != null)
            {
                isSuccess = true;
                Invoke(nameof(OnLoaded), 0.1f);
            }

            return isSuccess;
        }

        public void SetMainCamera(Camera mainCamera)
        {
            this.mainCamera = mainCamera;
            UpdateCamera();
        }

        void OnLoaded()
        {
            if (currentSequence != null && currentSequence.states.Count > 0)
            {
                currentState = currentSequence.states[0];

                if (currentState != null)
                {
                    currentState.OnEnter();
                }
            }
        }


        /// <summary>
        /// Adding the target to the list
        /// </summary>
        /// <param name="target"></param>
        public void AddTarget(TutorialTarget target)
        {
            if (targets.ContainsKey(target.UniqueID))
            {
                targets[target.UniqueID] = target;
                // Debug.LogError("Tutorial Unique id already Exists : ID = " + target.UniqueID);
                return;
            }

            targets.Add(target.UniqueID, target);
            target.MarkAsAdded(true);
        }

        public void RefreshAllTargets()
        {
            var sceneTargets = FindObjectsOfType<TutorialTarget>();
            foreach (var target in sceneTargets)
            {
                if (targets.ContainsKey(target.UniqueID) && targets[target.UniqueID] == null)
                {
                    targets[target.UniqueID] = target;
                }
            }

            var canvasObjects = FindObjectsOfType<Canvas>();
            if (canvasObjects != null)
            {
                foreach (var c in canvasObjects)
                {
                    var canvasTargets = c.GetComponentsInChildren<TutorialTarget>(true);
                    foreach (var target in canvasTargets)
                    {
                        if (targets.ContainsKey(target.UniqueID) && targets[target.UniqueID] == null)
                        {
                            targets[target.UniqueID] = target;
                        }
                    }
                }
            }
        }

        public void RemoveTarget(TutorialTarget target)
        {
            if (targetCallbacks.ContainsKey(target.UniqueID))
            {
                targetCallbacks.Remove(target.UniqueID);
            }

            if (targets.ContainsKey(target.UniqueID))
            {
                target.MarkAsAdded(false);
                targets.Remove(target.UniqueID);
            }
        }

        public void FindTarget(string elementName, Action<TutorialTarget> onTargetFound)
        {
            if (string.IsNullOrEmpty(elementName))
                return;
            if (targets.ContainsKey(elementName))
            {
                if (targets[elementName] == null)
                {
                    RefreshAllTargets();
                }
                onTargetFound(targets[elementName]);
            }
            else
            {
                targetCallbacks[elementName] = onTargetFound;
                FindAllTargets();
            }
        }

        public void FindTargets(string[] elementsIds, Action<TutorialTarget> onTargetFound)
        {
            for (int i = 0; i < elementsIds.Length; i++)
            {
                FindTarget(elementsIds[i], onTargetFound);
            }
        }

        public TutorialState FindStateById(string stateId)
        {
            TutorialState stateObject = null;

            if (currentSequence != null && !string.IsNullOrEmpty(stateId))
            {
                foreach (var state in currentSequence.states)
                {
                    if (state.stateId == stateId)
                    {
                        stateObject = state;
                        break;
                    }
                }
            }

            return stateObject;
        }


        //forcefully quits the tutorial 
        public void ForceEndTutorial()
        {
            if (IsTutorialActive)
            {
                if (currentSequence != null && currentState != null)
                {
                    IsTutorialActive = false;
                    currentState.OnExit(true);
                    EndTutorial();
                }
            }
        }

        public void CompleteState(string stateName, string exitState)
        {
            targetCallbacks.Clear();
#if UNITY_EDITOR
            PreviousStateName = CurrentStateName;
#endif

            if (currentState != null)
            {
                OnStateExit?.Invoke(stateName);
            }
            var state = FindStateById(exitState);
            if (state == null || !IsTutorialActive)
            {
                Log.Print("Tutorial Ended ");

                EndTutorial();
            }
            else
            {
                Log.Print("Tutorial : Exiting :" + currentState.stateId + ", Entering : " + exitState);
                currentState = state;
                currentState.OnEnter();
            }
        }

        public void UpdateCamera()
        {
            if (mainCamera == null)
                mainCamera = Camera.main;

            tutorial3DCamera.transform.position = mainCamera.transform.position;
            tutorial3DCamera.transform.rotation = mainCamera.transform.rotation;
            var flags = tutorial3DCamera.clearFlags;
            var mask = tutorial3DCamera.cullingMask;
            tutorial3DCamera.CopyFrom(mainCamera);
            tutorial3DCamera.clearFlags = flags;
            tutorial3DCamera.cullingMask = mask;
            tutorial3DCamera.depth = mainCamera.depth + 10;
        }

        private void Update()
        {

            if (currentState != null)
                currentState.Update();

            foreach (var it in targetCallbacks)
            {
                if (targets.ContainsKey(it.Key))
                {
                    it.Value(targets[it.Key]);
                    targetCallbacks.Remove(it.Key);
                    break;
                }
            }
        }


        public void Notify(string message, GameObject objectToHighlight = null)
        {
            EventCallBack?.Invoke(message, objectToHighlight);
        }

        /// <summary>
        /// Load and display the tutorial
        /// if overridejson data is empty, it will load from local resources. Else it will load the sequence from json data
        /// </summary>
        /// <param name="tutorialFilePath"></param>
        /// <param name="onTutorialComplete"></param>
        /// <param name="overrideJsonData"></param>
        public void ShowTutorial(string tutorialFilePath, Action<string> onTutorialComplete = null, string overrideJsonData = "")
        {
            if (canvasGo != null)
            {
                canvasGo.SetActive(true);
            }
            else
			{
                onTutorialComplete.Invoke(tutorialFilePath);
                IsTutorialActive = false;
                return;
			}
            ActiveTutorialID = tutorialFilePath;
            OnTutorialComplete = onTutorialComplete;
            if ((string.IsNullOrEmpty(tutorialFilePath) && string.IsNullOrEmpty(overrideJsonData)) || !LoadTutorial(tutorialFilePath, overrideJsonData))
            {
                OnTutorialComplete?.Invoke(ActiveTutorialID);
                return;
            }
            IsTutorialActive = true;
            OnTutorialStart?.Invoke(tutorialFilePath);
            if (currentSequence != null)
                GetCanvas().ShowSkipButton(currentSequence.enableSkipButton);
        }

        private void EndTutorial()
        {
            IsTutorialActive = false;
            currentState = null;
            currentSequence = null;
            GetCanvas().ShowTintBG(false);
            OnTutorialComplete?.Invoke(ActiveTutorialID);
            targetCallbacks.Clear();
            GetCanvas().ShowSkipButton(false);
            if (canvasGo != null)
            {
                canvasGo.SetActive(false);
            }
        }

        public TutorialCanvas GetCanvas()
        {
            return canvas;
        }

        public GameObject FindPrefabById(string id)
        {
            if (setup != null)
                return setup.GetAssetById(id);
            return null;
        }

        public Camera Get3DCamera()
        {
            return tutorial3DCamera;
        }

        public bool StringToBool(string value)
        {
            if (value.ToUpper().Equals("TRUE"))
                return true;

            return false;
        }

        public Vector3 StringToVector3(string value)
        {
            string[] splits = value.Split(',');
            if (splits.Length == 3)
            {
                return new Vector3(float.Parse(splits[0]), float.Parse(splits[1]), float.Parse(splits[2]));
            }
            return Vector3.zero;
        }
    }
}
