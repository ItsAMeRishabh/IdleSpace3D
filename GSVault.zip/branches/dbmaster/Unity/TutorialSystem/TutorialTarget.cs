﻿using UnityEngine;
using System;
using UnityEngine.UI;

namespace GS
{
    [Serializable]
    public class TargetGUID
    {
        public string id;
    }

    [Serializable]
    public class AssetID
    {
        public string id;
    }

    public class TutorialTarget : MonoBehaviour
    {
        [SerializeField] private string uniqueID = Guid.NewGuid().ToString();

        public string UniqueID => uniqueID;

        [ContextMenu("Generate UniqueID")]
        private void RegenerateGUID() => uniqueID = Guid.NewGuid().ToString();

        [ReadOnly] [SerializeField] private bool isUI;

        public bool IsUI 
        {
            get 
            { 
                if(!isUICheckCompleted)
                    CheckForisUI();
                return isUI;
            }
        }
        private Canvas canvas;
        private bool isAddedToDictionary = false;
        private bool canvasSortingStatus = false;
        private bool isUICheckCompleted = false;

        public void MarkAsAdded(bool isAdded)
        {
            isAddedToDictionary = true;
        }

        private void Start()
        {

        }

        public void OverrideUniqueID(string id)
        {
            uniqueID = id;
        }

        void CheckForisUI()
        {
            isUICheckCompleted = true;
            if (gameObject.GetComponent<RectTransform>() != null)
            {
                isUI = true;
                canvas = GetComponent<Canvas>();
                if (canvas == null)
                    canvas = gameObject.AddComponent<Canvas>();
                var raycaster = gameObject.GetComponent<GraphicRaycaster>();

                if (raycaster == null)
                    gameObject.AddComponent<GraphicRaycaster>();

                    canvas.overrideSorting = canvasSortingStatus;
            }
        }

        private void OnEnable()
        {
            CheckForisUI();
            if(!isAddedToDictionary)
                TutorialManager.Instance.AddTarget(this);
        }

        private void OnDestroy()
        {
            if (TutorialManager.IsInstatiated() && TutorialManager.Instance != null)
                TutorialManager.Instance.RemoveTarget(this);
        }

        public void SetLayer(int layer)
        {
            if (canvas != null)
            {
                if (layer != 0)
                {
                    canvas.overrideSorting = true;
                    canvas.sortingOrder = layer;
                    canvasSortingStatus = true;
                }
                else
                {
                    canvas.sortingOrder = layer;
                    canvas.overrideSorting = false;
                    canvasSortingStatus = false;
                }
            }
        }
    }
}