﻿using GS.GameConsts;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    /// <summary>
    /// List of all common Events which can be used in any projects  
    /// </summary>
    namespace GameEvents
    {
        /// <summary>
        /// Start couroutine Event for non monobahaviour Event
        /// </summary>
        public class StartCoroutineEvent : GameEvent
        {
            public IEnumerator routine;

            public StartCoroutineEvent(IEnumerator routine)
            {
                this.routine = routine;
            }
        }

        public class StopCoroutineEvent : GameEvent
        {
            public IEnumerator routine;

            public StopCoroutineEvent(IEnumerator routine)
            {
                this.routine = routine;
            }
        }


        /// <summary>
        /// Invoke a method  after specified duration
        /// </summary>
        public class InvokeActionEvent : GameEvent
        {
            public System.Action action;
            public float duration;
            public string actionKey; // this is the type of action used for cancellation of action

            public InvokeActionEvent(System.Action action, float duration, string key="")
            {
                this.actionKey = key;
                this.action = action;
                this.duration = duration;
                StopTracing();
            }
        }


        /// <summary>
        /// Invoke a method  after specified duration
        /// </summary>
        public class InvokeRepeateActionEvent : GameEvent
        {
            public System.Action action;
            public float repeateWait, startWait;
            public string actionKey; // this is the type of action used for cancellation of action

            public InvokeRepeateActionEvent(System.Action action, float duration, float startWait = 0, string key = "")
            {
                this.actionKey = key;
                this.action = action;
                this.repeateWait = duration;
                this.startWait = startWait;
                StopTracing();
            }
        }

        /// <summary>
        /// This event is used to cancel the invoke actions based on the key of the invoke
        /// </summary>
        public class CancelInvokeActionEvent : GameEvent
        {
            public string key;

            public CancelInvokeActionEvent(string key)
            {
                this.key = key;
                StopTracing();
            }
        }

		/// <summary>
		/// This event is used to run the given action on mainthread which is running in different thread
		/// </summary>
		public sealed class RunOnUnityMainThreadEvent : GameEvent
        { 
            public Action action;

			public RunOnUnityMainThreadEvent(Action action)
			{
				this.action = action;
			}
		}


        /// <summary>
        /// UI Event Type which holds Screen type and button Name
        /// </summary>
        public class UIEvent : GameEvent
        {
            public int screenID;
            public string buttonName;
            public bool isOn;
            public Vector3 elementPosition;

            public UIEvent(int fromScreen, string buttonName, Vector3 elementPosition, bool isOn = true)
            {
                screenID = fromScreen;
                this.buttonName = buttonName;
                this.isOn = isOn;
                this.elementPosition = elementPosition;
            }
        }

        /// <summary>
        /// This event will be raised Scene handler/Game Modes once it is initialized by 
        /// </summary>
        public class UIGameObjectLoaded : GameEvent
        {
            public GameObject uiGameObject;

            public UIGameObjectLoaded(GameObject uiGameObject)
            {
                this.uiGameObject = uiGameObject;
            }
        }


        /// <summary>
        /// UIScreen(s) transition based on 'UIScreenEventType'.
        /// </summary>
        public class UIScreenEvent : GameEvent
        {
            public int screenID;
            public UIScreenEventType operationType = UIScreenEventType.Switch;
            public Action<int, bool> onScreenChanged { get; private set; }

            public UIScreenEvent(Action<int, bool> onScreenChange)
            {
                onScreenChanged = onScreenChange;
            }
            public UIScreenEvent(int screen, UIScreenEventType operationType = UIScreenEventType.Switch)
            {
                screenID = screen;
                this.operationType = operationType;
            }

            public UIScreenEvent(object onScreenChanged)
            {

            }
        }

        

        /// <summary>
        /// Carries data to UIScreen's registered dataPairs methods
        /// </summary>
        public class UIScreenUpdateInfoEvent : GameEvent
        {
            //public UIScreenID screenID { get; private set; }

            /// <summary>
            /// Key of DataPiar
            /// </summary>
            // TODO: If possible restrict it to 'scene specific' DataPairsEnum
            public int dataPairKey;

            /// <summary>
            /// Value of DataPair
            /// </summary>
            public object dataPairValue;

            public UIScreenUpdateInfoEvent()//Enum @enum)
            {
                //var asd = @enum.GetType();
            }

            // Setters for variables
            //public void SetScreenID(UIScreenID screen) { screenID = screen; }
            //public void SetUIDataPair(UIDataPair uiDataPair) { this.uiDataPair = uiDataPair; }
        }

        /// <summary>
        /// Carries 'scene specific' DataPairsEnum 'count'
        /// </summary>
        public class UIControllerDataPairsEnumCountEvent : GameEvent
        {
            public int enumsCount { get; private set; }

            public UIControllerDataPairsEnumCountEvent(Enum enums)
            {
                enumsCount = Enum.GetNames(enums.GetType()).Length;
            }
        }

       
        /// <summary>
        /// Event to Load a scene
        /// </summary>
        public class LoadSceneEvent : GameEvent
        {
            public string sceneName { get; private set; }
            public bool isLoadingSceneRequired { get; private set; }

            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="sceneName">Name of the Scene to Load</param>
            /// <param name="isLoadingRequired">Is Loading scene required to display ??</param>
            public LoadSceneEvent(string sceneName, bool isLoadingRequired)
            {
                this.sceneName = sceneName;
                this.isLoadingSceneRequired = isLoadingRequired;
            }
        }


        /// <summary>
        /// Either Set(s) or Get(s) User selections on UI screen to MatchSettings
        /// </summary>
        public class SettingsEvent<T> : GameEvent
        {
            //private string key = "";
            public struct SettingKeyPairs
            {
                public T key; // { get; private set; }
                public int val; // { get; private set; }

                public SettingKeyPairs(T keyName, int value)
                {
                    key = keyName;
                    val = value;
                }
            }

            public SettingKeyPairs[] KeyPairs { get; protected set; }
            public Action<SettingKeyPairs[]> Callback { get; protected set; }
            public bool IsGetEvent { get { return Callback != null; } }

            /// <summary>
            /// Set Key pairs list
            /// </summary>
            /// <param name="keyPairs"></param>
            public void SetKeyPairs(params SettingKeyPairs[] keyPairs)
            {
                this.KeyPairs = keyPairs;
            }

            /// <summary>
            /// Sets Callback function 
            /// </summary>
            /// <param name="callback"></param>
            public void SetCallback(Action<SettingKeyPairs[]> callback)
            {
                Callback = callback;
            }


            /// <summary>
            /// Get a value(s)
            /// </summary>
            /// <param name="key"></param>
            /// <param name="val"></param>
            public void GetParamaters(Action<SettingKeyPairs[]> callbackFun, params T[] keys)
            {
                this.Callback = callbackFun;
                this.KeyPairs = new SettingKeyPairs[keys.Length];

                // Assigning keys to KeyPairs. Values are filled by event listner
                for (int i = 0; i < keys.Length; i++)
                {
                    this.KeyPairs[i].key = keys[i];
                }
            }
        }


        /// <summary>
        /// Set/Get parmaters of Game settings Events
        /// </summary>
        public class GeneralSettingsEvent : SettingsEvent<GeneralSettingType>
        {

            public GeneralSettingsEvent()
            {

            }

            public GeneralSettingsEvent(params SettingKeyPairs[] keyPairs)
            {
                SetKeyPairs(keyPairs);
            }

            public GeneralSettingsEvent(Action<SettingKeyPairs[]> callbackFun, params GeneralSettingType[] keys)
            {
                GetParamaters(callbackFun, keys);
            }
        }

        /// <summary>
        /// To notify that loading required 'Game Scene' components done
        /// </summary>
        public class GameLoadingCompleted : GameEvent
        {
        }

        /// <summary>
        /// Removes all previous screens in stack
        /// </summary>
        public class RemovePreviousScreen : GameEvent
        {

        }


        /// <summary>
        /// Audio Event Type which holds the index of Playlist
        /// </summary>
        public class AudioEvent : GameEvent
        {
            public int audioIndex = -1;
            public AudioChannelType channelType;
            public bool shouldLoop;

            public AudioEvent(int index, AudioChannelType channelType, bool shouldLoop)
            {
                audioIndex = index;
                this.channelType = channelType;
                this.shouldLoop = shouldLoop;
            }
        }

        /// <summary>
        /// Swipe event which gets broadcasted when we swipe.....
        /// </summary>
        public class SwipeEvent : GameEvent
        {
            public SwipeDirection swipeDirection { get; private set; }
            public SwipeLength swipeLength { get; private set; }
            public bool isFakeSwipe = false; //This is to set a fake swipe even when the actual swipe is not happened...
            public Vector2 swipeVector;
            public bool IsOverUI;

            public SwipeEvent(SwipeDirection dir, Vector2 vector, SwipeLength swipeLen = SwipeLength.Short, bool isOverUI = false, bool isFakeSwipe = false)
            {
                this.swipeDirection = dir;
                this.swipeVector = vector;
                this.swipeLength = swipeLen;
                this.isFakeSwipe = isFakeSwipe;
                IsOverUI = isOverUI;
            }
        }

        /// <summary>
        /// User Tap Event Information
        /// </summary>
        public class TAPEvent : GameEvent
        {
            public Vector3 tapScreenPos { get; private set; }
            public bool IsOverUI { get; private set; }

            public TAPEvent(Vector3 pos, bool isOverUI)
            {
                this.tapScreenPos = pos;
                IsOverUI = isOverUI;
            }
        }

        /// <summary>
        /// Drag Event Type which raised when user drags on screen 
        /// </summary>
        public class DragEvent : GameEvent
        {
            public Vector3 currentPosition;
            public SwipeDirection swipeDirection { get; set; }
            public Vector3 dragDirection { get; set; }
            public bool dragEnd { get; set; }


        }


        /// <summary>
        /// This event will be raised if any scene is Loaded....
        /// </summary>
        public class LevelLoadedEvent : GameEvent
        {
            public UnityEngine.SceneManagement.Scene scene { get; private set; }
            /// <summary>
            /// Unity LoadScene Mode
            /// </summary>
            public UnityEngine.SceneManagement.LoadSceneMode sceneMode { get; private set; }

            public LevelLoadedEvent(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode sceneMode)
            {
                this.scene = scene;
                this.sceneMode = sceneMode;
            }

            public override string ToString()
            {
                return "Loaded Scene: " + scene.name;
            }
        }


        /// <summary>
        /// Dragging over UI Event
        /// </summary>
        public class DragUIEvent : GameEvent
        {
            public Vector3 position;
            public Vector3 direction;
            public bool isDrag = false;
        }

        public class HoldTapEvent : GameEvent
        {
            public Vector3 mousePosition;
        }

        public class BundleVersionCheckerDoneEvent : GameEvent
        {

        }

        public class ApplicationFocusEvent : GameEvent
        {
            public bool focus;
            public ApplicationFocusEvent(bool focus)
            {
                this.focus = focus;
            }
        }

        public class ApplicationQuitEvent : GameEvent
        {
        }

        public class GetPreRequestedOTP : GameEvent
        {
            public Action<int> callback;
            public GetPreRequestedOTP(Action<int> callback)
            {
                this.callback = callback;
            }
        }

        /// <summary>
        /// This Event will be raised to Play Plarticles
        /// </summary>
        public class ParticleEvent : GameEvent
        {
            public int type;
            public Vector3 position;

            public ParticleEvent(int type, Vector3 pos)
            {
                this.type = type;
                position = pos;
            }
        }

        public class UIManagerScreenChanged : GameEvent
        {
            public int screenId;
            public UIManagerScreenChanged(int _screenId)
            {
                screenId = _screenId;
                if(_screenId < 0)
				{
                    Log.Error("Screen Id passed is less than 0");
				}
            }
        }

        public class MainScreenBackHacked : GameEvent
		{
		}
    }
}
