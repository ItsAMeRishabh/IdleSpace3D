﻿using GS.Net;
using System.Diagnostics;
using UnityEditor;
using UnityEngine;

#if UNITY_EDITOR
/// <summary>
/// Editor helper Tools 
/// </summary>
public class CustomEditorMenu
{
    /// <summary>
    /// Menu Name which appears in Editor Menu
    /// </summary>
    public const string mainMenuItemName = "Tools/";

    #region SVN

    public static string commitCommnad = "/C TortoiseProc.exe /command:commit /path:" + Application.dataPath + " /closeonend:0";
    public static string updateCommnad = "/C TortoiseProc.exe /command:update /path:" + Application.dataPath + " /closeonend:0";


    public static string commitGSVaultCommand = "/C TortoiseProc.exe /command:commit /path:" + Application.dataPath + "/GSVault" + " /closeonend:0";
    public static string updateGSVaultCommand = "/C TortoiseProc.exe /command:update /path:" + Application.dataPath + "/GSVault" + " /closeonend:0";

    /// <summary>
    /// SVN Commits the code for both Main Project and GS Vault
    /// </summary>
    [MenuItem(mainMenuItemName + "SVN/Commit %s+m")]
    public static void Commit()
    {
        StartProcess(commitCommnad);
        StartProcess(commitGSVaultCommand);

    }

    /// <summary>
    /// Updates SVN the code for both Main Project and GS Vault
    /// </summary>
    [MenuItem(mainMenuItemName + "SVN/Update %s+u")]
    public static void Update()
    {
        StartProcess(updateCommnad);
        StartProcess(updateGSVaultCommand);
    }

    /// <summary>
    /// Starts the process using Window Process
    /// </summary>
    /// <param name="command"></param>
    private static void StartProcess(string command)
    {
        Process p = new Process();
        p.StartInfo.CreateNoWindow = true;
        p.StartInfo.UseShellExecute = false;
        p.StartInfo.FileName = "cmd.exe";
        p.StartInfo.Arguments = command;
        p.Start();
    }

    #endregion

    [MenuItem(mainMenuItemName + "ClearSaveData")]
    public static void ClearSaveData()
    {
        PlayerPrefs.DeleteAll();
        if(SavingSystemConfigSO.Instance != null)
            SavingSystemConfigSO.Instance.DeleteAllFile();
    }


    [MenuItem("Assets/Build Bundles for Android")]
    static void BuildAllAssetBundles()
    {
        string outPutPath = "AssetBundles/Android";
        BuildPipeline.BuildAssetBundles(outPutPath, BuildAssetBundleOptions.None, BuildTarget.Android | BuildTarget.StandaloneWindows);
    }

    [MenuItem("Assets/Build Bundles for IOS")]
    static void BuildAllIOSAssetBundles()
    {
        string outPutPath = "AssetBundles/ios";
        BuildPipeline.BuildAssetBundles(outPutPath, BuildAssetBundleOptions.None, BuildTarget.iOS);
    }
}
#endif