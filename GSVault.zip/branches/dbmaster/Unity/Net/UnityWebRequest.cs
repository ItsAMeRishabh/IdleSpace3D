﻿using System.Collections;
using UnityEngine.Networking;
using GS.Net;
using System;
using UnityEngine;
using System.Collections.Generic;

namespace GS.Unity
{
    /// <summary>
    /// Http Web Request Implementation using UnityWebRequest
    /// </summary>
    public class UnityWebRequest : IWebRequest
    {
        int timeOut = 30;
        #region Interface Members

        /// <summary>
        /// Downloads content from given URL.
        /// Returns progress of download and returns string in response
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public void Get(string url, string key, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback)
        {
            Utils.EventSync(new GameEvents.StartCoroutineEvent(GetRequest(url, key, onGetCompletedCallback, progressCallback)));
        }

        /// <summary>
        /// Post Web request 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onUploadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        public void Post(string url, string key, string data, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback)
        {
           // Debug.Log("Existing in webrequest.."+url+" data"+data);                
            Utils.EventSync(new GameEvents.StartCoroutineEvent(Upload(url, key, data, onUploadCompletedCallback, progressCallback)));
        }

        /// <summary>
        /// Updates Web request 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onUploadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        public void Update(string url, string key, string data, Action<string, string, string> onDownloadCompletedCallback, Action<float> progressCallback)
        {
            Utils.EventSync(new GameEvents.StartCoroutineEvent(UpdateRequest(url, key, data, onDownloadCompletedCallback, progressCallback)));
        }

        /// <summary>
        /// Delete content from given URL.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public void Delete(string url, string key, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback)
        {
            Utils.EventSync(new GameEvents.StartCoroutineEvent(DeleteRequest(url, key, onGetCompletedCallback, progressCallback)));
        }

        /// <summary>
        /// Download Web request 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onDownloadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        public void Download(string url, string key, string data, Action<string, byte[], string> onDownloadCompletedCallback, Action<float,string> progressCallback)
        {
            Utils.EventSync(new GameEvents.StartCoroutineEvent(DownloadFile(url, key, data, onDownloadCompletedCallback, progressCallback)));
        }

        #endregion Interface Members


        /// <summary>
        /// Internal function to download content from given URL.
        /// Returns progress of download and returns string in response
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        IEnumerator GetRequest(string url, string key, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback)
        {
            using (UnityEngine.Networking.UnityWebRequest webRequest = UnityEngine.Networking.UnityWebRequest.Get(url))
            {
                if (progressCallback != null)
                    progressCallback(webRequest.downloadProgress);
                webRequest.timeout = timeOut;
                // Request and wait for the desired page.
                yield return webRequest.SendWebRequest();
                NetworkUtils.IsConnected = (webRequest.isDone && string.IsNullOrEmpty(webRequest.error));

                if (onGetCompletedCallback != null)
                    onGetCompletedCallback(key, webRequest.isDone ? (webRequest.downloadHandler.text) : null, webRequest.error);
            }
        }


        /// <summary>
        /// Post data to using http call
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onUploadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        /// <returns></returns>
        IEnumerator Upload(string url, string key, string data, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback)
        {
          //  Debug.Log("Existing in webrequest..000"+data);

            byte[] formData = System.Text.Encoding.UTF8.GetBytes(data);
            using (UnityEngine.Networking.UnityWebRequest request = UnityEngine.Networking.UnityWebRequest.Post(url, data))
            {
                request.SetRequestHeader("Content-Type", "application/json");
                request.uploadHandler = (UploadHandler)new UploadHandlerRaw(formData);
                yield return request.SendWebRequest();

                bool isSuccess = request.result == UnityEngine.Networking.UnityWebRequest.Result.Success;
                NetworkUtils.Instance.CheckInternetConnection(isSuccess && string.IsNullOrEmpty(request.error));

                if (onUploadCompletedCallback != null)
                    onUploadCompletedCallback(key, isSuccess ? (request.downloadHandler.text) : null, request.error);
            }
        }

        /// <summary>
        /// Update data to using http call
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onUploadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        /// <returns></returns>
        IEnumerator UpdateRequest(string url, string key, string data, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback)
        {
            //  Debug.Log("Existing in webrequest..000"+data);

            byte[] formData = System.Text.Encoding.UTF8.GetBytes(data);
            using (UnityEngine.Networking.UnityWebRequest request = UnityEngine.Networking.UnityWebRequest.Put(url, data))
            {
                request.SetRequestHeader("Content-Type", "application/json");
                request.uploadHandler = (UploadHandler)new UploadHandlerRaw(formData);
                yield return request.SendWebRequest();

                bool isSuccess = request.result == UnityEngine.Networking.UnityWebRequest.Result.Success;
                NetworkUtils.Instance.CheckInternetConnection(isSuccess && string.IsNullOrEmpty(request.error));

                if (onUploadCompletedCallback != null)
                    onUploadCompletedCallback(key, isSuccess ? (request.downloadHandler.text) : null, request.error);
            }
        }

        /// <summary>
        /// Update data to using http call
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onUploadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        /// <returns></returns>
        IEnumerator DeleteRequest(string url, string key, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback)
        {
            using (UnityEngine.Networking.UnityWebRequest request = UnityEngine.Networking.UnityWebRequest.Delete(url))
            {
                request.SetRequestHeader("Content-Type", "application/json");
                request.downloadHandler = new DownloadHandlerBuffer();
                yield return request.SendWebRequest();

                bool isSuccess = request.result == UnityEngine.Networking.UnityWebRequest.Result.Success;
                NetworkUtils.Instance.CheckInternetConnection(isSuccess && string.IsNullOrEmpty(request.error));

                if (onUploadCompletedCallback != null)
                    onUploadCompletedCallback(key, isSuccess ? (request.downloadHandler.text) : null, request.error);
            }
        }

        /// <summary>
        /// Download File from http using URL 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onDownloadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        /// <returns></returns>
        IEnumerator DownloadFile(string url, string key, string data, Action<string, byte[], string> onDownloadCompletedCallback, Action<float,string> progressCallback)
        {
            using (UnityEngine.Networking.UnityWebRequest webRequest = UnityEngine.Networking.UnityWebRequest.Get(url))
            {
                if (progressCallback != null)
                    progressCallback(webRequest.downloadProgress,key);
                webRequest.SendWebRequest();
                // Request and wait for the desired page.
                while(webRequest.downloadProgress < 1)
                {
                    progressCallback(webRequest.downloadProgress, key);
                    yield return new WaitForSeconds(0.03f);
                }
                progressCallback(1f, key);
                if (onDownloadCompletedCallback != null)
                    onDownloadCompletedCallback(key, webRequest.isDone ? (webRequest.downloadHandler.data) : null, webRequest.error);
            }
            //WWW www = new WWW(url);
            //yield return www;

            //if (www != null)
            //{
            //    if (onDownloadCompletedCallback != null)
            //        onDownloadCompletedCallback(key, www.isDone ? (www.bytes) : null, www.error);
            //}
        }

    }
}