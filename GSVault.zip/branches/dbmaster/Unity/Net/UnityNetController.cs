﻿using GS.Data.Encryption;
using GS.GameEvents;
using GS.Net.Interceptor;
using GS.Net.Transactions;
using GS.Unity;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Net
{
    /// <summary>
    /// This class is used to generic implementation for Unity Related network functionlity
    /// </summary>
    public class UnityNetController<TPacketType> : NetworkController where TPacketType : Enum
    {
        public const string DECRYPTIONFAILED = "Decryption failed";
        public static int activeRequestCount = 0;

        #region Encryptors

        /// <summary>
        /// encryption System for HTTP requests.
        /// </summary>
        protected virtual IEncryptionSystem apiEncryptionSystem => new PlainTextEncryptionSystem();
        /// <summary>
        /// encryption System for local request/reponse vaults.
        /// </summary>
        protected virtual IEncryptionSystem fileEncryptionSystem => new PlainTextEncryptionSystem();

        #endregion

        #region Interceptors

        protected RequestInterceptor<TPacketType> requestInterceptor;
        protected ResponseInterceptor<TPacketType> responseInterceptor;

        #endregion

        // handle for web socket 
        protected IWebRequest webRequest;
        protected bool subscribedToConnectionStatus = false;

        /// <summary>
        /// Create Web socket of type UnityWebRequest
        /// </summary>
        /// <returns></returns>
        protected virtual IWebRequest CreateWebRequest()
        {
            CreateInterceptor();
            return new UnityWebRequest();
        }
        protected virtual void OnOfflineRequestCompleted() { }

        protected void CreateInterceptor()
        {
            requestInterceptor = requestInterceptor ?? new RequestInterceptor<TPacketType>(fileEncryptionSystem);
            responseInterceptor = responseInterceptor ?? new ResponseInterceptor<TPacketType>(fileEncryptionSystem);

            if (!subscribedToConnectionStatus)
            {
                NetworkConnectionStatus();
                NetworkUtils.NetworkConnectionStatus += NetworkConnectionStatus;
                subscribedToConnectionStatus = true;
            }
        }

        /// <summary>
        /// if first time, creates weebrequest instance or else returns the existing instance
        /// </summary>
        /// <returns></returns>
        private IWebRequest GetWebRequest()
        {
            if (webRequest != null)
            {
                return webRequest;
            }

            webRequest = CreateWebRequest();

            return webRequest;
        }

        /// <summary>
        /// Htttp Get Request with callbacks
        /// [Caution : This function doesn't use any of the SaveSystem functionlaity]
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="onGetCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        protected void HttpGet(string url, string transactionId, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback)
        {
            CreateInterceptor();
            activeRequestCount++;

            //NetworkUtils.Instance.CheckInternetConnection();
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            if(!string.IsNullOrEmpty(transaction.Path))
            {
                Uri baseUri = new Uri(url);
                Uri uri = new Uri(baseUri, transaction.Path);
            }

            if (NetworkUtils.IsConnected || !(SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
            {
                Utils.EventSync(new GameEvents.StartCoroutineEvent(HttpGetRoutine(url, transactionId, onGetCompletedCallback, progressCallback)));
            }
            else
            {
                string dataResponse = GetSavedResponse(transactionId, url, null);  
                if (dataResponse != null)
                {
                    onGetCompletedCallback?.Invoke(transactionId, dataResponse, "");
                }
                else
                {
                    Utils.EventSync(new GameEvents.StartCoroutineEvent(HttpGetRoutine(url, transactionId, onGetCompletedCallback, progressCallback)));
                }
            }
        }

        protected IEnumerator HttpGetRoutine(string url, string transactionId, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback)
        {
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            bool hasTransactionCompleted = false;

            GetWebRequest().Get(url, transactionId, (requestKey, response, error) =>
            {
                if (!hasTransactionCompleted)
                {
                    if (!NetworkUtils.IsConnected && (SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
                    {
                        string dataResponse = GetSavedResponse(transactionId, url, null);
                        onGetCompletedCallback?.Invoke(transactionId, dataResponse, "");
                    }
                    else
                    {
                        SaveResponse(transactionId, response, url);
                        onGetCompletedCallback?.Invoke(requestKey, response, error);
                    }
                }

                activeRequestCount--;
                hasTransactionCompleted = true;
            }, progressCallback);

            float currentTime = 0f;
            float timeoutTimer = transaction.RequestTimeoutTimer == -1 ? SavingSystemConfigSO.Instance.requestTimeoutTimer : transaction.RequestTimeoutTimer;

            while (!hasTransactionCompleted && currentTime < timeoutTimer)
            {
                currentTime += Time.unscaledDeltaTime;

                yield return null;
            }

            if (!hasTransactionCompleted)
            {
                string dataResponse = GetSavedResponse(transactionId, url, null);
                if (!string.IsNullOrEmpty(dataResponse))
                {
                    IBaseResponseDefination baseResponse = (IBaseResponseDefination)JsonConvert.DeserializeObject(dataResponse, transaction.ResponseType, new JsonSerializerSettings());

                    if ((NetworkUtils.IsConnected && baseResponse.Status != ResponseStatus.Failed) || !NetworkUtils.IsConnected)
                    {
                        onGetCompletedCallback?.Invoke(transactionId, dataResponse, "");
                        hasTransactionCompleted = true;
                    }
                }
            }
        }

        /// <summary>
        /// Http Post Request with callbacks
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onUploadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        protected void HttpPost(string url, string transactionId, string data, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback, bool offlineRequest = false)
        {
            CreateInterceptor();
            //NetworkUtils.Instance.CheckInternetConnection();
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            if (!string.IsNullOrEmpty(transaction.Path))
            {
                Uri baseUri = new Uri(url);
                Uri uri = new Uri(baseUri, transaction.Path);
            }

            IBaseRequestDefination request = (IBaseRequestDefination) JsonConvert.DeserializeObject(data, transaction.RequestType, new JsonSerializerSettings());

            bool processSync = true;
            if (SyncingPanel.isSyncing)
            {
                processSync = request.IsOffline;
            }

            if (NetworkUtils.IsConnected && processSync && !NetworkUtils.IsSendingOfflineData || !(SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
            {
                Utils.EventSync(new GameEvents.StartCoroutineEvent(HttpPostRoutine(url, transactionId, data, onUploadCompletedCallback, progressCallback, offlineRequest)));
            }
            else
            {
                HttpPostOffline(url, transactionId, data, onUploadCompletedCallback);
            }
        }

        private void HttpPostOffline(string url, string transactionId, string data, Action<string, string, string> onUploadCompletedCallback, bool isOffline = false)
        {
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            if (transaction.IsQueueable)
            {
                if (transaction.IsStackable)
                {
                    requestInterceptor.GetAndRemoveRequest(transactionId);
                }
                SaveRequest(transactionId, url, data, true, isOffline);
            }
            string dataResponse = GetSavedResponse(transactionId, url, data);

            onUploadCompletedCallback?.Invoke(transactionId, dataResponse, "");
        }

        protected IEnumerator HttpPostRoutine(string url, string transactionId, string data, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback, bool offlineRequest = false)
        {
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            bool hasTransactionCompleted = false;

            string _data = apiEncryptionSystem.Encrypt(data);
            GetWebRequest().Post(url, transactionId, _data, (string resquestkey, string response, string error) =>
            {
                if (!NetworkUtils.IsConnected && (SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
                {
                    HttpPostOffline(url, transactionId, data, onUploadCompletedCallback);
                }
                else
                {
                    OnHTTPComplete(url, resquestkey, response, error, data, hasTransactionCompleted ? null : onUploadCompletedCallback);
                }

                hasTransactionCompleted = true;
            }, progressCallback);

            if (SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate)
            {
                float currentTime = 0f;
                float timeoutTimer = transaction.RequestTimeoutTimer == -1 ? SavingSystemConfigSO.Instance.requestTimeoutTimer : transaction.RequestTimeoutTimer;
                while (!hasTransactionCompleted && currentTime < timeoutTimer)
                {
                    currentTime += Time.unscaledDeltaTime;

                    yield return null;
                }

                if (!hasTransactionCompleted)
                {
                    string dataResponse = GetSavedResponse(transactionId, url, data);

                    IBaseResponseDefination baseResponse = (IBaseResponseDefination) JsonConvert.DeserializeObject(dataResponse, transaction.ResponseType, new JsonSerializerSettings());

                    if ((NetworkUtils.IsConnected && baseResponse.Status != ResponseStatus.Failed) || !NetworkUtils.IsConnected)
                    {
                        baseResponse.IsCached = true;
                        onUploadCompletedCallback?.Invoke(transactionId, dataResponse, "");
                        hasTransactionCompleted = true;
                    }
                }
            }
        }

        protected IEnumerator HttpUpdateRoutine(string url, string transactionId, string data, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback, bool offlineRequest = false)
        {
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            if (!string.IsNullOrEmpty(transaction.Path))
            {
                Uri baseUri = new Uri(url);
                Uri uri = new Uri(baseUri, transaction.Path);
            }
            bool hasTransactionCompleted = false;

            string _data = apiEncryptionSystem.Encrypt(data);
            GetWebRequest().Update(url, transactionId, _data, (string resquestkey, string response, string error) =>
            {
                if (!NetworkUtils.IsConnected && (SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
                {
                    HttpPostOffline(url, transactionId, data, onUploadCompletedCallback);
                }
                else
                {
                    OnHTTPComplete(url, resquestkey, response, error, data, hasTransactionCompleted ? null : onUploadCompletedCallback);
                }

                hasTransactionCompleted = true;
            }, progressCallback);

            if (SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate)
            {
                float currentTime = 0f;
                float timeoutTimer = transaction.RequestTimeoutTimer == -1 ? SavingSystemConfigSO.Instance.requestTimeoutTimer : transaction.RequestTimeoutTimer;
                while (!hasTransactionCompleted && currentTime < timeoutTimer)
                {
                    currentTime += Time.unscaledDeltaTime;

                    yield return null;
                }

                if (!hasTransactionCompleted)
                {
                    string dataResponse = GetSavedResponse(transactionId, url, data);

                    IBaseResponseDefination baseResponse = (IBaseResponseDefination)JsonConvert.DeserializeObject(dataResponse, transaction.ResponseType, new JsonSerializerSettings());

                    if ((NetworkUtils.IsConnected && baseResponse.Status != ResponseStatus.Failed) || !NetworkUtils.IsConnected)
                    {
                        baseResponse.IsCached = true;
                        onUploadCompletedCallback?.Invoke(transactionId, dataResponse, "");
                        hasTransactionCompleted = true;
                    }
                }
            }
        }

        protected void HttpUpdate(string url, string transactionId, string data, Action<string, string, string> onUploadCompletedCallback, Action<float> progressCallback, bool offlineRequest = false)
        {
            CreateInterceptor();
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);

            IBaseRequestDefination request = (IBaseRequestDefination)JsonConvert.DeserializeObject(data, transaction.RequestType, new JsonSerializerSettings());

            bool processSync = true;
            if (SyncingPanel.isSyncing)
            {
                processSync = request.IsOffline;
            }

            if (NetworkUtils.IsConnected && processSync && !NetworkUtils.IsSendingOfflineData || !(SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
            {
                Utils.EventSync(new GameEvents.StartCoroutineEvent(HttpUpdateRoutine(url, transactionId, data, onUploadCompletedCallback, progressCallback, offlineRequest)));
            }
            else
            {
                HttpPostOffline(url, transactionId, data, onUploadCompletedCallback);
            }
        }
        
        protected void HttpDelete(string url, string transactionId, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback)
        {
            CreateInterceptor();
            //NetworkUtils.Instance.CheckInternetConnection();
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            if (!string.IsNullOrEmpty(transaction.Path))
            {
                Uri baseUri = new Uri(url);
                Uri uri = new Uri(baseUri, transaction.Path);
            }

            if (NetworkUtils.IsConnected || !(SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
            {
                Utils.EventSync(new GameEvents.StartCoroutineEvent(HttpDeleteRoutine(url, transactionId, onGetCompletedCallback, progressCallback)));
            }
            else
            {
                string dataResponse = GetSavedResponse(transactionId, url, null);
                if (dataResponse != null)
                {
                    onGetCompletedCallback?.Invoke(transactionId, dataResponse, "");
                }
                else
                {
                    Utils.EventSync(new GameEvents.StartCoroutineEvent(HttpDeleteRoutine(url, transactionId, onGetCompletedCallback, progressCallback)));
                }
            }
        }

        protected IEnumerator HttpDeleteRoutine(string url, string transactionId, Action<string, string, string> onGetCompletedCallback, Action<float> progressCallback)
        {
            IBaseTransaction transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);
            bool hasTransactionCompleted = false;

            GetWebRequest().Delete(url, transactionId, (requestKey, response, error) =>
            {
                if (!hasTransactionCompleted)
                {
                    if (!NetworkUtils.IsConnected && (SavingSystemConfigSO.Instance.enabled && transaction.CanAutomate))
                    {
                        string dataResponse = GetSavedResponse(transactionId, url, null);
                        onGetCompletedCallback?.Invoke(transactionId, dataResponse, "");
                    }
                    else
                    {
                        SaveResponse(transactionId, response, url);
                        onGetCompletedCallback?.Invoke(requestKey, response, error);
                    }
                }

                hasTransactionCompleted = true;
            }, progressCallback);

            float currentTime = 0f;
            float timeoutTimer = transaction.RequestTimeoutTimer == -1 ? SavingSystemConfigSO.Instance.requestTimeoutTimer : transaction.RequestTimeoutTimer;

            while (!hasTransactionCompleted && currentTime < timeoutTimer)
            {
                currentTime += Time.unscaledDeltaTime;

                yield return null;
            }

            if (!hasTransactionCompleted)
            {
                string dataResponse = GetSavedResponse(transactionId, url, null);
                IBaseResponseDefination baseResponse = (IBaseResponseDefination)JsonConvert.DeserializeObject(dataResponse, transaction.ResponseType, new JsonSerializerSettings());

                if ((NetworkUtils.IsConnected && baseResponse.Status != ResponseStatus.Failed) || !NetworkUtils.IsConnected)
                {
                    onGetCompletedCallback?.Invoke(transactionId, dataResponse, "");
                    hasTransactionCompleted = true;
                }
            }
        }

        /// <summary>
        /// Http Download Request with callbacks
        /// [Caution : This function doesn't use any of the SaveSystem functionlaity]
        /// </summary>
        /// <param name="url"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="onUploadCompletedCallback"></param>
        /// <param name="progressCallback"></param>
        protected void HttpDownload(string url, string key, string data, Action<string, byte[], string> onDownloadCompletedCallback, Action<float, string> progressCallback)
        {
            CreateWebRequest().Download(url, key, data, onDownloadCompletedCallback, progressCallback);
        }

        private void OnHTTPComplete(string url, string transactionId, string response, string error, string request, Action<string, string, string> onUploadCompletedCallback)
        {
            NetworkUtils.LastOnline = DateTime.UtcNow;

            var transaction = BaseTransactionsHolder<TPacketType>.Get(transactionId);

            if (apiEncryptionSystem.Decrypt(ref response))
            {
                if (transaction.CanAutomate && SavingSystemConfigSO.Instance.enabled)
                {
                    SaveResponse(transactionId, response, url, request);
                }
            }
            else
            {
                error = DECRYPTIONFAILED;
            }

            onUploadCompletedCallback?.Invoke(transactionId, response, error);
        }

        #region Feed and Retrive of request and responses.

        /// <summary>
        /// Enqueues the request locally.
        /// </summary>
        /// <param name="transactionId"></param>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="isPost"></param>
        protected void SaveRequest(string transactionId, string url, string data = "", bool isPost = false, bool isOffline = false)
        {
            CreateInterceptor();
            if (!NetworkUtils.OfflineReady)
            {
                return;
            }

            if (isOffline)
            {
                requestInterceptor.PushToTop(url, transactionId, data, isPost);
            }
            else
            {
                requestInterceptor.EnqueueRequest(url, transactionId, data, isPost);
            }
        }

        protected int GetSavedRequestCount()
        {
            return requestInterceptor.Count; ;
        }

        /// <summary>
        /// Gets the locally queued request.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        protected int GetSavedRequest(out KeyValuePair<string, RequestInfo> request)
        {
            request = new KeyValuePair<string, RequestInfo>();
            int count = GetSavedRequestCount();
            if (count == 0)
            {
                return 0;
            }
            request = requestInterceptor.GetQueuedRequest();
            return count;
        }

        /// <summary>
        /// Saves the response / request pair to the file. 
        /// </summary>
        /// <param name="transactionID"></param>
        /// <param name="response"></param>
        /// <param name="request"></param>
        protected void SaveResponse(string transactionID, string response, string url, string request = null)
        {
            ResponseInterceptor<TPacketType>.instance.SaveResponse(transactionID, response, url, request, activeRequestCount <= 1);
        }

        /// <summary>
        /// Retrives a response from the file for the transactionID.
        /// </summary>
        /// <param name="transactionID"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        protected string GetSavedResponse(string transactionID, string url, string request)
        {
            CreateInterceptor();
            return responseInterceptor.GetTransactionResponse(transactionID, url, request);
        }

        #endregion

        private bool processingSyncRequest = false;
        private void OnGlobalTimeFetch()
        {
            NetworkUtils.OnGlobalTimeFetched -= OnGlobalTimeFetch;
            processingSyncRequest = false;
            NetworkConnectionStatus();
        }

        protected void NetworkConnectionStatus()
        {
            Utils.EventSync(new InvokeActionEvent(() =>
            {
                if (NetworkUtils.IsConnected && !NetworkUtils.StopCheck && !processingSyncRequest) //Online!!
                {
                    if (NetworkUtils.isTimeFromOffline)
                    {
                        processingSyncRequest = true;
                        NetworkUtils.IsGlobalTimeFetched = false;
                        NetworkUtils.OnGlobalTimeFetched += OnGlobalTimeFetch;
                        NetworkUtils.Instance.StartCoroutine(NetworkUtils.Instance.CheckNetworkAvailability());

                        return;
                    }

                    KeyValuePair<string, RequestInfo> savedRequest;

                    if (GetSavedRequest(out savedRequest) > 0)
                    {
                        processingSyncRequest = true;
                        SyncingPanel.instance.ShowPopUp();
                        if (NetworkUtils.IsSendingOfflineData)
                        {
                            NetworkUtils.IsSendingOfflineData = true;
                            NetworkUtils.OnSendingOfflineChanged?.Invoke(true);
                        }

                        var transaction = BaseTransactionsHolder<TPacketType>.Get(savedRequest.Value.transactionID);
                        IBaseRequestDefination request = (IBaseRequestDefination) JsonConvert.DeserializeObject(savedRequest.Value.data, transaction.RequestType, new JsonSerializerSettings());
                        request.IsOffline = true;

                        //DateTime globalTime = NetworkUtils.Getglobaltime;
                        //DateTime localTime = DateTime.Now;

                        //long timeStampGlobal = globalTime.ToTimeStamp();
                        //long timeStampLocal = localTime.ToTimeStamp();

                        //localTime.AddMilliseconds(timeStampLocal - timeStampGlobal);
                        //request.TimeStamp = localTime;

                        //int timeDiffSignPre = DateTime.Compare(request.TimeStamp, NetworkUtils.lastCheckedOnline);
                        //if (timeDiffSignPre < 0)
                        //{
                        //    DateTime lastOnline = NetworkUtils.lastCheckedOnline;
                        //    lastOnline = lastOnline.AddMinutes(Time.time);
                        //    request.TimeStamp = lastOnline;
                        //}

                        //int timeDiffSignPost = DateTime.Compare(request.TimeStamp, globalTime);
                        //if (timeDiffSignPost > 0)
                        //{
                        //    request.TimeStamp = globalTime;
                        //}

                        string data = JsonConvert.SerializeObject(request, transaction.RequestType, new JsonSerializerSettings());

                        Log.Print($"Offline Request fired: {savedRequest.Value.transactionID} : {data}", LogFilter.Network);
                        if (savedRequest.Value.isPost)
                        {
                            HttpPost(savedRequest.Value.url, savedRequest.Value.transactionID, data, (key, response, error) =>
                            {
                                processingSyncRequest = false;
                                NetworkConnectionStatus();
                                if (!string.IsNullOrEmpty(error))
                                {
                                    Log.Print(error, LogFilter.Error);
                                }

                                Log.Print($"Offline Response: {savedRequest.Value.transactionID} : {response}", LogFilter.Network);
                                ResponseInterceptor<TPacketType>.instance.SaveResponse(transaction.TransactionID, response, string.Empty, data);

                            }, null, true);
                        }
                        else
                        {
                            HttpGet(savedRequest.Value.url, savedRequest.Value.transactionID, (key, response, error) =>
                            {
                                processingSyncRequest = false;
                                NetworkConnectionStatus();
                                if (!string.IsNullOrEmpty(error))
                                {
                                    Log.Print(error, LogFilter.Error);
                                }

                                Log.Print($"Offline Response: {savedRequest.Value.transactionID} : {response}", LogFilter.Network);
                                ResponseInterceptor<TPacketType>.instance.SaveResponse(transaction.TransactionID, response, savedRequest.Value.url, data);
                            }, null);
                        }
                    }
                    else
                    {
                        SyncingPanel.instance.HidePopUp();
                    }

                    if (NetworkUtils.IsSendingOfflineData)
                    {
                        NetworkUtils.IsSendingOfflineData = false;
                        NetworkUtils.OnSendingOfflineChanged?.Invoke(false);
                    }
                }
                else
                {
                    SyncingPanel.instance.HidePopUp();
                }
            }, 0.1f));
        }
    }
}
