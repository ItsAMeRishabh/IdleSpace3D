using UnityEditor;

namespace GS.Net
{
    public class SavingSystemEditor : Editor
    {
        [MenuItem("Tools/Saving System/Delete Request File #&g")]
        public static void DeleteRequestFile()
        {
            SavingSystemConfigSO.Instance.DeleteRequestFile();
        }

        [MenuItem("Tools/Saving System/Delete Response File #&f")]
        public static void DeleteResponseFile()
        {
            SavingSystemConfigSO.Instance.DeleteResponseFile();
        }


        [MenuItem("Tools/Saving System/Delete Request and Response File #&q")]
        public static void DeleteRequestAndResponseFile()
        {
            SavingSystemConfigSO.Instance.DeleteAllFile();
        }

        [MenuItem("Tools/Saving System/Open PersistentDataPath #&o")]
        public static void OpenPersistentDataPath()
        {
            SavingSystemConfigSO.Instance.OpenPersistentDataPath();
        }

        [MenuItem("Tools/Clear PlayerPrefs #&p")]
        public static void ClearPlayerPrefs()
        {
            UnityEngine.PlayerPrefs.DeleteAll();
        }
    }
}
