﻿using UnityEngine;
using System.IO;
using UnityEditor;
using GS.Data;

namespace GS.Net
{
    [CreateAssetMenu(
        fileName = "SavingSystemConfigSO",
        menuName = "ScriptableObjects/SavingSystemConfigSO"
    )]
    public class SavingSystemConfigSO : ScriptableObject
    {
        private const string SAVING_SYSTEM_CONFIG_TAG = "SavingSystemConfigSO";

        private static SavingSystemConfigSO instance;
        public static SavingSystemConfigSO Instance
        {
            get
            {
                instance =
                    instance ?? Resources.Load<SavingSystemConfigSO>(SAVING_SYSTEM_CONFIG_TAG);
                return instance;
            }
        }

        public bool enabled;
        public string connectionTesterLink = "http://google.com/";
        public string offlineModeEncryptionKey;
        public string offlineModeEncryptionSalt;

        public string requestFileName;

        public int requestQueueLength = 10;
        public long offlineTimeLimit = 7200000;

        [Button("DeleteRequestFile")]
        public bool deleteRequestFile;

        [Space(10)]
        public string responseFileName;

        [Button("DeleteResponseFile")]
        public bool deleteResponseFile;

        [Space(10)]
        [Button("DeleteAllFile")]
        public bool deleteAllFile;

        [Button("OpenPersistentDataPath")]
        public bool openPersistentDataPath;
        public float requestTimeoutTimer = 90f;

        private string fullRequestFileName;
        private string fullResponseFileName;
        public float minimumLoadPercentage = 0.1f;

        public string GetFulRequestFileName
        {
            get
            {
                if (string.IsNullOrEmpty(fullRequestFileName))
                {
                    fullRequestFileName = Path.Combine(
                        Application.persistentDataPath,
                        requestFileName
                    );
                }

                return fullRequestFileName;
            }
        }

        public string GetFulResponseFileName
        {
            get
            {
                if (string.IsNullOrEmpty(fullResponseFileName))
                {
                    fullResponseFileName = Path.Combine(
                        Application.persistentDataPath,
                        responseFileName
                    );
                }

                return fullResponseFileName;
            }
        }

        public static void Initialize()
        {
#if USE_ADDRESSABLES
            AddressableHandler.LoadAsset<SavingSystemConfigSO>(
                SAVING_SYSTEM_CONFIG_TAG,
                config =>
                {
                    instance = config;
                }
            );
#else
            instance = instance ?? Resources.Load<SavingSystemConfigSO>(SAVING_SYSTEM_CONFIG_TAG);
#endif
        }

        public void OpenPersistentDataPath()
        {
#if UNITY_EDITOR
            if (File.Exists(GetFulResponseFileName))
            {
                EditorUtility.RevealInFinder(GetFulResponseFileName);
            }
            else
            {
                EditorUtility.RevealInFinder(Application.persistentDataPath + "/");
            }
#endif
        }

        public void DeleteRequestFile()
        {
            File.Delete(GetFulRequestFileName);
        }

        public void DeleteResponseFile()
        {
            File.Delete(GetFulResponseFileName);
        }

        public void DeleteAllFile()
        {
            DeleteRequestFile();
            DeleteResponseFile();
        }
    }
}
