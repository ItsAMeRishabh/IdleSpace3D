﻿using UnityEngine;

namespace GS
{
    /// <summary>
    /// Saves all Game parameters and progressions in Player Prefs
    /// </summary>
    internal class SaveManager
    {
        #region Other
        /// <summary>
        /// Clears the save data.
        /// </summary>
        public void ClearSaveData()
        {
            PlayerPrefs.DeleteAll();
            Log.Print("Deleted All Playerprefs Keys");
        }

        /// <summary>
        /// Deletes the key.
        /// </summary>
        /// <param name="key">Key.</param>
        public void DeleteKey(string key)
        {
            PlayerPrefs.DeleteKey(key);
        }

        /// <summary>
        /// Does the key already Exists
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool HasKey(string key)
        {
            return PlayerPrefs.HasKey(key);
        }

        #endregion

        #region Setters

        /// <summary>
        /// Sets the int.
        /// </summary>
        /// <param name="key">Key.</param>
        /// <param name="val">Value.</param>
        public void SetInt(string key, int val)
        {
            PlayerPrefs.SetInt(key, val);
        }

        /// <summary>
        /// Sets the float.
        /// </summary>
        /// <param name="key">Key.</param>
        /// <param name="val">Value.</param>
        public void SetFloat(string key, float val)
        {
            PlayerPrefs.SetFloat(key, val);
        }

        /// <summary>
        /// Sets the string.
        /// </summary>
        /// <param name="key">Key.</param>
        /// <param name="val">Value.</param>
        public void SetString(string key, string val)
        {
            PlayerPrefs.SetString(key, val);
        }

        public void SetBool(string key, bool val)
        {
            int value = System.Convert.ToInt32(val);
            SetInt(key, value);
        }

        #endregion

        #region Getters

        /// <summary>
        /// Gets the int.
        /// </summary>
        /// <returns>The int.</returns>
        /// <param name="key">Key.</param>
        public int GetInt(string key, int defaultVal = 0)
        {
            return PlayerPrefs.GetInt(key, defaultVal);
        }

        /// <summary>
        /// Gets the value of float type.
        /// </summary>
        /// <returns>The float.</returns>
        /// <param name="key">Key.</param>
        public float GetFloat(string key, float defaultVal = 0)
        {
            return PlayerPrefs.GetFloat(key, defaultVal);
        }

        /// <summary>
        /// Gets the value of string type.
        /// </summary>
        /// <returns>The string.</returns>
        /// <param name="key">Key.</param>
        public string GetString(string key, string defaultVal = "")
        {
            return PlayerPrefs.GetString(key, defaultVal);
        }

        /// <summary>
        /// Gets the value of bool type
        /// </summary>
        /// <param name="key"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        public bool GetBool(string key, bool val = false)
        {
            return System.Convert.ToBoolean(GetInt(key, System.Convert.ToInt32(val)));
        }

        #endregion
    }
}