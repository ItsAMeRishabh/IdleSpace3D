﻿using GS.GameEvents.Save;

namespace GS
{
    /// <summary>
    /// This class listens all save events and set/gets data from SaveManager
    /// </summary>
    public class SaveManagerController : IController
    {
        SaveManager saveManager;

        public void Initialize()
        {
            saveManager = new SaveManager();
        }

        public void RegisterListener()
        {
            //EventManager.Instance.AddListener<SaveManagerEvent>(EventListner);
            EventManager.Instance.AddListener<SaveManagerEventInt>(EventListenerInt);
            EventManager.Instance.AddListener<SaveManagerEventFloat>(EventListenerFloat);
            EventManager.Instance.AddListener<SaveManagerEventBool>(EventListenerBool);
            EventManager.Instance.AddListener<SaveManagerEventString>(EventListenerString);
        }

        public void Release()
        {
        }

        public void UnRegisterListener()
        {
            //EventManager.Instance.RemoveListener<SaveManagerEvent>(EventListner);
            EventManager.Instance.RemoveListener<SaveManagerEventInt>(EventListenerInt);
            EventManager.Instance.RemoveListener<SaveManagerEventFloat>(EventListenerFloat);
            EventManager.Instance.RemoveListener<SaveManagerEventBool>(EventListenerBool);
            EventManager.Instance.RemoveListener<SaveManagerEventString>(EventListenerString);
        }

        public void Update()
        {

        }

        /// <summary>
        /// For Get/Set Int values
        /// </summary>
        /// <param name="eve"></param>
        private void EventListenerInt(SaveManagerEventInt eve)
        {
            if (eve.callback == null)
            {
                // As it is not expecting callback, save passed value
                saveManager.SetInt(eve.keyName, eve.val);
            }
            else
            {
                eve.callback(saveManager.GetInt(eve.keyName, eve.val));
            }
        }

        /// <summary>
        /// For Get/Set Float values
        /// </summary>
        /// <param name="eve"></param>
        private void EventListenerFloat(SaveManagerEventFloat eve)
        {
            if (eve.callback == null)
            {
                // As it is not expecting callback, save passed value
                saveManager.SetFloat(eve.keyName, eve.val);
            }
            else
            {
                eve.callback(saveManager.GetFloat(eve.keyName, eve.val));
            }
        }

        /// <summary>
        /// For Get/Set Boolean values
        /// </summary>
        /// <param name="eve"></param>
        private void EventListenerBool(SaveManagerEventBool eve)
        {
            if (eve.callback == null)
            {
                // As it is not expecting callback, save passed value
                saveManager.SetBool(eve.keyName, eve.val);
            }
            else
            {
                eve.callback(saveManager.GetBool(eve.keyName, eve.val));
            }
        }

        /// <summary>
        /// For Get/Set String values
        /// </summary>
        /// <param name="eve"></param>
        private void EventListenerString(SaveManagerEventString eve)
        {
            if (eve.callback == null)
            {
                // As it is not expecting callback, save passed value
                saveManager.SetString(eve.keyName, eve.val);
            }
            else
            {
                eve.callback(saveManager.GetString(eve.keyName, eve.val));
            }
        }

    } // Class
} // Namespace