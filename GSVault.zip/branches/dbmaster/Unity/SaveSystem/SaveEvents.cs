﻿using System;


namespace GS
{
    namespace GameEvents
    {
        #region SaveManager Events
        namespace Save
        {
            /// <summary>
            /// Base Event for saveManager to save a value in playerPref. Dont use class diectly in other modules
            /// </summary>
            /// <typeparam name="T"></typeparam>
            public class SaveManagerBaseEvent<T> : GameEvent
            {
                public string keyName { get; private set; }
                public T val { get; private set; }

                public System.Action<T> callback { get; private set; }
                public bool IsSet { get { return (callback == null); }
            }

                /// <summary>
                /// Sets given value with keyName
                /// </summary>
                /// <param name="keyName">Pref Key</param>
                /// <param name="val">Value</param>
                protected SaveManagerBaseEvent(string keyName, T val)
                {
                    this.keyName = keyName;
                    this.val = val;
                }

                /// <summary>
                /// Rises callback with value of given playerPref key. If not found returns 'passed' default value
                /// </summary>
                /// <param name="callback"></param>
                /// <param name="keyName">Player Pref Key</param>
                /// <param name="defaultVal">DefaultValue to be returned if not found</param>
                protected SaveManagerBaseEvent(System.Action<T> callback, string keyName, T defaultVal)
                {
                    this.callback = callback;
                    this.keyName = keyName;
                    this.val = defaultVal;
                }
            }

            /// <summary>
            /// Saves/Retrives 'Int' value in playerPrefs
            /// </summary>
            public class SaveManagerEventInt : SaveManagerBaseEvent<int>
            {
                /// <summary>
                /// Sets given value with keyName
                /// </summary>
                /// <param name="keyName">Pref Key</param>
                /// <param name="val">Value</param>
                public SaveManagerEventInt(string keyName, int val) : base(keyName, val)
                {

                }

                /// <summary>
                /// Rises callback with value of given playerPref key. If not found returns 'passed' default value
                /// </summary>
                /// <param name="callback"></param>
                /// <param name="keyName">Player Pref Key</param>
                /// <param name="defaultVal">DefaultValue to be returned if not found</param>
                public SaveManagerEventInt(System.Action<int> callback, string keyName, int defaultVal) : base(callback, keyName, defaultVal)
                {

                }
            }

            /// <summary>
            /// Saves/Retrives 'Float' value in playerPrefs
            /// </summary>
            public class SaveManagerEventFloat : SaveManagerBaseEvent<float>
            {
                /// <summary>
                /// Sets given value with keyName
                /// </summary>
                /// <param name="keyName">Pref Key</param>
                /// <param name="val">Value</param>
                public SaveManagerEventFloat(string keyName, float val) : base(keyName, val)
                {

                }

                /// <summary>
                /// Rises callback with value of given playerPref key. If not found returns 'passed' default value
                /// </summary>
                /// <param name="callback"></param>
                /// <param name="keyName">Player Pref Key</param>
                /// <param name="defaultVal">DefaultValue to be returned if not found</param>
                public SaveManagerEventFloat(System.Action<float> callback, string keyName, float defaultVal) : base(callback, keyName, defaultVal)
                {

                }
            }

            /// <summary>
            /// Saves/Retrives 'Bool' value in playerPrefs
            /// </summary>
            public class SaveManagerEventBool : SaveManagerBaseEvent<bool>
            {
                /// <summary>
                /// Sets given value with keyName
                /// </summary>
                /// <param name="keyName">Pref Key</param>
                /// <param name="val">Value</param>
                public SaveManagerEventBool(string keyName, bool val) : base(keyName, val)
                {

                }

                /// <summary>
                /// Rises callback with value of given playerPref key. If not found returns 'passed' default value
                /// </summary>
                /// <param name="callback"></param>
                /// <param name="keyName">Player Pref Key</param>
                /// <param name="defaultVal">DefaultValue to be returned if not found</param>
                public SaveManagerEventBool(System.Action<bool> callback, string keyName, bool defaultVal) : base(callback, keyName, defaultVal)
                {

                }
            }

            /// <summary>
            /// Saves/Retrives 'String' value in playerPrefs
            /// </summary>
            public class SaveManagerEventString : SaveManagerBaseEvent<string>
            {
                /// <summary>
                /// Sets given value with keyName
                /// </summary>
                /// <param name="keyName">Pref Key</param>
                /// <param name="val">Value</param>
                public SaveManagerEventString(string keyName, string val) : base(keyName, val)
                {

                }

                /// <summary>
                /// Rises callback with value of given playerPref key. If not found returns 'passed' default value
                /// </summary>
                /// <param name="callback"></param>
                /// <param name="keyName">Player Pref Key</param>
                /// <param name="defaultVal">DefaultValue to be returned if not found</param>
                public SaveManagerEventString(System.Action<string> callback, string keyName, string defaultVal) : base(callback, keyName, defaultVal)
                {

                }
            }
        }

        #endregion SaveManager Events
    }
}