﻿using UnityEngine;

namespace GS
{
    /// <summary>
    /// IMonoState class is base class Mono bahaviour class which acts like state for a State Machine
    /// </summary>
    public class IMonoState : MonoBehaviour, IState
    {
        /// <summary>
        /// Whether from this state can go back to previous state
        /// </summary>
        [SerializeField]
        protected bool canGoBack = false;

        /// <summary>
        /// Flag whther this state to be added to Previous Stack or not
        /// </summary>
        [SerializeField]
        protected bool addToPreviousStack = false;

        /// <summary>
        /// If true, this state will never calls DoBeforeLeaving Method
        /// </summary>
        [SerializeField]
        protected bool alwaysVisible = false;

        /// <summary>
        /// Can go back to previous Screen
        /// </summary>
        public bool CanGoBack
        {
            get
            {
                return canGoBack;
            }
            set
            {
                canGoBack = value;
            }
        }

        /// <summary>
        /// Can this state will be added to previoius stack list or not
        /// </summary>
        public bool AddToPreviousStack
        {
            get
            {
                return addToPreviousStack;
            }
            set {
                addToPreviousStack = value;
            }
        }

        /// <summary>
        /// Called while entering into this state
        /// </summary>
        public virtual void DoBeforeEntering()
        {
            gameObject.SetActive(true);
        }

        /// <summary>
        /// Called while leaving this state
        /// </summary>
        public virtual void DoBeforeLeaving()
        {
            if (!alwaysVisible)
            {
                gameObject.SetActive(false);
            }
		}
        
        /// <summary>
        /// Gets the state index
        /// </summary>
        /// <returns></returns>
        public virtual int GetStateID()
        {
            return 0;
        }

        public virtual void Initialize()
        {
            
        }

        public virtual void Release()
        {
            
        }

        public virtual void UpdateState()
        {
            
        }
    }
}
