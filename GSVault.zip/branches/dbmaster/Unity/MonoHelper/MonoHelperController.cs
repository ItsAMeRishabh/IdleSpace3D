﻿using System;
using GS.GameEvents;
using UnityEngine;

namespace GS
{
    namespace Unity
    {
        /// <summary>
        /// This controller interacts with MonoHelper class
        /// </summary>
        public class MonoHelperController<TSettingType, TPacketType> : IController
            where TSettingType : Enum
            where TPacketType : Enum
        {
            /// <summary>
            /// Monohelper instance reference
            /// </summary>
            private MonoHelper helper;

            /// <summary>
            /// Creates an instance for MonoHelper class
            /// </summary>
            public void Initialize()
            {
                GameObject go = GS.MainEntry<TSettingType, TPacketType>.Instance.gameObject;
                if (go != null)
                {
                    helper = go.AddComponent<MonoHelper>();
#if UNITY_EDITOR
                    // Highlighting GameObject in Hierarchy Window 
                    UnityExtensions.MarkAsGSObject(go);
#endif
                }
            }

            /// <summary>
            /// Register events here
            /// </summary>
            public void RegisterListener()
            {
                Utils.EM.AddListener<GameEvents.StartCoroutineEvent>(OnStartCoRoutineListener);
                Utils.EM.AddListener<GameEvents.StopCoroutineEvent>(OnStopCoRoutineListener);
                Utils.EM.AddListener<GameEvents.InvokeActionEvent>(OnInvokeActionListener);
                Utils.EM.AddListener<GameEvents.InvokeRepeateActionEvent>(OnInvokeRepeateActionListener);
                Utils.EM.AddListener<GameEvents.CancelInvokeActionEvent>(OnCancelInvokeActionListener);
                Utils.EM.AddListener<GameEvents.RunOnUnityMainThreadEvent>(OnRunOnUnityMainThread);
            }

            /// <summary>
            /// Unregisters events here
            /// </summary>
            public void UnRegisterListener()
            {
                Utils.EM.RemoveListener<GameEvents.StartCoroutineEvent>(OnStartCoRoutineListener);
                Utils.EM.RemoveListener<GameEvents.StopCoroutineEvent>(OnStopCoRoutineListener);
                Utils.EM.RemoveListener<GameEvents.InvokeActionEvent>(OnInvokeActionListener);
                Utils.EM.RemoveListener<GameEvents.InvokeRepeateActionEvent>(OnInvokeRepeateActionListener);
                Utils.EM.RemoveListener<GameEvents.CancelInvokeActionEvent>(OnCancelInvokeActionListener);
                Utils.EM.RemoveListener<GameEvents.RunOnUnityMainThreadEvent>(OnRunOnUnityMainThread);
            }



			private void OnStopCoRoutineListener(StopCoroutineEvent coroutineEve)
            {
                if (coroutineEve == null || helper == null)
                    return;

                helper.StopCoroutine(coroutineEve.routine);
            }


            /// <summary>
            /// Releases 
            /// </summary>
            public void Release()
            {
                if(helper != null)
                    GameObject.Destroy(helper.gameObject);
            }

          
            public void Update()
            {

            }

            /// <summary>
            /// Callback function for Start Couroutine Listener 
            /// </summary>
            /// <param name="coroutineEvent"></param>
            private void OnStartCoRoutineListener(GameEvents.StartCoroutineEvent coroutineEvent)
            {
                if (coroutineEvent == null || helper == null)
                    return;

                helper.StartCoroutine(coroutineEvent.routine);
            }

            /// <summary>
            /// Callback to InvokeAction Listener
            /// </summary>
            /// <param name="e"></param>
            private void OnInvokeRepeateActionListener(InvokeRepeateActionEvent invokeRepeateActionEvent)
            {
                if (invokeRepeateActionEvent == null || helper == null)
                    return;

                helper.InvokeCallback(invokeRepeateActionEvent.action, invokeRepeateActionEvent.repeateWait, invokeRepeateActionEvent.actionKey, true);
            }

            /// <summary>
            /// Callback to InvokeAction Listener
            /// </summary>
            /// <param name="e"></param>
            private void OnInvokeActionListener(InvokeActionEvent invokeActionEvent)
            {
                if (invokeActionEvent == null || helper == null)
                    return;

                helper.InvokeCallback(invokeActionEvent.action, invokeActionEvent.duration, invokeActionEvent.actionKey, false);
            }

            /// <summary>
            /// Cancel Invoke Action Listener
            /// </summary>
            /// <param name="cancelInvokeActionEvent"></param>
            private void OnCancelInvokeActionListener(CancelInvokeActionEvent cancelInvokeActionEvent)
            {
                if(helper == null)
                {
                    return;
                }

                helper.CancelInvokeWithKey(cancelInvokeActionEvent.key);
            }

			private void OnRunOnUnityMainThread(RunOnUnityMainThreadEvent eventData)
			{
				if (eventData == null || helper == null)
					return;

				helper.Enqueue(eventData.action);
			}
		}
    }
}
