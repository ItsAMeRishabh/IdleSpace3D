﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Unity
{
    /// <summary>
    /// Monobehaviour functionalities which can be useful for non monobahaviour classes
    /// </summary>
    public class MonoHelper : MonoBehaviour
    {


        /// <summary>
        /// Action information which holds the duration and action to be called
        /// </summary>
        class ActionInfo
        {
            public float timer = 0.0f, duration;
            public System.Action action;
            public bool completed = false;
            public bool canRepeate = false;

            public ActionInfo(System.Action action, float duration, bool canRepeate = false)
            {
                this.duration = duration;
                timer = duration;
                this.action = action;
                completed = false;
                this.canRepeate = canRepeate;
            }

            /// <summary>
            /// Updates all timers to invoke callback and delete callback once it is completed
            /// </summary>
            public bool Update()
            {
                if (completed)
                    return completed;

                timer -= Time.deltaTime;
                if (timer <= 0.0f)
                {
                    action();
                    if (!canRepeate)
                    {
                        completed = true;
                    }
                    else
                    {
                        timer = duration;
                    }
                }
                return completed;
            }

            public void StopAction()
            {
                completed = true;
            }
        }

        /// <summary>
        /// Holds list of callback to be invoked
        /// </summary>
        List<ActionInfo> callbacks;

        /// <summary>
        /// Hold key and callbacks references this helps in cancelation of invokes
        /// </summary>
        private Dictionary<string, List<ActionInfo>> keyActionsDic= new Dictionary<string, List<ActionInfo>>();

		private static readonly Queue<Action> executionQueue = new Queue<Action>();

		//awake
		private void Awake()
        {
            callbacks = new List<ActionInfo>();
            DontDestroyOnLoad(this);
        }

		/// <summary>
		/// Updates all timers to invoke callback and delete callback once it is completed
		/// </summary>
		void Update()
        {
			lock (executionQueue)
			{
				while (executionQueue.Count > 0)
				{
					executionQueue.Dequeue().Invoke();
				}
			}

			bool checkForRemove = false;

            if (callbacks == null)
                return;
            // checking if any callback just completed
            for (int i = 0; i < callbacks.Count; i++)
            {
                if (callbacks[i].Update())
                    checkForRemove = true;
            }

            if (checkForRemove)
                callbacks.RemoveAll(s => s.completed);
        }

        /// <summary>
        /// Clears all active callbacks
        /// </summary>
        public void ClearAllActions()
        {
            callbacks.Clear();
        }

        /// <summary>
        /// Invokes Action Method after some duration
        /// </summary>
        /// <param name="action"></param>
        /// <param name="duration"></param>
        public void InvokeCallback(System.Action action, float duration, string key, bool canRepeate = false)
        {
            if (callbacks == null)
                callbacks = new List<ActionInfo>();

            ActionInfo actionInfo = new ActionInfo(action, duration, canRepeate);
            callbacks.Add(actionInfo);

            if (!string.IsNullOrEmpty(key))
            {
                if (keyActionsDic.ContainsKey(key))
                {
                    keyActionsDic[key].Add(actionInfo);
                }
                else
                {
                    keyActionsDic[key] = new List<ActionInfo>();
                    keyActionsDic[key].Add(actionInfo);
                }
            }
        }

        public void CancelInvokeWithKey(string key)
        {
            if (keyActionsDic.ContainsKey(key))
            {
                for (int i = 0; i < keyActionsDic[key].Count; i++)
                {
                    keyActionsDic[key][i].StopAction();
                }
            }
        }

		public void Enqueue(Action action)
		{
			lock (executionQueue)
			{
				executionQueue.Enqueue(action);
			}
		}


		/// <summary>
		/// Raises an event on minimize/maximize app
		/// </summary>
		/// <param name="focus"></param>
		private void OnApplicationFocus(bool focus)
        {
            Utils.EventSync(new GameEvents.ApplicationFocusEvent(focus));
        }

        /// <summary>
        /// Set the game state to QUITTING when the application is quitting.
        /// </summary>
        void OnApplicationQuit()
        {
            Utils.EventSync(new GameEvents.ChangeGameState(GameConsts.GameState.Quitting));
            Utils.EventSync(new GameEvents.ApplicationQuitEvent());
        }
    }
}
