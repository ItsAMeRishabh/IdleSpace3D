﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Unity
{
    public class CameraManager
    {
        public List<GameCamera> sceneCameras = null;

        /// <summary>
        /// Holds referrence for active camera in scene..
        /// </summary>
        public GameCamera currentCamera = null;
        public GameCamera prevCamera = null;
        public int currentCameraState;


        /// <summary>
        /// Sets the camera to given ID
        /// </summary>
        /// <param name="camID"></param>
        public GameCamera EnableCamera(int camID)
        {
            GameCamera cam = GetCamera(camID);
            if (cam != null)
            {
                currentCamera.gameObject.SetActive(false);
                prevCamera = currentCamera;
                currentCamera = cam;
                currentCamera.gameObject.SetActive(true);
                return cam;
            }
            Log.Print("Could not found the camera : " + camID.ToString() + ", please re-check the Cam IDs set to each GameCamera", LogFilter.Game);
            return null;

        }

        /// <summary>
        /// Returns the GameCamera with ID...
        /// </summary>
        /// <param name="camID"></param>
        /// <returns></returns>
        public GameCamera GetCamera(int camID)
        {
            // foreach (GameCamera camSetup in sceneCameras)
            for (int i = 0; i < sceneCameras.Count; i++)
            {
                GameCamera camSetup = sceneCameras[i];
                if (camSetup.CamType == camID)
                {
                    return camSetup;
                }
            }

            return null;
        }

        /// <summary>
        /// Set Cameras list from scene and sets the default camera...
        /// </summary>
        public void Initialize(List<GameCamera> cameras)
        {
            if (cameras != null)
            {
                sceneCameras = cameras;
            }

            //Set current Camera.
            if (currentCamera == null && sceneCameras.Count > 0)
            {
                currentCamera = sceneCameras[0];
            }
        }

        /// <summary>
        /// Enables/ Disbales additional Camera without affecting current camera
        /// </summary>
        /// <param name="type"></param>
        public void EnableAdditionalCamera(int type, bool isEnable)
        {
            GameCamera cam = GetCamera(type);
            if (cam != null)
                cam.gameObject.SetActive(isEnable);
        }

        /// <summary>
        /// Sets the current camera State
        /// </summary>
        /// <param name="type"></param>
        public void SwitchCamera(int type)
        {
            if (currentCamera != null && currentCamera.CamType == type)
                return;
            if (currentCamera != null)
                currentCamera.gameObject.SetActive(false);
            currentCamera = GetCamera(type);
            if (currentCamera != null)
                currentCamera.gameObject.SetActive(true);
        }
    }
}
