﻿using System;
using UnityEngine;

namespace GS.Unity
{
    [RequireComponent(typeof(Camera))]
    public class GameCamera : MonoBehaviour 
    {
        protected int camType; //Defines the Camera ID
        private Camera assosiatedCamera = null;

        public Camera AssosiatedCamera
        {
            get
            {
                return assosiatedCamera;
            }
        }


        public int CamType
        {
            get
            {
                return camType;
            }
        }

        // Start is called before the first frame update
        void Awake()
        {
            assosiatedCamera = GetComponent<Camera>();
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}