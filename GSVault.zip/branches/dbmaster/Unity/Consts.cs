﻿/* Const.cs
 * Decalre all common costants here which can be used in any project
 */


using UnityEngine;

namespace GS
{
    namespace GameConsts
    {

        /// <summary>
        /// Define the operation type of UI Screen
        /// </summary>
        public enum UIScreenEventType
        {
            Switch,
            Add,
        }

        /// <summary>
        /// Game Language Type
        /// </summary>
        public enum Language
        {
            Default,
            English,
            Hindi
        }

        /// <summary>
        /// Game Difficulty Level
        /// </summary>
        public enum Difficulty
        {
            Easy = 0,
            Medium,
            Hard,
        }

        /// <summary>
        /// Swipe Gesture direction
        /// </summary>
        public enum SwipeDirection
        {
            None = 0,
            Up,
            Right,
            Down,
            Left,
            UpRight,
            Upleft,
            DownRight,
            DownLeft
        }




        /// <summary>
        /// Determains Swipe length....
        /// </summary>
        public enum SwipeLength
        {
            Short = 0,
            Long
        }

        /// <summary>
        /// Defines the Tutorial Status
        /// </summary>
        public enum TutorialStatus
        {
            None = 0,
            InProgress,
            Finished,
        }







        /// <summary>
        /// General Settings parameter types
        /// </summary>
        public enum GeneralSettingType
        {
            // Sounds / Volume
            MasterVolume,
            MusicVolume,
            SFXVolume,
            VoiceVoulme
        }

        /// <summary>
        /// Types of Store items
        /// </summary>
        public enum StoreItemType
        {
            None = 0,
            ConsumableItem,
            SubscriptionItem,
            EquippableItem,
            NonConsumableItem
        }

        /// <summary>
        /// Types of Store item purchase modes
        /// </summary>
        public enum StoreItemPurchaseMode
        {
            None = 0,
            SoftCurrencyPurchaseMode,
            HardCurrencyPurchaseMode,
            RealMoneyPurchaseMode,
            WatchRewardVideo
        }

        public enum SoftCurrencyType
        {
            none,
            Coin,
            Energy
        }

        //UI popup types
        public enum UIPopupType
        {
            Info = 0,
            Prompt,
            Timed,
            Static
        }

        public enum UIPopUpPrefabType
        {
            Basic,
            PayTm
        }

    public enum GameGraphicsType
    { 
      SD,
      HD
    }

        /// <summary>
        /// All game states.
        /// </summary>
    public enum GameState
        {
            NullState = 0,
            Intro,
            Menu,
            Loading,
            InGame,
            Paused,
            EndGame,
            Quitting
        }

        public enum AssetsGraphicsType
        {
            Lite,
            HD
        }

        public enum AudioChannelType
        {
            BGM,
            SFX,
            Voise
        }
    }
}