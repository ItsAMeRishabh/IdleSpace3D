﻿using UnityEngine;
using GS.GameEvents;
using UnityEngine.EventSystems;

namespace GS
{
    /// <summary>
    /// This class handles all Game inputs (not UI).
    /// </summary>
    public class InputManager
    {
        /// <summary>
        /// Minimum Drag Length to consider as Swipe
        /// </summary>
        public float minSwipeLength = 15f;
        //public int shortSwipePercentage = 5;
        /// <summary>
        /// Long Swipe Percentage with respect to Screen Width
        /// </summary>
        public int longSwipePercentage = 10;

        /// <summary>
        /// Intial mouse/Tap Position on begin Drag
        /// </summary>
        private Vector2 _initialClickPos = Vector2.zero;

        /// <summary>
        /// Drag Release Position
        /// </summary>
        private Vector2 _finalClickPos = Vector2.zero;

        /// <summary>
        /// Time duration of swipe
        /// </summary>
        private float _swipeTime = 0.0f;

        /// <summary>
        /// current swipe Direction Vector
        /// </summary>
        private Vector2 _currentSwipe = Vector2.zero;

        /// <summary>
        /// Current Swipe Direction
        /// </summary>
        public static GameConsts.SwipeDirection swipeDirection = GameConsts.SwipeDirection.None;

        /// <summary>
        /// Allows drag functionality
        /// </summary>
        public bool canDrag = true;

        /// <summary>
        /// Allow processing input
        /// </summary>
        public bool canTakeInput = false;

        public bool isOverUI = false;


        public float holdTime = 0.3f;
        public float holdMaxLength = 700;
        private float holdTimeElapsed = 0.0f;

        private EventSystem eventSystem; 
        /// <summary>
        /// Determines current Swipe Length
        /// </summary>
        [SerializeField]
        private GameConsts.SwipeLength _swipeLength = GameConsts.SwipeLength.Short;

        private DragEvent dragEvent = new DragEvent();

        private DragUIEvent dragUIEvent = new DragUIEvent();

        private HoldTapEvent holdTapEvent = new HoldTapEvent();

        /// <summary>
        /// Holds all possible types of direction vectors
        /// These value compares with drag direction vector
        /// </summary>
        class GetCardinalDirections
        {
            public static readonly Vector2 Up = new Vector2(0, 1);
            public static readonly Vector2 Down = new Vector2(0, -1);
            public static readonly Vector2 Right = new Vector2(1, 0);
            public static readonly Vector2 Left = new Vector2(-1, 0);

            public static readonly Vector2 UpRight = new Vector2(1, 1);
            public static readonly Vector2 UpLeft = new Vector2(-1, 1);
            public static readonly Vector2 DownRight = new Vector2(1, -1);
            public static readonly Vector2 DownLeft = new Vector2(-1, -1);
        }

        public InputManager()
        {
            eventSystem = EventSystem.current;
            if (eventSystem == null)
                Log.Error("Please Add Event System in scene");
        }


        /// <summary>
        /// Detecting swipe based on touch inputs
        /// </summary>
        public void Update()
        {
            if (canTakeInput)
                DetectSwipe();

            // Rasing device back button for Android or Escape button in Keybaord
            if (Input.GetKeyDown(KeyCode.Escape))
                Utils.EventSync(new Events.BackKeyPressed());
        }

        /// <summary>
        /// This detects the current swipe direction on Mobies/Touch devices as well as with Mouse.
        /// </summary>
        void DetectSwipe()
        {
            //For Mobile devices....
            if (Input.touches.Length > 0)
            {
                Touch t = Input.GetTouch(0);



                if (t.phase == TouchPhase.Began)
                {

                    SetInitialTouchPos(t.position);
                }

                if (t.phase == TouchPhase.Moved && canDrag)
                {
                    UpdateTouchPos(t.position);
                }

                if (t.phase == TouchPhase.Ended)
                {
                    EndTouchPos(t.position);
                }
            }
            else
            {
                //For PC
                if (Input.GetMouseButtonDown(0))
                {

                    SetInitialTouchPos(Input.mousePosition);
                }
                else if (Input.GetMouseButton(0) && canDrag)
                {
                    UpdateTouchPos(Input.mousePosition);
                }
                else
                {
                    swipeDirection = GameConsts.SwipeDirection.None;
                }

                if (Input.GetMouseButtonUp(0))
                {
                    EndTouchPos(Input.mousePosition);
                }
            }
        }

        /// <summary>
        /// Sets the initial position of the Touch/Mouse
        /// </summary>
        /// <param name="val"></param>
        private void SetInitialTouchPos(Vector3 val)
        {
            // Ignoring Tap Event if mouse over any UI Element

            isOverUI = UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject();

            holdTimeElapsed = 0.0f;
            if (isOverUI)
            {
                dragUIEvent.direction = _currentSwipe;
                dragUIEvent.position = val;
            }

#if UNITY_ANDROID
        //TODO:(VK REDDY) for multiple touch scenarios loop through touch count to check if other touch are over UI
        if (Input.touchCount > 0)
            isOverUI = UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId);
#endif

            _initialClickPos = new Vector2(val.x, val.y);
            _swipeTime = 0.0f;
            _swipeLength = GameConsts.SwipeLength.Short;
        }

        /// <summary>
        /// Updates Touch Pos...
        /// </summary>
        /// <param name="pos"></param>
        private void UpdateTouchPos(Vector3 pos)
        {

            _swipeTime += Time.deltaTime;
            _finalClickPos.x = pos.x;
            _finalClickPos.y = pos.y;

            _currentSwipe.x = _finalClickPos.x - _initialClickPos.x;
            _currentSwipe.y = _finalClickPos.y - _initialClickPos.y;

            swipeDirection = GetSwipeDir(_currentSwipe);
            dragEvent.currentPosition = pos;
            dragEvent.dragDirection = _currentSwipe;
            dragEvent.swipeDirection = swipeDirection;
            dragEvent.dragEnd = false;

            dragUIEvent.position = pos;
            dragUIEvent.direction = _currentSwipe;

            holdTimeElapsed += Time.deltaTime;

            if (holdTimeElapsed > holdTime && (Screen.width * (_currentSwipe.magnitude / 100f)) < holdMaxLength)
            {
                holdTimeElapsed = -1000.0f; // To avoid raising multiple Events

                holdTapEvent.mousePosition = pos;
                EventManager.Instance.TriggerEvent(holdTapEvent);
            }


            if (!isOverUI)
                EventManager.Instance.QueueEvent(dragEvent);
            else
            {
                dragUIEvent.isDrag = true;
                EventManager.Instance.QueueEvent(dragUIEvent);
            }

        }

        /// <summary>
        /// Ends the touch update...
        /// </summary>
        /// <param name="pos"></param>
        private void EndTouchPos(Vector3 pos)
        {
            _finalClickPos.x = pos.x;
            _finalClickPos.y = pos.y;

            _currentSwipe.x = _finalClickPos.x - _initialClickPos.x;
            _currentSwipe.y = _finalClickPos.y - _initialClickPos.y;

            holdTimeElapsed = 0.0f;
            Utils.EventAsync(new TAPEvent(pos, isOverUI));

            // if is over UI on Mouse begin ognore swipe and drag events
            if (isOverUI)
            {
                dragUIEvent.position = pos;
                dragUIEvent.direction = _currentSwipe;
                dragUIEvent.isDrag = false;
                EventManager.Instance.QueueEvent(dragUIEvent);
            }

            swipeDirection = GetSwipeDir(_currentSwipe);
            _swipeLength = GetSwipeLength(_currentSwipe);

            Vector2 normalizedVector = _currentSwipe / Screen.width;
            //Register an event about swipe.
            Utils.EventAsync(new SwipeEvent(swipeDirection, normalizedVector, _swipeLength, isOverUI));


            if (!isOverUI)
            {
                dragEvent.swipeDirection = swipeDirection;
                dragEvent.dragDirection = _currentSwipe.normalized;
                dragEvent.currentPosition = pos;
                dragEvent.dragEnd = true;

                Utils.EventAsync(dragEvent);
            }
        }

        private GameConsts.SwipeLength GetSwipeLength(Vector2 currSwipe)
        {
            if (currSwipe.magnitude > (Screen.width * (longSwipePercentage / 100f)))
                return GameConsts.SwipeLength.Long;

            return GameConsts.SwipeLength.Short;
        }

        /// <summary>
        /// Returns the direction player has swiped...
        /// </summary>
        /// <param name="currSwipe"></param>
        /// <returns></returns>
        public GameConsts.SwipeDirection GetSwipeDir(Vector2 currSwipe, bool ignoreMagnitude = false)
        {
            GameConsts.SwipeDirection swipeDir = GameConsts.SwipeDirection.None;

            if (currSwipe.magnitude > minSwipeLength || ignoreMagnitude)
            {
                currSwipe.Normalize();

                //0.906 is euqivalent to Cos(25);

                if (Vector2.Dot(currSwipe, GetCardinalDirections.Up) > 0.906f)
                    return GameConsts.SwipeDirection.Up;
                if (Vector2.Dot(currSwipe, GetCardinalDirections.Down) > 0.906f)
                    return GameConsts.SwipeDirection.Down;
                if (Vector2.Dot(currSwipe, GetCardinalDirections.Left) > 0.906f)
                    return GameConsts.SwipeDirection.Left;
                if (Vector2.Dot(currSwipe, GetCardinalDirections.Right) > 0.906f)
                    return GameConsts.SwipeDirection.Right;
                if (Vector2.Dot(currSwipe, GetCardinalDirections.UpRight) > 0.906f)
                    return GameConsts.SwipeDirection.UpRight;
                if (Vector2.Dot(currSwipe, GetCardinalDirections.UpLeft) > 0.906f)
                    return GameConsts.SwipeDirection.Upleft;
                if (Vector2.Dot(currSwipe, GetCardinalDirections.DownRight) > 0.906f)
                    return GameConsts.SwipeDirection.DownRight;
                if (Vector2.Dot(currSwipe, GetCardinalDirections.DownLeft) > 0.906f)
                    return GameConsts.SwipeDirection.DownLeft;
            }

            return swipeDir;
        }

        /// <summary>
        /// Calculates Swipe Speed 
        /// </summary>
        /// <returns></returns>
        public float GetSwipeSpeedFactor()
        {

            float speedFactor = GetResolutionIndependentVal(_currentSwipe.magnitude) / _swipeTime;
            //Tested values on editor
            float minVal = 0.5f;
            float maxVal = 5.0f;

            if (float.IsNaN(speedFactor) || speedFactor.Equals(0))
            {
                speedFactor = minVal;
            }
            else if (float.IsInfinity(speedFactor))
            {
                speedFactor = maxVal;
            }
            else
            {
                speedFactor = Mathf.Clamp(speedFactor, minVal, maxVal);
            }

            //normalizing the val
            return (speedFactor /= maxVal);

        }

        /// <summary>
        /// Converts screen dependent position to percentile unit
        /// </summary>
        /// <param name="val">Range from 0 to 1</param>
        /// <returns></returns>
        float GetResolutionIndependentVal(float val)
        {
            float updatedVal = val / (float)Screen.width;
            return (updatedVal > 1 ? 1.0f : updatedVal);
        }
    }
}