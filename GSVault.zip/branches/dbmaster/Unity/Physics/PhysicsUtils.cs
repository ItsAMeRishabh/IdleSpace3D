﻿using UnityEngine;

namespace GS
{
    /// <summary>
    /// Define your Physics Calculation helper functions here
    /// </summary>
    public static class PhysicsUtils
    {
        /// <summary>
        /// Nearest Point on finite line
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="pnt"></param>
        /// <returns></returns>
        public static Vector3 NearestPointOnFiniteLine(Vector3 start, Vector3 end, Vector3 pnt)
        {
            var line = (end - start);
            var len = line.magnitude;
            line.Normalize();

            var v = pnt - start;
            var d = Vector3.Dot(v, line);
            d = Mathf.Clamp(d, 0f, len);
            return start + line * d;
        }

        /// <summary>
        /// Finds nearest point in infinite line
        /// </summary>
        /// <param name="linePnt">point the line passes through</param>
        /// <param name="lineDir">unit vector in direction of line, either direction works</param>
        /// <param name="pnt">the point to find nearest on line for </param>
        /// <returns></returns>
        public static Vector3 NearestPointOnLine(Vector3 linePnt, Vector3 lineDir, Vector3 pnt)
        {
            lineDir.Normalize();//this needs to be a unit vector
            var v = pnt - linePnt;
            var d = Vector3.Dot(v, lineDir);
            return linePnt + lineDir * d;
        }

        /// <summary>
        /// Get nearest Distance from point to infinite line 
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="direction"></param>
        /// <param name="point"></param>
        /// <returns></returns>
        public static float GetDistPointToLine(Vector3 origin, Vector3 direction, Vector3 point)
        {
            Vector3 point2origin = origin - point;
            Vector3 point2closestPointOnLine = point2origin - Vector3.Dot(point2origin, direction) * direction;
            return point2closestPointOnLine.magnitude;
        }


        /// <summary>
        /// Calculates distance between a and b vectors in xz Plane (ignores Y Values)
        /// Vector distance equation square of( x2-x1 ) + square of ( y2 - y1)
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        public static float SquareDistanceInXZPlane(Vector3 a, Vector3 b)
        {
            return (b.x - a.x) * (b.x - a.x) + (b.z - a.z) * (b.z - a.z);
        }

        // Given three colinear points p, q, r, the function checks if
        // point q lies on line segment 'pr'
        public static bool OnSegment(Vector3 p, Vector3 q, Vector3 r)
        {
            if (q.x <= Mathf.Max(p.x, r.x) && q.x >= Mathf.Max(p.x, r.x) &&
                q.z <= Mathf.Max(p.z, r.z) && q.z >= Mathf.Max(p.z, r.z))
                return true;

            return false;
        }

        // To find orientation of ordered triplet (p, q, r).
        // The function returns following values
        // 0 --> p, q and r are colinear
        // 1 --> Clockwise
        // 2 --> Counterclockwise
        static int Orientation(Vector3 p, Vector3 q, Vector3 r)
        {
            float val = (q.z - p.z) * (r.x - q.x) - (q.x - p.x) * (r.z - q.z);

            if ((int)val == 0) return 0;  // colinear

            return (val > 0) ? 1 : 2; // clock or counterclock wise
        }

        // Returns true if line segment 'p1q1' and 'p2q2' intersect.
        //Lines are considered to be in XZ Plane
        public static bool DoIntersect(Vector3 p1, Vector3 q1, Vector3 p2, Vector3 q2)
        {
            // Find the four orientations needed for general and
            // special cases
            int o1 = Orientation(p1, q1, p2);
            int o2 = Orientation(p1, q1, q2);
            int o3 = Orientation(p2, q2, p1);
            int o4 = Orientation(p2, q2, q1);

            // General case
            if (o1 != o2 && o3 != o4)
                return true;

            // Special Cases
            // p1, q1 and p2 are colinear and p2 lies on segment p1q1
            if (o1 == 0 && OnSegment(p1, p2, q1)) return true;

            // p1, q1 and q2 are colinear and q2 lies on segment p1q1
            if (o2 == 0 && OnSegment(p1, q2, q1)) return true;

            // p2, q2 and p1 are colinear and p1 lies on segment p2q2
            if (o3 == 0 && OnSegment(p2, p1, q2)) return true;

            // p2, q2 and q1 are colinear and q1 lies on segment p2q2
            if (o4 == 0 && OnSegment(p2, q1, q2)) return true;

            return false; // Doesn't fall in any of the above cases
        }
    }
}
    