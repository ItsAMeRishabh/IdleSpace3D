﻿using System;
using UnityEngine;

namespace GS.UI
{
    public class UnitySprite : ISprite
    {
        private Sprite sprite;

        public UnitySprite(Sprite sprite)
        {
            this.sprite = sprite;
        }

        public Sprite GetSprite()
        {
            return sprite;
        }
    }
}
