﻿using GS.SimpleJSON;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Unity.UI
{
  // TODO: Polish this script
  /// <summary>
  /// Creates and fills records
  /// </summary>
  public class JsonUIRecordsUpdater
  {

    #region Listers/Callbacks



    #endregion Listers/Callbacks


    public void PrepareRecords(JsonUIDataPair jsonDataPair, string jsonDataNodeName, JsonUIDataType jsonDataType, JsonUIRecordTemplate template, ref List<JsonUIRecordTemplate> objectsPool)
    {
      if (template == null || objectsPool == null)
      {
        Log.Error("DisplayRecordsHandler - Either recordTemplate or objectsPool is null !! Cant Fill records  for given jsonDataNode: " + jsonDataNodeName);
        return;
      }


      if (jsonDataPair == null)
      {
        Log.Error("DisplayRecordsHandler - JsonDataPair is null !! Cant Fill records for given jsonDataNode: " + jsonDataNodeName);
        return;
      }

      JSONNode jsonData = jsonDataPair.jsonDataNode;



      // ----------------- Fill records -----------------
      FillRecords(jsonData, jsonDataType, template, ref objectsPool);
    }

    void FillRecords(JSONNode jsonData, JsonUIDataType jsonDataType, JsonUIRecordTemplate template, ref List<JsonUIRecordTemplate> objectsPool)
    {
      if (jsonData == null)
      {
        Log.Error("DisplayRecordsHandler - Display Data List is null !! Cant Fill records !!");
        return;
      }


      JSONArray jArray = jsonData.AsArray;
      //JSONClass jClass = null;
      List<JSONNode> dataList = new List<JSONNode>();

      //if (jsonDataType == JsonDataType.Array)
      //if(jsonDataType.GetType() == typeof(JSONArray))
      if (jArray != null)
      {
        //JSONArray jArray = jsonData.AsArray;
        //if (jArray == null)
        //{
        //    Log.Error("DisplayRecordsHandler - Excpected JSONArray but data is in other formatt for given jsonDataNodeName: " + jsonDataNodeName);
        //    return;
        //}

        for (int i = 0; i < jArray.Count; i++)
        {
          dataList.Add(jArray[i]);
        }
      }
      else //if (jsonDataType == JsonDataType.Class)
      {
        // TODO: Check this adding element
        #region OldCode
        //JSONClass jClass = (JSONClass)jsonData;
        //for (int i = 0; i < jClass.Count; i++)
        //{
        //  dataList.Add(jClass[i]);
        //}
        #endregion
        JSONClass jClass = (JSONClass)jsonData;
        dataList.Add(jClass);

      }

      // Looping all data records
      for (int i = 0; i < dataList.Count; i++)
      {
        if (dataList[i] == null)
          continue;


        GameObject record = null;

        if (i < objectsPool.Count)
        {
          // Getting object from objectPool
          if (objectsPool[i] != null)
            record = objectsPool[i].gameObject;
        }

        if (record == null)
        {
          // As we dont have object in objectPool, creating new one.
          record = GameObject.Instantiate(template.gameObject, template.transform.parent);

          record.transform.SetParent(template.transform.parent);

          if (i < objectsPool.Count)
            // As we have empty slot in objectsPool, adding current record in it.
            objectsPool[i] = record.GetComponentInChildren<JsonUIRecordTemplate>();
          else
            // As all slots are occupied, adding this at end
            objectsPool.Add(record.GetComponentInChildren<JsonUIRecordTemplate>());
        }

        JsonUIRecordTemplate scriptComp = record.GetComponentInChildren<JsonUIRecordTemplate>();
        if (scriptComp == null)
          continue;

        // Making sure record is active
        record.SetActive(true);

        // Looping all Keys
        //for (int j = 0; j < dataList[i].Count; j++)
        foreach (string key in dataList[i].Keys)
        {

          bool isJSONNode_Complex = (dataList[i][key].GetType() == typeof(JSONClass)) || (dataList[i][key].GetType() == typeof(JSONArray));

          if (isJSONNode_Complex)
          {
            for (int k = 0; k < scriptComp.displaySubPrefabs.Length; k++)
            {
              if (scriptComp.displaySubPrefabs[k].displayRecordTemplate != null && scriptComp.displaySubPrefabs[k].displayRecordTemplate.jsonTagName == key)
              {
                FillRecords(dataList[i][key], JsonUIDataType.Array, scriptComp.displaySubPrefabs[k].displayRecordTemplate, ref scriptComp.displaySubPrefabs[k].objectsPool);
              }
            }
          }
          else
          {
            //bool isTextComponentFound = false;
            for (int l = 0; l < scriptComp.textComponents.Length; l++)
            {
              if (scriptComp.textComponents[l] == null)
                continue;

              // Dont break loop here, because we may have multiple texts with same name where same data is expected.
              if (scriptComp.textComponents[l].name == key)
                scriptComp.textComponents[l].text = dataList[i][key];
            }

            //if (!isTextComponentFound)
            {
              //// As key is not found in Textcomponents, checking in image components
              for (int l = 0; l < scriptComp.imageComponentsStructs.Length; l++)
              {
                for (int m = 0; m < scriptComp.imageComponentsStructs[l].imageComponents.Length; m++)
                {
                  if (scriptComp.imageComponentsStructs[l].imageComponents[m] == null)
                    continue;

                  // Dont break loop here, because we may have multiple images with same name where same data is expected.
                  if (scriptComp.imageComponentsStructs[l].imageComponents[m].name == key)
                    scriptComp.imageComponentsStructs[l].imageComponents[m].sprite = GetSprite(scriptComp.imageComponentsStructs[l].folderPath, dataList[i][key]); // dataList[i][key];
                }
              }
            }


            if (scriptComp.recordBehaviours.behaviourConditionStruct != null)
            {
              for (int m = 0; m < scriptComp.recordBehaviours.behaviourConditionStruct.Length; m++)
              {
                scriptComp.recordBehaviours.behaviourConditionStruct[m].IsJsonKeyMatches(key, dataList[i][key]);
              }
            }

            for (int m = 0; m < scriptComp.timerTextStruct.Length; m++)
            {
              for (int l = 0; l < scriptComp.timerTextStruct[m].keyNames.Length; l++)
              {
                if (scriptComp.timerTextStruct[m].keyNames[l].Equals(key))
                {
                  scriptComp.timerTextStruct[m].keyValues[l] = dataList[i][key];
                }
              }
            }

          }

        }

        // start timer for all timer related calls
        // since by this time all the keyvalues for timertext struct will be initialised
        for (int m = 0; m < scriptComp.timerTextStruct.Length; m++)
        {
          scriptComp.timerTextStruct[m].SetTarget(onTimerCompletedCallback, record);
        }

        //if (scriptComp.recordBehaviours.behaviourConditionStruct != null)
        //{
        //    for (int m = 0; m < scriptComp.recordBehaviours.behaviourConditionStruct.Length; m++)
        //    {
        //        //if (scriptComp.recordBehaviours.behaviourConditionStruct[m].IsJsonKeyMatches(key, dataList[i][key]))
        //        {
        //            scriptComp.recordBehaviours.behaviourConditionStruct[m].SetConditionValue();
        //        }
        //    }
        //}

      }


      // Disabling remaining objects in objectsPool
      for (int i = dataList.Count; i < objectsPool.Count; i++)
      {
        if (objectsPool[i] != null)
          objectsPool[i].gameObject.SetActive(false);
      }
    }

    private void onTimerCompletedCallback(GameObject record)
    {
      JsonUIRecordTemplate scriptComp = record.GetComponentInChildren<JsonUIRecordTemplate>();
      if (scriptComp != null)
      {
        if (scriptComp.recordBehaviours.behaviourConditionStruct != null)
        {
          for (int m = 0; m < scriptComp.recordBehaviours.behaviourConditionStruct.Length; m++)
          {
            scriptComp.recordBehaviours.behaviourConditionStruct[m].IsJsonKeyMatches("startDate", TimeUtils.Instance.currentUTCTime.Date.ToString("yyyy-MM-dd"));
            scriptComp.recordBehaviours.behaviourConditionStruct[m].IsJsonKeyMatches("startTime", TimeUtils.Instance.currentUTCTime.ToString("HH:mm") + " GMT");
          }
        }
      }
    }

    Sprite GetSprite(string filePath, string fileRelativePath)
    {
      Sprite s = null;
      fileRelativePath = filePath + fileRelativePath;

      // TODO: 
      //if (!string.IsNullOrEmpty(fileRelativePath))
      //    Utils.EventAsync(new );
      //s = (Resources.Load(fileRelativePath) as Sprite);
      s = Resources.Load<Sprite>(fileRelativePath);

      if (s == null)
        s = Resources.Load<Sprite>(filePath + "default");


      return s;
    }

  }
}