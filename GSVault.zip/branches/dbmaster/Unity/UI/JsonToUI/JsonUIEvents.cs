﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Events
{
    /// <summary>
    /// Prepares(Instantiates and Fills) display records of given 'jsonDataNodeName'
    /// </summary>
    public class PrepareUIDisplayRecords : GameEvent
    {
        public string jsonDataNodeName;
        public GS.Unity.UI.JsonUIDataType jsonDataType;
        /*MenuScreenID screenID,*/
        public GS.Unity.UI.JsonUIRecordTemplate template;
        public List<GS.Unity.UI.JsonUIRecordTemplate> objectsPool;

        public PrepareUIDisplayRecords(string jsonDataNodeName, GS.Unity.UI.JsonUIDataType jsonDataType, /*MenuScreenID screenID,*/ GS.Unity.UI.JsonUIRecordTemplate template, ref List<GS.Unity.UI.JsonUIRecordTemplate> objectsPool)
        {
            this.jsonDataNodeName = jsonDataNodeName;
            this.jsonDataType = jsonDataType;
            this.template = template;
            this.objectsPool = objectsPool;
        }
    }

    /// <summary>
    /// Gets JsonData in JsonNode(JsonDataPair) of given jsonDataNodeName
    /// </summary>
    public class GetJsonDataOfPacketType : GameEvent
    {
        public string jsonDataNodeName;
        public Action<Unity.UI.JsonUIDataPair> callback;

        public GetJsonDataOfPacketType(string jsonDataNodeName, Action<Unity.UI.JsonUIDataPair> callback)
        {
            this.jsonDataNodeName = jsonDataNodeName;
            this.callback = callback;
        }
    }

    public class OnJsonDataPacketRecived : GameEvent
    {
        public string jsonDataNodeName;

        public OnJsonDataPacketRecived(string jsonDataNodeName)
        {
            this.jsonDataNodeName = jsonDataNodeName;
        }
    }
}