﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace GS.Unity.UI
{
    public enum JsonUIDataType
    {
        Class,
        Array
    }

    /// <summary>
    /// Item Record template class holds all updatable UI components (Text and Image)
    /// </summary>
    public class JsonUIRecordTemplate : MonoBehaviour
    {
        public string jsonTagName;

        public Text[] textComponents;

        public TimerTextStruct[] timerTextStruct;

        public ImageComponentsStruct[] imageComponentsStructs;

        public DisplaySubRecord[] displaySubPrefabs;

        public UIRecordBehaviour recordBehaviours;
    }

    /// <summary>
    /// Struct that holds sub record templates
    /// </summary>
    [System.Serializable]
    public struct DisplaySubRecord
    {
        public JsonUIRecordTemplate displayRecordTemplate;

        // TODO: place 'ReadOnly' header here
        public List<JsonUIRecordTemplate> objectsPool;
    }

    /// <summary>
    /// Struct that holds UI Image components
    /// </summary>
    [System.Serializable]
    public struct ImageComponentsStruct
    {
        public string folderPath;
        public Image[] imageComponents;
    }

    [System.Serializable]
    public class TimerTextStruct
    {

        //// reference to the text component which displays time
        //public Text textComp;

        //// reference to the slider component which displays time
        //public Slider sliderComp;
        //public float fromValue;
        //public float toValue;
        //// display options for remaing time
        //public string rtDisplayPattern, ttDisplayPattern;
        public TimerComponent timerComponent;

        public TimerComponentEvent timerComponentEvent;

        // since we get time in two different keys start Date and start Time
        public string[] keyNames;
        // note key values and names should be in [0] = date and [1] = time ; order
        // these values need to be set via inspector in the prefab
        public string[] keyValues; 

        public string[] dateTimePatterns; // note [0] = date pattern and [1] = time pattern;

        private Action<GameObject> onTimerCompletedCallback;
        private GameObject callbackGameobject;

        DateTime timeTarget;
        //public Action callback;

        public void SetTarget(Action<GameObject> completionCallback, GameObject callbackGameobject)
        {
            onTimerCompletedCallback = completionCallback;
            this.callbackGameobject = callbackGameobject;
            Utils.EventAsync(new GetCurrentTimeEvent(OnReceivedCurretTime));
        }

        private void OnReceivedCurretTime(DateTime currentTime)
        {
            timeTarget = GS.Utils.ParseDateTime(keyValues[0], keyValues[1], dateTimePatterns[0],dateTimePatterns[1]);

 //= new TimerComponent();

            // if the target time has already passed
            if ( DateTime.Compare(timeTarget, currentTime) <= 0)
            {
                timerComponent.timerType = TimerType.remainingTime;
                timerComponent.RemainingTime = 0;
            }
            else
            {
                //// if the date is same as current date
                //// then only we are interested in showing the remaing time
                //if(currentTime.Date.CompareTo(timeTarget.Date) == 0)
                //{
                //    timerComponent.timerType = TimerType.remainingTime;
                //    timerComponent.RemainingTime = (timeTarget - currentTime).TotalSeconds;
                //}
                //Now as we are checking the time Range, Comparing TotalMinutes instead Date.
                TimeSpan span = timeTarget - currentTime;
                if (span.TotalMinutes > 0 && span.TotalMinutes < 1440)
                {
                    timerComponent.timerType = TimerType.remainingTime;
                    timerComponent.RemainingTime = (timeTarget - currentTime).TotalSeconds;
                }
                // else we show the target time (if the event is on next date)
                else
                {
                    timerComponent.timerType = TimerType.targetTime;
                }

            }

            //timerComponent.text = textComp;
            //timerComponent.slider = sliderComp;
            //timerComponent.rtDisplayPattern = rtDisplayPattern;
            //timerComponent.ttDisplayPattern = ttDisplayPattern;

            timerComponent.TargetTime = timeTarget;
            timerComponent.RemainingTime = (timeTarget - currentTime).TotalSeconds;

            Utils.EventAsync(timerComponentEvent = new TimerComponentEvent(timerComponent, onTimerCompletedCallback,callbackGameobject));

        }

        /// <summary>
        ///  Gets called on completetion
        /// </summary>
        private void Callback()
        {

        }

     
    }

}