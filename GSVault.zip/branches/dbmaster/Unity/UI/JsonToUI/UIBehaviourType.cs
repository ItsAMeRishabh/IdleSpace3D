﻿using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{

    public enum UIBehaviourCondition
    {
        None = 0,
        Equals,
        GreaterThan,
        LessThan,

        // Date related
        Date_Equals = 10,
        Date_GreaterThan = 11,
        Date_LessThan = 12,
        Date_Equals_CurrentDate = 13,

        // Time related (in Minutes)
        TimeRemaining_Range = 20,
        TimeRemaining_Greater = 21,
        TimeRemaining_Lessthan = 22,

        // Predefined
        NoCheckRequired = 90,

        CustomLogic = 100
    }

    public enum UIBehaviourType
    {
        None,
        // ----- GameObject ------
        SetGameObjectActive = 1,
        //SetDisable,
        SetGameObjectName = 2,


        // ----- Images ------
        SetImageColor = 20,


        // ----- Tet ------
        SetText = 40,


        // ----- Common ------
        SetInteractbility = 60
    }

    [System.Serializable]
    public struct UIRecordBehaviour
    {
        //public IBehaviour[] behaviours;
        public UIBehaviourConditionStruct[] behaviourConditionStruct;
    }

    [System.Serializable]
    public struct UIBehaviourConditionStruct
    {
        public string jsonKey;
        private string[] jsonKeys;
        private string[] jsonVals;
        public UIBehaviourCondition condition;
        public string inspectorVal;
        //public short valInt;

        //[System.Serializable]
        //public delegate bool CustomLogicDel();
        ////[SerializeField]
        //public CustomLogicDel customLogic;
        //public UnityEvent unityEvent;


        public UIRecordBehaviourObjects[] recordBehaviourObjects;

        private int valuesRequired;
        public void IsJsonKeyMatches(string key, string val)
        {
            if (jsonKeys == null)
            {
                if (!string.IsNullOrEmpty(jsonKey))
                    jsonKeys = jsonKey.Split(',');

                if (jsonKeys == null)
                    jsonKeys = new string[0];

                jsonVals = new string[jsonKeys.Length];

                valuesRequired = jsonKeys.Length;
            }

            for (int i = 0; i < jsonKeys.Length; i++)
            {
                if (jsonKeys[i].Equals(key))
                {
                    jsonVals[i] = val;
                    valuesRequired--;
                    break;
                }
            }

            if(valuesRequired <= 0)
            {
                SetConditionValue();
                valuesRequired = jsonKeys.Length;
            }

        }

        public void SetConditionValue() //(string jsonVal)
        {
            // If condition is None, then return from this block
            if (condition == UIBehaviourCondition.None)
                return;

            // As customLogic is not defined for 'BehaviourCondition.CustomLogic', returnin from here
            //if (condition == BehaviourCondition.CustomLogic && customLogic == null)
            //    return;

            bool isConditionPassed = false;
            bool isErrorOccured = false;

            short jsonValNumber = 0;

            string jsonVal = string.Empty;

            // since we have multiple values only for time in current scenario
            if(jsonVals.Length == 1)
            {
                jsonVal = jsonVals[0];
            }

            bool isNumberData = short.TryParse(jsonVal, out jsonValNumber);


            switch (condition)
            {
                case UIBehaviourCondition.None:

                    break;
                case UIBehaviourCondition.NoCheckRequired:
                    isConditionPassed = true;
                    break;
                case UIBehaviourCondition.Equals:
                    //if(isNumberData)
                    //    isConditionPassed = (jsonValNumber == valInt);
                    //else
                    //{
                    //    GS.Log.Warning(this + " - can't parse to number, of given JsonKey: " + jsonKey + ", JsonValue: " + jsonVal);
                    isConditionPassed = (inspectorVal.Equals(jsonVal));
                    //}
                    break;
                case UIBehaviourCondition.GreaterThan:
                    if (isNumberData)
                        isConditionPassed = (jsonValNumber > int.Parse(inspectorVal));
                    break;
                case UIBehaviourCondition.LessThan:
                    if (isNumberData)
                        isConditionPassed = (jsonValNumber < int.Parse(inspectorVal));
                    break;

                // ---------- Date ----------
                // For All date based comparisons we have multiple values
                case UIBehaviourCondition.Date_Equals:
                case UIBehaviourCondition.Date_GreaterThan:
                case UIBehaviourCondition.Date_LessThan:
                case UIBehaviourCondition.Date_Equals_CurrentDate:
                    // Covert inspecter data to DateTime
                    DateTime valStrDateTime;
                    if (inspectorVal.ToLower().Equals("currentdate"))
                    {
                        valStrDateTime = TimeUtils.Instance.currentUTCTime;
                    }
                    else
                    {
                        if (!DateTime.TryParse(inspectorVal, out valStrDateTime))
                            Log.Error(this + " - Error in DateTime parse of string: " + inspectorVal);
                    }

                    // Convert JsonValue to DateTime
                    DateTime jsonValDateTime;
                    if (jsonVals.Length > 1)
                    {
                        jsonValDateTime = Utils.ParseDateTime(jsonVals[0], jsonVals[1], "yyyy-MM-dd", "HH:mm GMT");
                    }
                    else
                    {
                        if (!DateTime.TryParse(jsonVals[0], out jsonValDateTime))
                            Log.Error(this + " - Error in DateTime parse of string: " + jsonVal);
                    }

                    int dateTimeCompare = DateTime.Compare(jsonValDateTime, valStrDateTime);
                    if (condition == UIBehaviourCondition.Date_Equals)
                        isConditionPassed = (dateTimeCompare == 0);
                    else if (condition == UIBehaviourCondition.Date_GreaterThan)
                        isConditionPassed = (dateTimeCompare > 0);
                    else if (condition == UIBehaviourCondition.Date_LessThan)
                        isConditionPassed = (dateTimeCompare < 0);
                    else if (condition == UIBehaviourCondition.Date_Equals_CurrentDate)
                    {
                        int dateCompare = DateTime.Compare(jsonValDateTime.Date, valStrDateTime.Date);
                        isConditionPassed = (dateCompare == 0);
                    }
                    break;

                // All Time based comparisons
                case UIBehaviourCondition.TimeRemaining_Greater:
                case UIBehaviourCondition.TimeRemaining_Lessthan:
                case UIBehaviourCondition.TimeRemaining_Range:

                    // As inspecter data is Time in Minutes we are assuming to validate according to Current Time.
                    DateTime valStrDateTime2;
                    valStrDateTime2 = TimeUtils.Instance.currentUTCTime;

                    // Convert JsonValue to DateTime
                    DateTime jsonValDateTime2;
                    if (jsonVals.Length > 1)
                    {
                        jsonValDateTime2 = Utils.ParseDateTime(jsonVals[0], jsonVals[1], "yyyy-MM-dd", "HH:mm GMT");
                    }
                    else
                    {
                        if (!DateTime.TryParse(jsonVals[0], out jsonValDateTime2))
                            Log.Error(this + " - Error in DateTime parse of string: " + jsonVal);
                    }

                    TimeSpan timeRemaining = jsonValDateTime2 - valStrDateTime2;
                    string[] _inspectorValue = inspectorVal.Split(',');
                    if (condition == UIBehaviourCondition.TimeRemaining_Greater)
                        isConditionPassed = timeRemaining.TotalMinutes > int.Parse(_inspectorValue[0]);
                    else if(condition == UIBehaviourCondition.TimeRemaining_Lessthan)
                        isConditionPassed = timeRemaining.TotalMinutes <= int.Parse(_inspectorValue[0]);
                    else if(condition == UIBehaviourCondition.TimeRemaining_Range)
                        isConditionPassed = timeRemaining.TotalMinutes > int.Parse(_inspectorValue[0]) && timeRemaining.TotalMinutes < int.Parse(_inspectorValue[1]);

                    break;

                case UIBehaviourCondition.CustomLogic:
                    string[] splits = inspectorVal.Split('.');
                    isConditionPassed = CustomLogic(splits[0], splits[1], new object[] { jsonVal }, out isErrorOccured);
                    break;
            }

            if (!isErrorOccured)
            {
                for (int i = 0; i < recordBehaviourObjects.Length; i++)
                {
                    recordBehaviourObjects[i].ValidateBehaviour(isConditionPassed, jsonVal);
                }
            }
        }


        bool CustomLogic(string typeName, string methodName, object[] args, out bool errorOccured)
        {
            bool isConditionPassed = false;
            errorOccured = false;

            Type type = Type.GetType(typeName);

            if (type == null)
            {
                isConditionPassed = false;
                Log.Error(this + " - Given type: " + typeName + ", not found !!");
            }
            else
            {
                object returnValue = type.InvokeMember(
                    methodName,
                    BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static,
                    null,
                    null,
                    args //new object[] { p1 }
                    );

                if (returnValue is bool)
                {
                    isConditionPassed = (bool)returnValue;
                    errorOccured = true;
                }
                else
                {
                    Log.Error(this + " - Return type is not in 'bool' for given type: " + typeName);
                }
            }

            //Debug.LogError(isConditionPassed);

            return isConditionPassed;
        }

    }


    [System.Serializable]
    public struct UIRecordBehaviourObjects
    {
        public UIBehaviourType behaviourType;

        [Space(10)]
        public Behaviour_GameObject[] behaviour_GameObjects;

        [Space(10)]
        public Behaviour_GameObject_Name[] behaviour_GameObjects_Names;

        [Space(10)]
        // ----- Image Componet -----
        public Behaviour_Image[] behaviour_Images;

        [Space(10)]
        // ----- Text Componet -----
        public Behaviour_Text[] behaviour_Texts;

        [Space(10)]
        public Behaviour_Interactable[] behaviour_Interactables;


        public void ValidateBehaviour(bool isConditionPassed, string jsonVal)
        {
            if (behaviourType == UIBehaviourType.None)
                return;

            switch (behaviourType)
            {
                case UIBehaviourType.SetGameObjectActive:
                    for (int i = 0; i < behaviour_GameObjects.Length; i++)
                    {
                        if (behaviour_GameObjects[i].gameObject != null)
                            behaviour_GameObjects[i].gameObject.SetActive((isConditionPassed) ? behaviour_GameObjects[i].isActive : !behaviour_GameObjects[i].isActive);
                    }
                    break;
                case UIBehaviourType.SetGameObjectName:
                    for (int i = 0; i < behaviour_GameObjects_Names.Length; i++)
                    {
                        if (behaviour_GameObjects_Names[i].gameObject != null)
                        {
                            if (behaviour_GameObjects_Names[i].nameType == Behaviour_GameObject_Name.NameType.SuccessFailedString)
                                behaviour_GameObjects_Names[i].gameObject.name = ((isConditionPassed) ? behaviour_GameObjects_Names[i].success_Name : behaviour_GameObjects_Names[i].failed_Name);
                            else if (behaviour_GameObjects_Names[i].nameType == Behaviour_GameObject_Name.NameType.JsonNodeData)
                                // TODO: Check failed reason
                                behaviour_GameObjects_Names[i].gameObject.name = ((isConditionPassed) ? jsonVal : "");
                        }
                    }
                    break;
                case UIBehaviourType.SetImageColor:
                    for (int i = 0; i < behaviour_Images.Length; i++)
                    {
                        if (behaviour_Images[i].image != null)
                            behaviour_Images[i].image.color = (isConditionPassed) ? behaviour_Images[i].success_Color : behaviour_Images[i].failed_Color;
                    }
                    break;
                case UIBehaviourType.SetText:
                    for (int i = 0; i < behaviour_Images.Length; i++)
                    {
                        if (behaviour_Texts[i].text != null)
                            behaviour_Texts[i].text.text = (isConditionPassed) ? behaviour_Texts[i].success_Text : behaviour_Texts[i].failed_Text;
                    }
                    break;
                case UIBehaviourType.SetInteractbility:
                    for (int i = 0; i < behaviour_Interactables.Length; i++)
                    {
                        if (behaviour_Interactables[i].selectable != null)
                            behaviour_Interactables[i].selectable.interactable = (isConditionPassed) ? behaviour_Interactables[i].isInteractable : !behaviour_Interactables[i].isInteractable;
                    }
                    break;
            }
        }
    }

    [System.Serializable]
    public struct Behaviour_GameObject
    {
        public GameObject gameObject;
        public bool isActive;
    }

    [System.Serializable]
    public struct Behaviour_GameObject_Name
    {
        public enum NameType
        {
            JsonNodeData,
            SuccessFailedString
        }

        public GameObject gameObject;
        public NameType nameType;

        public string success_Name;
        public string failed_Name;
    }

    [System.Serializable]
    public struct Behaviour_Image
    {
        public Image image;
        public Color success_Color;
        public Color failed_Color;
    }

    [System.Serializable]
    public struct Behaviour_Text
    {
        public Text text;
        public string success_Text;
        public string failed_Text;
    }

    [System.Serializable]
    public struct Behaviour_Interactable
    {
        public Selectable selectable;
        public bool isInteractable;
    }

    //public interface IBehaviour
    //{

    //}

    //public struct SetActiveBehaviour : IBehaviour
    //{
    //    public string jsonKey;
    //    public BehaviourConditionStruct behaviourConditionStruct;
    //}

}