﻿using GS.SimpleJSON;
using System.Collections;
using System.Collections.Generic;

namespace GS.Unity.UI
{
    public class JsonUIDataPair
    {
        public string jsonDataNodeName;
        public JSONNode jsonDataNode;
    }

    /// <summary>
    /// Holds all multiple UI(display) related Json data.
    /// </summary>
    public class JsonUIDataContainer
    {
        #region Variables

        const string JsonDataNodePrefix = "JsonDataType_";
        public const string RecordPrefix = "Record_";

        List<JsonUIDataPair> jsonDataPairs;

        JsonUIRecordsUpdater displayRecordsUpdater;

        #endregion Variables


        internal JsonUIDataContainer()
        {
            jsonDataPairs = new List<JsonUIDataPair>();
            displayRecordsUpdater = new JsonUIRecordsUpdater();

            // --------------------- Register Events ---------------------
            Utils.EM.AddListener<GS.Events.GetJsonDataOfPacketType>(OnGetJsonDataOfPacketType);
            Utils.EM.AddListener<GS.Events.PrepareUIDisplayRecords>(OnPrepareUIDisplayRecords);
        }


        /// <summary>
        /// Adds JsonData to container list
        /// </summary>
        /// <param name="jsonStr"></param>
        public void AddJsonData(string jsonStr)
        {
            string jsonDataNodeName = "";
            JSONNode jsonNode = JSON.Parse(jsonStr);

            foreach (var k in jsonNode.Keys)
            {
                //if (k.Contains(JsonDataNodePrefix))
                {
                    // Means this is kind of display data

                    jsonDataNodeName = k.Replace(JsonDataNodePrefix, "");

                    bool isDataNodeExists = false;

                    // --------- Add this node to 'jsonDataPairs' ---------
                    // Check if same dataNode exists in list, if so replace new data.
                    for (int i = 0; i < jsonDataPairs.Count; i++)
                    {
                        if (jsonDataPairs[i].jsonDataNodeName.Equals(k))
                        {
                            isDataNodeExists = true;
                            jsonDataPairs[i].jsonDataNode = jsonNode[k];
                            break;
                        }
                    }

                    // Add jsonData to list if same data type is not added yet.
                    if (!isDataNodeExists)
                        jsonDataPairs.Add(new JsonUIDataPair() { jsonDataNodeName = k, jsonDataNode = jsonNode[k] });

                }
            }

            // Notify that data is updated
            Utils.EventAsync(new GS.Events.OnJsonDataPacketRecived(jsonDataNodeName));
        }

        /// <summary>
        /// Gets JsonData of given 'jsonDataNode' from container list
        /// </summary>
        /// <param name="jsonDataNode"></param>
        /// <returns></returns>
        public JsonUIDataPair GetJsonData(string jsonDataNode)
        {
            for (int i = 0; i < jsonDataPairs.Count; i++)
            {
                if (jsonDataPairs[i].jsonDataNodeName.Equals(/*JsonDataNodePrefix + */jsonDataNode))
                    return jsonDataPairs[i];
            }

            Log.Error("JsonDataPairsManager - GetJsonData, no data exists for given jsonDataType: " + jsonDataNode);
            return null;
        }


        #region Listers/Callbacks

        void OnGetJsonDataOfPacketType(GS.Events.GetJsonDataOfPacketType e)
        {
            if (e == null)
                return;

            if (e.callback == null)
                return;

            e.callback(GetJsonData(e.jsonDataNodeName));
        }

        public void OnPrepareUIDisplayRecords(GS.Events.PrepareUIDisplayRecords e)
        {
            if (e == null)
                return;

            displayRecordsUpdater.PrepareRecords(GetJsonData(e.jsonDataNodeName), e.jsonDataNodeName, e.jsonDataType, e.template, ref e.objectsPool);
        }

        #endregion Listers/Callbacks

    }

}