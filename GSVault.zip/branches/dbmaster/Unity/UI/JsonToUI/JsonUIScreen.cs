﻿using System.Collections.Generic;
using UnityEngine;

namespace GS.Unity.UI
{
  public class JsonUIScreen : MonoBehaviour
  {
    public string jsonDataNodeName;
    public JsonUIRecordTemplate displayRecordTemplate;
    public List<JsonUIRecordTemplate> objectsPool;

    void Awake()
    {
      objectsPool = new List<JsonUIRecordTemplate>();
    }

    void OnEnable()
    {
      Utils.EM.AddListener<GS.Events.OnJsonDataPacketRecived>((e) => { if (e.jsonDataNodeName.Equals(jsonDataNodeName)) FillRecords(); Log.Print(e.jsonDataNodeName + " : " + jsonDataNodeName); });

      //Invoke("FillRecords", 2.0f);
      // FillRecords();
    }

    void FillRecords()
    {
      Utils.EventAsync(new GS.Events.PrepareUIDisplayRecords(jsonDataNodeName, JsonUIDataType.Array, displayRecordTemplate, ref objectsPool));
      // Utils.EventAsync(new CricketApp.AppEvents.LoadingScreenEvent(false));//Disable Loading
    }

  }
}