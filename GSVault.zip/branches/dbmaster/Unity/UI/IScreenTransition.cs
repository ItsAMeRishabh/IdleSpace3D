using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace GS
{
    namespace UI
    {
        public interface IScreenTransition
        {
            bool IsOpen { get; set; }

            void OnInitialize(GameObject screenGo, bool isRequireAnimation);

            void Update(GameObject gameObject, CanvasGroup canvasGroup);

            bool IsOpening();

            bool IsClosing();
        }

        public class ScreenTransitionAnimationController : IScreenTransition
        {
            private Animator animator = null;
            public int IsOpen_AnimID = Animator.StringToHash("IsOpen");

            private int hkOpen;
            private int hkClose;

            public void OnInitialize(GameObject screenGo, bool isRequireAnimation)
            {
                animator = screenGo.GetComponent<Animator>();

                if (isRequireAnimation)
                {
                    if (animator == null)
                    {
                        Utils.EventSync(new Data.LoadAnimatorControllerEvent(Data.DataConsts.AssetDataBundleKeys.UIPrefabs, "UIScreen Animations/DefaultUIScreenAnimator", onDefaultUIScreenAnimatorLoaded));
                    }
                    if (animator != null)
                    {
                        animator.updateMode = AnimatorUpdateMode.Normal;
                        hkOpen = Animator.StringToHash("Open");
                        hkClose = Animator.StringToHash("Close");
                    }
                }
                else if (animator != null)
                {
                    //Remove the animator if it is not null.
                    GameObject.Destroy(animator);
                }
            }

            /// <summary>
            /// CallBack for loading 'DefaultUIScreenAnimator'
            /// </summary>
            /// <param name="controller"></param>
            void onDefaultUIScreenAnimatorLoaded(RuntimeAnimatorController controller)
            {
                if (animator != null)
                    animator.runtimeAnimatorController = controller;
            }

            public void Update(GameObject gameObject, CanvasGroup canvasGroup)
            {
                if (animator != null)
                {
                    //Allow input only when the menu is opened.
                    if (!animator.GetCurrentAnimatorStateInfo(0).IsName("Open") || IsOpen == false)
                    {
                        if (canvasGroup.blocksRaycasts == true || canvasGroup.interactable == true)
                            canvasGroup.blocksRaycasts = canvasGroup.interactable = false;
                    }
                    else if (animator.GetCurrentAnimatorStateInfo(0).normalizedTime > 0.5f && animator.GetCurrentAnimatorStateInfo(0).IsName("Open"))
                    {
                        if (canvasGroup.blocksRaycasts == false || canvasGroup.interactable == false)
                            canvasGroup.blocksRaycasts = canvasGroup.interactable = true;
                    }

                    //If the animation playing is Close and time>0.95 almost the menu is closed to disable the GameObject
                    if (IsOpen == false && animator.GetCurrentAnimatorStateInfo(0).IsName("Close"))
                    {
                        if (animator.GetCurrentAnimatorStateInfo(0).normalizedTime > 0.95f && !animator.IsInTransition(0))
                            gameObject.SetActive(false);
                    }
                }
            }

            public bool IsOpening()
            {
                if (animator == null)
                    return true;

                return animator.GetCurrentAnimatorStateInfo(0).IsName("Open");
            }

            public bool IsClosing()
            {
                if (animator == null)
                    return true;

                return animator.GetCurrentAnimatorStateInfo(0).IsName("Close");
            }

            /// <summary>
            /// To know wether the menu is open or closed. 
            /// </summary>
            public bool IsOpen
            {
                get { return animator.GetBool(IsOpen_AnimID); }
                set { animator.SetBool(IsOpen_AnimID, value); }
            }
        }
    }
}