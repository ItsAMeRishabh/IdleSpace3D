﻿using GS;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// TODO: Define a nameSpace for this class
/// <summary>
/// Tracker for Loading Scene Progress
/// </summary>
public class LoadingSceneProgress : MonoBehaviour
{

    /// <summary>
    /// Holds the SlidingBar to show the load progress 
    /// </summary>
    [SerializeField] private Slider loadingBarSlider;
    [SerializeField] private Image loadingImage;
    /// <summary>
    /// Holds a text compenent to display the precentage of loading completed
    /// </summary>
    [SerializeField] private TextMeshProUGUI loadingBarText;
    [SerializeField] float progressSpeed = 0.01f;

    /// <summary>
    /// used in update to fill the loading image.
    /// </summary>
    private float sceneCompletePercentage;

    /// <summary>
    /// Holds the current scene's sceneHandler 'Initialize()' status
    /// </summary>
    private float sceneHandlerInitPercentage;

    /// <summary>
    /// sets sceneCompletePercentage to the specified value
    /// </summary>
    /// <param name="value"></param>
    /// 
    [SerializeField] float loadingUpdateDuration= 0.25f;
    public void setSceneCompleteProgress(float value)
    {
        
        // As Scene Loding progress is from "0.0f to 1.0f", but we need "0 to 100",
        // so multiply with 100.
        sceneCompletePercentage = value * 100;

        // Unity will always return '0.9' as the finial loading value. (This might be bug from unity side)
        // So '0.9 * 100 = 90' means scene loading is completed. So set percentage loaded as '100'.
        if (sceneCompletePercentage >= 90)
            sceneCompletePercentage = 100;
        SetSliderInitial();
    }

    /// <summary>
    /// sets sceneHandlerInitPercentage to the specified value
    /// </summary>
    /// <param name="value"></param>
    public void setSceneHandlerInitProgress(float value)
    {
        sceneHandlerInitPercentage = value;
        SetSliderInitial();
    }

    /// <summary>
    /// Combined progress of 'Scene Loading %' and 'SceneHandler Init' in '0% to 100 %'
    /// </summary>
    public float totalLoadProgress
    {
        get { return (sceneCompletePercentage * 0.2f) + (sceneHandlerInitPercentage * 0.8f); }
    }

    
    float progressTimer = 0.0f;

    float loadingImageProgress = 0.0f;
    float loadingBarProgress = 0.0f;
    bool progressUpdated = true;

    void SetSliderInitial()
    {
        progressUpdated = false;
        progressTimer = 0.0f;
        if (loadingBarSlider != null)
            loadingBarProgress = loadingBarSlider.value;
        if (loadingImage != null)
            loadingImageProgress = loadingImage.fillAmount;
    }

    void UpdateLoadingProgress()
    {
        if (progressTimer < 1.0f)
            progressTimer += progressSpeed * Time.deltaTime;
        else
        {
            progressTimer = 1.0f;
        }


        if (loadingBarSlider != null)
            loadingBarSlider.value = Mathf.Lerp(loadingBarProgress, totalLoadProgress, progressTimer);
        if (loadingImage != null)
        {
            loadingImage.fillAmount = Mathf.Lerp(loadingImageProgress, totalLoadProgress / 100.0f, progressTimer);
        }

        if (loadingBarText != null)
                loadingBarText.text = totalLoadProgress.ToString("F0") + " %";


        if (progressTimer >= 1.0f)
            progressUpdated = true;
    }

    private void LateUpdate()
    {
        if(!progressUpdated)
            UpdateLoadingProgress();
    }

    private static bool isDestroyed = false;
    public void DestroyLoadingProgress()
    {
        isDestroyed = true;
        GameObject.Destroy(gameObject, 0.3f);
    }

    private void OnEnable()
    {
        isDestroyed = false;
    }

    private void OnDisable()
    {

    }


    /// <summary>
    /// Sets this UI object's 'DontDestroyOnLoad'
    /// </summary>
    public void SetDontDestroyOnLoad()
    {
        DontDestroyOnLoad(this);
    }
}
