﻿
using System;
using Game.Data;
using GS.Data;
using GS.Events;
using GS.GameEvents;
using GS.UI;
using UnityEngine;

namespace GS
{

    /// <summary>
    /// This is the Base class of all UIController and it listens all UI Events 
    /// This class exchange data between UIScreen and GameLogic
    /// </summary>
    public abstract class UIController : IController
    {
        protected UIStateMachine uiManager;
        public static UIBlocker blocker;
        protected bool isBlockedRequired = true;
        protected DynamicScreenData[] dynamicScreenData;
        protected Transform rootUIObject;
        public UIController()
        {

        }
        /// <summary>
        /// Override this method to receive UI Event
        /// </summary>
        /// <param name="uiEvent"></param>
        protected abstract void OnEvent(GameEvents.UIEvent uiEvent);

        public virtual void Update()
        {
            if (uiManager != null)
                uiManager.Update();
        }

        /// <summary>
        /// Intializes UI Controller. Base.Initalize() should be called from override function
        /// </summary>
        public virtual void Initialize()
        {
           
            //RegisterListener();
        }

        /// <summary>
        /// gets all your screens and Adds to UIStateMachine
        /// </summary>
        /// <param name="uiGameObject"></param>
        public virtual void PrepareScreens(GameObject uiGameObject)
        {
            uiManager = new UIStateMachine();
            uiManager.SetPopUp(new UIPopUp());
            IMonoState[] screens = uiGameObject.transform.GetComponentsInChildren<IMonoState>(true);
            uiManager.Initialize();

            for (int i = 0; i < screens.Length; i++)
                uiManager.AddState(screens[i]);

            var container = uiGameObject.GetComponent<DynamicScreenContainer>();
            
            if(container != null)
                dynamicScreenData = container.dynamicScreens;
             
            // Add blocker Prefab to scene
            if (blocker == null && isBlockedRequired)
            {
                if (UIBlocker.Instance == null)
                {
                    GameObject go = Resources.Load<GameObject>("UI/UIBlocker");
                    if (go != null)
                    {
                        var blockerGo = GameObject.Instantiate(go);
                        if (blockerGo != null)
                            blocker = blockerGo.GetComponent<UIBlocker>();
                    }
                }
                else
                {
                    blocker = UIBlocker.Instance;
                }
            }
        }

        /// <summary>
        /// Callback for device back button (OnEscape)
        /// </summary>
        protected virtual void OnEscapeMethod()
        {

        }

        /// <summary>
        /// DataPairs Keys can be registered in this method.
        /// This will be called after UIScreenManager Init.
        /// </summary>
        protected void RegisterDataPairsKeys()
        {

        }

        /// <summary>
        /// Releases UI Controller
        /// Base.Release() should be called from override function
        /// </summary>
        public virtual void Release()
        {
            
        }

        public virtual void RegisterListener()
        {
            // Registering UI Events here
            Utils.EM.AddListener<GameEvents.UIEvent>(OnEvent);
            Utils.EM.AddListener<GameEvents.UIGameObjectLoaded>(OnUIObjectLoadedListener);
            Utils.EM.AddListener<UIScreenEvent>(OnScreenEvent);
            Utils.EM.AddListener<UIPrefabLoadedEvent>(OnUIObjctLoadedListener);
            Utils.EM.AddListener<UIPopUPEvent>(OnPopUpListener);
        }

   

    public virtual void UnRegisterListener()
        {
            // UnRegistering UI Events here
            Utils.EM.RemoveListener<GameEvents.UIEvent>(OnEvent);
            Utils.EM.RemoveListener<GameEvents.UIGameObjectLoaded>(OnUIObjectLoadedListener);
            Utils.EM.RemoveListener<UIScreenEvent>(OnScreenEvent);
            Utils.EM.RemoveListener<UIPrefabLoadedEvent>(OnUIObjctLoadedListener);
            Utils.EM.RemoveListener<UIPopUPEvent>(OnPopUpListener);

    }

    private void OnPopUpListener(UIPopUPEvent popUpEvent)
        {
            if (popUpEvent == null || uiManager == null)
                return;

            //uiManager.popUp.ShowPopUp(popUpEvent.title, popUpEvent.message, popUpEvent.icon, popUpEvent.type, popUpEvent.yesEvent, 
            //popUpEvent.noEvent, popUpEvent.cancelEvent, popUpEvent.timeToClose, popUpEvent.uIPopUpPrefabType);
            uiManager.popUp.ShowPopUp(popUpEvent);
        }

        private void OnUIObjctLoadedListener(UIPrefabLoadedEvent uiObjectLoadedEvent)
        {
            if (uiObjectLoadedEvent == null || uiObjectLoadedEvent.uiGameObject == null)
                return;

            rootUIObject = uiObjectLoadedEvent.uiGameObject.transform;
            PrepareScreens(uiObjectLoadedEvent.uiGameObject);
            GoToScreen(uiObjectLoadedEvent.intialScreenID);
        }

        protected virtual void OnScreenEvent(UIScreenEvent e)
        {
            switch (e.operationType)
            {
                case GameConsts.UIScreenEventType.Switch:
                    GoToScreen(e.screenID);
                    break;
                default:
                    Log.Error(e.operationType + " : not handled");
                    break;
            }

        }


        

        /// <summary>
        /// Callback when ui Object loaded 
        /// </summary>
        /// <param name="uiObjLoaded"></param>
        protected virtual void OnUIObjectLoadedListener(UIGameObjectLoaded uiObjLoaded)
        {
            if (uiObjLoaded == null || uiObjLoaded.uiGameObject == null)
                return;
        }

        public void GoToScreen(int screenID)
        {
            if (uiManager != null)
            {
                if(dynamicScreenData != null)
                {
                    var screen = uiManager.GetState(screenID);
                    if(screen == null)
                    {
                        for(int i=0;i<dynamicScreenData.Length;i++)
                        {
                            var screenData = dynamicScreenData[i];
                            if (screenData.screenId == screenID)
                            {
                                GameObject screenGo = GameObject.Instantiate(screenData.template, rootUIObject);
                                if(screenGo != null)
                                {
                                    var monoScreen = screenGo.GetComponent<IMonoState>();
                                    uiManager.AddState(monoScreen);
                                }
                                break;
                            }
                        }
                    }
                }
                uiManager.ChangeState(screenID);
            }
        }

        protected virtual void EnableBlocker(float duration)
        {
            if(duration > 0)
                blocker?.TurnOn(duration);
        }
    }
}
