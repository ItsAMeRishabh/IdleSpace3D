﻿using System.Collections;
using System.Collections.Generic;
using GS.Unity;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    public class UIBlocker : SingleTon<UIBlocker>
    {
        public Image blocker;

        private void Awake()
        {
            blocker?.gameObject.SetActive(false);
            DoNotDestroyOnLoad = true;
        }

       private IEnumerator EnableBlocker(float duration)
        {
            if (blocker != null)
            {
                blocker.gameObject.SetActive(true);
                blocker.raycastTarget = true;
            }
            yield return new WaitForSecondsRealtime(duration);

            if (blocker != null)
            {
                blocker.raycastTarget = false;
                blocker.gameObject.SetActive(false);
            }
        }

        public void TurnOn(float duration)
        {
            StartCoroutine(EnableBlocker(duration));
        }

    }
}