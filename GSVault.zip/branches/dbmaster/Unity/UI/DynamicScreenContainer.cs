﻿using System;
using UnityEngine;

namespace GS
{
    namespace UI
    {
        [System.Serializable]
        public class DynamicScreenData
        {
            public int screenId;
            public GameObject template;
            public bool destroyOnDisable;
        }

        public class DynamicScreenContainer : MonoBehaviour
        {
            public DynamicScreenData[] dynamicScreens;
        }
    }
}