﻿
using UnityEngine;

namespace GS
{

    public enum UIEventType
    {
        SwitchScreen
    }

    [System.Serializable]
    public class UIPair
    {
        public string buttonName;
        public UIEventType eventType;
        public int screenID;
    }

    namespace Events
    {





        /// <summary>
        /// This event will be raised Scene handler after the UI gameobject is instantiated
        /// </summary>
        public class UIPrefabLoadedEvent : GameEvent
        {
            public GameObject uiGameObject;
            public int intialScreenID;

            public UIPrefabLoadedEvent(GameObject guiObject, int startScreen)
            {
                uiGameObject = guiObject;
                intialScreenID = startScreen;
            }
        }
    }
}
