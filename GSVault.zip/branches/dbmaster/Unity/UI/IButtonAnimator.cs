﻿
using System;
using UnityEngine;
using UnityEngine.UI;

namespace GS
{
    namespace UI
    {
        /// <summary>
        /// This interface let the user implement thier own button animations on pressing/release button
        /// </summary>
        public interface IButtonAnimator
        {
            /// <summary>
            /// Implement on button leave animation here. This will be called when pointer leaves the button touch area
            /// </summary>
            /// <param name="button"></param>
            /// <param name="intialScale"></param>
            void OnPointerExit(Button button, Vector3 intialScale);

            /// <summary>
            /// Implement your button press animation logic here. This will be called when pointer pressed the button
            /// </summary>
            /// <param name="button"></param>
            void OnButtonPressed(Button button);

            /// <summary>
            /// Implement on click animation here. 
            /// </summary>
            /// <param name="button"></param>
            /// <param name="intialScale"></param>
            /// <param name="callback"></param>
            void OnButtonRelease(Button button, Vector3 intialScale, Action<Button> callback);
        }
    }
}