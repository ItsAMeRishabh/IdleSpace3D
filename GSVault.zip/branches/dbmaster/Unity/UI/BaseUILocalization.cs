using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BaseUILocalization : MonoBehaviour
{
    public string KeyWord;
    protected string languagetype = null;
    public static bool checkLocalizeDataLoaded = false;
    public abstract void OnEnable();
    public abstract void SetText();
    public abstract void UpdateKeyword(string keyword,bool localize=true);
    public abstract void UpdateKeyword(string _localizedText, bool localize = true, params object[] argum);
    public abstract void OnDisable();
}
