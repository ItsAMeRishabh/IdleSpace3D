using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using TMPro;
using System;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using System.Threading.Tasks;
using GS.GameEvents;

namespace GS
{
    namespace UI
    {
        /// <summary>
        /// This class holds the utilitys/extension methods for default functions which reduce our work.
        /// </summary>
        public static class UIUtil
        {
            #region BUTTON_EXTENSIONS

            private static GS.UI.IButtonAnimator buttonAnimator;

            public static void SetCustomButtonAnimator(IButtonAnimator buttonAnimator)
            {
                UIUtil.buttonAnimator = buttonAnimator;
            }

            public static Dictionary<string, float> processingButtons = new Dictionary<string, float>();

            public static async void RemoveProcessingButtons(string buttonName, int sleep = 10)
			{
                while(processingButtons.ContainsKey(buttonName) && processingButtons[buttonName] - Time.realtimeSinceStartup < 500)
				{
                    await Task.Delay(sleep);
				}
                if (processingButtons.ContainsKey(buttonName))
                {
                    processingButtons.Remove(buttonName);
                }
            }
            public static void AddButtonListener(Button button, Action<Button> callback)
            {
                if (button == null)
                    return;

                Button b = button;
                Vector3 intialScale = button.transform.localScale;

                if (buttonAnimator != null)
                {
                    var trigger = button.GetOrAddComponent<EventTrigger>();
                    if (trigger.triggers.Find(x => x.eventID == EventTriggerType.PointerDown) == null)
                    {
                        
                        var pointerDown = new EventTrigger.Entry();
                        pointerDown.eventID = EventTriggerType.PointerDown;
                        pointerDown.callback.AddListener((e) =>
                        {
                            if (button.interactable)
                            {
                                if (!processingButtons.ContainsKey(button.name))
                                {
                                    processingButtons.Add(button.name, Time.realtimeSinceStartup);
                                    //Utils.EventAsync(new InvokeActionEvent(RemoveProcessingButtons, 0.2f, "GTIME"));
                                    RemoveProcessingButtons(button.name);
                                }
                                else
								{
                                    return;
								}
                                buttonAnimator.OnButtonPressed(b);
                            }
                        });

                        var pointerExit = new EventTrigger.Entry();
                        pointerExit.eventID = EventTriggerType.PointerExit;
                        pointerExit.callback.AddListener((e) =>
                        {
                            if (button.interactable)
                            {
                                if (processingButtons.ContainsKey(button.name))
                                {
                                    processingButtons.Remove(button.name);
                                }
                                buttonAnimator.OnPointerExit(b, intialScale);
                            }
                        });

                        trigger.triggers.Add(pointerDown);
                        trigger.triggers.Add(pointerExit);
                    }

                    
                }

                button.onClick.AddListener(() =>
                {
                    if (processingButtons.ContainsKey(button.name))
                    {
                        processingButtons.Remove(button.name);
                    }
                    // if animation assigned, do animation and then calls OnClick
                    if (buttonAnimator != null)
                    {
                        buttonAnimator.OnButtonRelease(b, intialScale, callback);
                    }
                    else
                    {
                        callback?.Invoke(b);
                    }
                });
            }


            /// <summary>
            /// Changes the aplha of Button Element
            /// </summary>
            /// <param name="button"></param>
            /// <param name="value"></param>
            /// <param name="includeText"></param>
            /// <param name="duration"></param>
            /// <param name="ignoreTimeScale"></param>
            public static void SetAlpha(this Button button, float value, bool includeText, float duration = 0.0f, bool ignoreTimeScale = false)
            {
                if (button.image)
                    button.image.CrossFadeAlpha(value, duration, ignoreTimeScale);

                if (includeText)
                {
                    Text tx = button.GetComponentInChildren<Text>();
                    if (tx)
                        tx.CrossFadeAlpha(value, duration, ignoreTimeScale);
                    else
                    {
                        TextMeshProUGUI tmp = button.GetComponentInChildren<TextMeshProUGUI>();
                        if (tmp)
                        {
                            tmp.CrossFadeAlpha(value, duration, ignoreTimeScale);
                        }
                    }
                }
            }

            /// <summary>
            /// Change button visible text.
            /// </summary>
            /// <param name="button"></param>
            /// <param name="text"></param>
            public static void ChangeButtonText(this Button button, string text)
            {
                Text tx = button.GetComponentInChildren<Text>();
                if (tx != null) tx.text = text;
            }

            /// <summary>
            /// Change button name and text
            /// </summary>
            /// <param name="button"></param>
            /// <param name="name"></param>
            /// <param name="text"></param>
            public static void ChaneButtonNameAndText(this Button button, string name, string text)
            {
                if (button != null)
                {
                    button.gameObject.name = name;
                    button.ChangeButtonText(text);
                }
            }

            /// <summary>
            /// Cool down button functionality
            /// </summary>
            /// <param name="button"></param>
            /// <param name="duration"></param>
            /// <param name="visual"></param>
            public static void CoolDown(this Button button, float duration, GameObject visual)
            {
                 CoolDown(button, duration, visual, true, true);
            }

            /// <summary>
            /// Cool down button functionality
            /// </summary>
            /// <param name="button"></param>
            /// <param name="duration"></param>
            /// <param name="visual"></param>
            /// <param name="dispImage"></param>
            /// <param name="dispTimer"></param>
            /// <returns></returns>
            public static IEnumerator CoolDown(this Button button, float duration, GameObject visual, bool dispImage, bool dispTimer)
            {
                Button b = button;
                //Will disable the button;
                b.interactable = false;
                float time = duration;
                visual.SetActive(true);

                //Check if we need to display filler
                Image fillerImage = visual.GetComponent<Image>();
                if (fillerImage != null) fillerImage.enabled = dispImage;

                //Check wether we need to display the timer.
                Text countDownText = visual.GetComponentInChildren<Text>();
                if (countDownText != null) countDownText.gameObject.SetActive(dispTimer);

                while (time > 0f)
                {
                    time -= Time.deltaTime;

                    //Fill the image and display the text
                    if (fillerImage && fillerImage.enabled) fillerImage.fillAmount = time / duration;
                    if (countDownText && countDownText.gameObject.activeSelf) countDownText.text = time.ToString("00");

                    yield return null;
                }

                b.interactable = true;
                visual.SetActive(false);
            }

            #endregion

            #region RECT_TRANSFORM_EXTENSIONS

            /// <summary>
            /// Get the current size of the RectTransform as a Vector2
            /// </summary>
            /// <param name="trans"></param>
            /// <returns></returns>
            public static Vector2 GetSize(this RectTransform trans)
            {
                return trans.rect.size;
            }

            /// <summary>
            /// Get  width of the RectTransform
            /// </summary>
            /// <param name="trans"></param>
            /// <returns></returns>
            public static float GetWidth(this RectTransform trans)
            {
                return trans.rect.width;
            }

            /// <summary>
            /// Get height of the RectTransform
            /// </summary>
            /// <param name="trans"></param>
            /// <returns></returns>
            public static float GetHeight(this RectTransform trans)
            {
                return trans.rect.height;
            }

            /// <summary>
            /// Now we're talking. Set the position of a specific corner of the RectTransform within it's parent's coordinates--------------.
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newPos"></param>
            public static void SetPositionOfPivot(this RectTransform trans, Vector2 newPos)
            {
                trans.localPosition = new Vector3(newPos.x, newPos.y, trans.localPosition.z);
            }

            /// <summary>
            /// Move Transform postion  to Left Bottom 
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newPos"></param>
            public static void SetLeftBottomPosition(this RectTransform trans, Vector2 newPos)
            {
                trans.localPosition = new Vector3(newPos.x + (trans.pivot.x * trans.rect.width), newPos.y + (trans.pivot.y * trans.rect.height), trans.localPosition.z);
            }

            /// <summary>
            /// Move Transform postion  to Left Top
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newPos"></param>
            public static void SetLeftTopPosition(this RectTransform trans, Vector2 newPos)
            {
                trans.localPosition = new Vector3(newPos.x + (trans.pivot.x * trans.rect.width), newPos.y - ((1f - trans.pivot.y) * trans.rect.height), trans.localPosition.z);
            }

            /// <summary>
            /// Move Transform postion  to Right Bottom 
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newPos"></param>
            public static void SetRightBottomPosition(this RectTransform trans, Vector2 newPos)
            {
                trans.localPosition = new Vector3(newPos.x - ((1f - trans.pivot.x) * trans.rect.width), newPos.y + (trans.pivot.y * trans.rect.height), trans.localPosition.z);
            }

            /// <summary>
            /// Move Transform postion  to Left Top 
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newPos"></param>
            public static void SetRightTopPosition(this RectTransform trans, Vector2 newPos)
            {
                trans.localPosition = new Vector3(newPos.x - ((1f - trans.pivot.x) * trans.rect.width), newPos.y - ((1f - trans.pivot.y) * trans.rect.height), trans.localPosition.z);
            }

            /// <summary>
            /// Set the dimensions of the RectTransform regardless of its anchors, pivot and offsets.-------------------
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newSize"></param>
            public static void SetSize(this RectTransform trans, Vector2 newSize)
            {
                Vector2 oldSize = trans.rect.size;
                Vector2 deltaSize = newSize - oldSize;
                trans.offsetMin = trans.offsetMin - new Vector2(deltaSize.x * trans.pivot.x, deltaSize.y * trans.pivot.y);
                trans.offsetMax = trans.offsetMax + new Vector2(deltaSize.x * (1f - trans.pivot.x), deltaSize.y * (1f - trans.pivot.y));
            }

            /// <summary>
            /// Sets new width to Rect Transform
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newSize"></param>
            public static void SetWidth(this RectTransform trans, float newSize)
            {
                SetSize(trans, new Vector2(newSize, trans.rect.size.y));
            }

            /// <summary>
            /// Sets new height to Rect Transform
            /// </summary>
            /// <param name="trans"></param>
            /// <param name="newSize"></param>
            public static void SetHeight(this RectTransform trans, float newSize)
            {
                SetSize(trans, new Vector2(trans.rect.size.x, newSize));
            }
            #endregion

            
        }
    }
}

