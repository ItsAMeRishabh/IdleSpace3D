﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;
using GS.GameConsts;
using TMPro;

namespace GS.UI
{
    /// <summary>
    /// Attach this script to common PopupUI prefab
    /// </summary>
    public class UIPopupPanel : MonoBehaviour
    {


        /// <summary>
        /// Title in case if we want.
        /// </summary>
        public TextMeshProUGUI title;

        /// <summary>
        /// Message to display in the pop-up.
        /// </summary>
        public TextMeshProUGUI message;

        /// <summary>
        /// Icon to display in the pop-up
        /// </summary>
        public Image icon;

        public Text timeLeft;
        
        /// <summary>
        /// Panel contains Of YES/NO Buttons
        /// </summary>
        public Transform bottomPanel;
        
        /// <summary>
        /// Panel contains Of message and Icon
        /// </summary>
        public Transform messagePanel;

        public Button yesButton;
        public Button noButton;
        public Button closeButton;

        public System.Action destroyCallback;

        public UIPopupType _popUpType;

        private Animator _animator = null; //In case if we want any opening/closing animations.

        Action CloseEvent = null;
        Action NoEvent = null;

        private BaseUILocalization titleuiLocalization;
        private BaseUILocalization messageuiLocalization;

        /// <summary>
        /// Sets the Animator Parameter to animate Popup Transition Enable/Disable
        /// </summary>
        public bool IsOpen
        {
            get { return _animator.GetBool("IsOpen"); }
            set { _animator.SetBool("IsOpen", value); }
        }

        void Awake()
        {
            _animator = GetComponent<Animator>();

            _popUpType = UIPopupType.Info;

            titleuiLocalization = title.GetComponent<BaseUILocalization>();
            messageuiLocalization = message.GetComponent<BaseUILocalization>();
        }

        void OnEnable()
        {
            if (timeLeft)
            {
                if (timeLeft.gameObject.activeSelf)
                    timeLeft.gameObject.SetActive(false);
            }
        }

        /// <summary>
        /// Construct Panel based on parameters
        /// </summary>
        /// <param name="title"></param>
        /// <param name="icon"></param>
        /// <param name="message"></param>
        /// <param name="type"></param>
        /// <param name="yesEvent"></param>
        /// <param name="noEvent"></param>
        /// <param name="closeEvent"></param>
        /// <param name="timeToDisplay"></param>
        public void Setup(string title, string message, Sprite sprite, UIPopupType type, System.Action yesEvent, System.Action noEvent,
                                                                                        System.Action closeEvent, float timeToDisplay = 1.0f,bool _localize=true)
        {
            //This will make sure that this is rendered on top of everything.
            transform.SetAsLastSibling();

            SetupTitleImageAndMessage(title, sprite, message,_localize);
            SetupButtons(type, yesEvent, noEvent, closeEvent, timeToDisplay);

             if (_animator != null)
                IsOpen = true;
        }


        public void Setup_Paytm(Sprite sprite, string title, string message, System.Action yesEvent, System.Action closeEvent, object[] titleParam = null, object[] descriptionParam = null,bool _localize=true)
        {
            transform.SetAsLastSibling();

            SetupTitleImageAndMessage_Paytm(title, message, sprite,titleParam, descriptionParam, _localize);
            SetupButtons_Paytm(yesEvent,closeEvent);

            if (_animator != null)
                IsOpen = true;

        }

        private void SetupTitleImageAndMessage_Paytm(string titleMsg, string description, Sprite sprite, object[] titleParam, object[] descriptionParam, bool _localize= true)
        {
            if (icon && sprite) icon.sprite = sprite;
            if (CheckForLocalization())
            {
                if (title) titleuiLocalization.UpdateKeyword(titleMsg, _localize, titleParam);
                if (message && !string.IsNullOrEmpty(description)) messageuiLocalization.UpdateKeyword(description,_localize,descriptionParam);
                else if (message || string.IsNullOrEmpty(description))
                    messagePanel.gameObject.SetActive(false);
            }
            else
            {
                Debug.LogWarning($"Commponent Reference is Missing in the prefab");
                if (title) title.SetText(titleMsg);
                if (message || !string.IsNullOrEmpty(description)) message.SetText(description);
            }
        }
        private void SetupButtons_Paytm(System.Action yesEvent, System.Action closeEvent)
        {
            //yesButton.onClick.RemoveAllListeners();

            if (yesEvent != null) UIUtil.AddButtonListener(yesButton, (yes) => { yesEvent(); });
            
            UIUtil.AddButtonListener(yesButton, (yes) => { DoDestroyPopup(); });

            if (closeEvent != null) UIUtil.AddButtonListener(closeButton, (close) => { closeEvent(); CloseEvent = closeEvent; });
            //else Debug.Log("<color=red>There is no event provided for CLOSE button in pop-up, IGNORE IF INTENSIONAL</color>", this);

            UIUtil.AddButtonListener(closeButton, (close) => { DoDestroyPopup(); });
        }

        private void RaiseButtonEvent(Button button)
        {
            Utils.EventAsync(new GameEvents.UIEvent(-1, button.name, UnityExtensions.GetUIWorldPosition(button.transform)));
        }

        public void UpdateButtonListener()
        {
            if (yesButton != null)
                UIUtil.AddButtonListener(yesButton, (yes) => RaiseButtonEvent(yes));
            if (noButton != null)
                UIUtil.AddButtonListener(noButton, (no) => RaiseButtonEvent(no));
            if (closeButton != null)
                UIUtil.AddButtonListener(closeButton, (close) => RaiseButtonEvent(close));
        }
        
        

        /// <summary>
        /// Setup Title, Image and message
        /// </summary>
        /// <param name="titleText"></param>
        /// <param name="sprite"></param>
        /// <param name="msg"></param>
        private void SetupTitleImageAndMessage(string titleText, Sprite sprite, string msg,bool _localize=true)
        {
            if (CheckForLocalization())
            {
               if (title) titleuiLocalization.UpdateKeyword(titleText, _localize);
               if (message && !string.IsNullOrEmpty(msg))
                    messageuiLocalization.UpdateKeyword(msg,_localize);
                else if (message || string.IsNullOrEmpty(msg))
                    messagePanel.gameObject.SetActive(false);
            }
            else
            {
                Debug.LogWarning($"Commponent Reference is Missing in the prefab");
                if (title) title.text = titleText;
                if (title) title.SetText(titleText);
                if (message && !string.IsNullOrEmpty(msg))
                    message.SetText(msg);
                else if (message || string.IsNullOrEmpty(msg))
                    messagePanel.gameObject.SetActive(false);
            }
            if (sprite)
                if (sprite)
                    icon.sprite = sprite;
            icon.sprite = sprite;
            //else
            //else
            //    icon.gameObject.SetActive(false);
            //    icon.gameObject.SetActive(false);
        }

        /// <summary>
        /// Enable or disables buttons based on type of pop up.
        /// </summary>
        /// <param name="popupType"></param>
        /// <param name="yesEvent"></param>
        /// <param name="noEvent"></param>
        /// <param name="closeEvent"></param>
        /// <param name="timeToDisplay"></param>
        private void SetupButtons(UIPopupType popupType, System.Action yesEvent, System.Action noEvent, System.Action closeEvent, float timeToDisplay = 1.0f)
        {
            this._popUpType = popupType;

            if (yesEvent != null && noEvent != null && bottomPanel != null)
            {
                bottomPanel.gameObject.SetActive(true);
            }

            switch (popupType)
            {
                case UIPopupType.Info:

                    bottomPanel.gameObject.SetActive(false);

                    //There are no YES/NO buttons are not there hence
                    closeButton.onClick.RemoveAllListeners();

                    if (closeEvent != null)
                        UIUtil.AddButtonListener(closeButton, (close) => { closeEvent(); });
                    //else Debug.Log("<color=red>There is no event provided for CLOSE button in popup, IGNORE IF INTENSIONAL</color>", this);

                    UIUtil.AddButtonListener(closeButton, (close) => { DoDestroyPopup(); });
                    break;
                case UIPopupType.Prompt:
                    closeButton.gameObject.SetActive(false);


                    yesButton.onClick.RemoveAllListeners();

                    if (yesEvent != null)
                        UIUtil.AddButtonListener(yesButton, (yes) => { yesEvent(); });
                    else
                        Log.Print("There is no event provided for YES button in popup, IGNORE IF INTENSIONAL</color>", this, LogFilter.Error);

                    UIUtil.AddButtonListener(yesButton, (yes) => { DoDestroyPopup(); });

                    noButton.onClick.RemoveAllListeners();

                    if (noEvent != null)
                        UIUtil.AddButtonListener(noButton, (no) => { noEvent(); NoEvent = noEvent; });
                    //else Debug.Log("<color=red>There is no event provided for NO button in popup, IGNORE IF INTENSIONAL</color>", this);

                    UIUtil.AddButtonListener(noButton, (no) => { DoDestroyPopup(); });
                    break;
                case UIPopupType.Static:
                    bottomPanel.gameObject.SetActive(false);
                    closeButton.gameObject.SetActive(false);
                    break;
                case UIPopupType.Timed:
                    bottomPanel.gameObject.SetActive(false);
                    closeButton.gameObject.SetActive(false);

                    StartCoroutine("UpdateTimer", timeToDisplay);
                    //Invoke destroy pop-up in given time.
                    //Invoke("DestroyPopup", timeToDisplay);
                    break;
            }
        }

        public void ClosePopUp()
        {
            if (_popUpType != UIPopupType.Static || _popUpType != UIPopupType.Timed)
            {
                // Invoke 'No/Close' buttons as popUp is closing on device back button
                if (noButton != null) // && noButton.onClick.GetPersistentEventCount() != null)
                { 
                noButton.onClick.Invoke();
                    NoEvent?.Invoke();
                    NoEvent = null;
                }
                if (closeButton != null) // && noButton.onClick.GetPersistentEventCount() != null)
                { 
                    closeButton.onClick.Invoke();
                    CloseEvent?.Invoke();
                    CloseEvent = null;
                }

                DoDestroyPopup();
            }
        }

        /// <summary>
        /// Updates the Popup Panel
        /// Check if the animator is there and played Close animation then destroy the object.
        /// Escape/Device Back key functionality
        /// </summary>
        void Update()
        {
            if (_animator != null)
            {
                if (IsOpen == false && _animator.GetCurrentAnimatorStateInfo(0).IsName("Close"))
                {
                    if (_animator.GetCurrentAnimatorStateInfo(0).normalizedTime > 0.95f)
                    {
                        //Almost finished the Close animation for the popup so destroy the object.
                        DestroyPopup();
                    }
                }
            }
        }

        //Destroy the pop-up.
        private void DoDestroyPopup()
        {
            if (_animator != null)
            {
                if (!_animator.GetAnimatorTransitionInfo(0).IsName("Close"))
                    IsOpen = false;
            }
            else
            {
                DestroyPopup();
            }
        }

        void DestroyPopup()
        {
            Destroy(gameObject);
        }

        //Update the timer if the pop-up is timed.
        IEnumerator UpdateTimer(float time)
        {
            timeLeft.gameObject.SetActive(true);

            while (time > 0)
            {
                time -= Time.deltaTime;
                timeLeft.text = "This pop-up will be closed automatically in " + time.ToString("00") + " secs.";
                yield return null;
            }

            timeLeft.gameObject.SetActive(false);
            DoDestroyPopup();
        }

        private void OnDestroy()
        {
            if (destroyCallback != null)
                destroyCallback();
        }
        public bool CheckForLocalization()
        {
            if (titleuiLocalization == null || messageuiLocalization == null)
            {
                return false;
            }
            return true;
        }
    }
}