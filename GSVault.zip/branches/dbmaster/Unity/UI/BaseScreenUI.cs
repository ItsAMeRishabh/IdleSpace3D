﻿using GS.Events;
using GS.GameConsts;
using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace GS
{
    namespace UI
    {

            

            /// <summary>
        /// Base Screen for all UI Screens
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public abstract class BaseScreenUI<T> : IMonoState where T : IConvertible
        {
            //every screen needs to have an ID
            public T screenID; // defaultIndex
            public bool isUnscaleTimeAnimation = false;
            
            //Check wether this screen requires animation when opening and closing
            
            [Header("Set if  you need animations for this screen while opening and closing")]
            public bool requireAnimations = true;

            IScreenTransition screenTransition;
            [HideInInspector]
            public CanvasGroup canvasGroup;

            protected string title;
            // private ButtonSound _audioObject;

            /// <summary>
            /// Holds CoolDown counter after 'Onclick' happaned in this screen
            /// </summary>
            private sbyte onClickCoolDownCounter;
            


            [Header("Add Events here")]
            public UIPair[] uIPairs;

            public override void DoBeforeLeaving()
            {
                if (screenTransition != null && !screenTransition.IsClosing())
                    IsAnimationOpen(false);
                else
                    base.DoBeforeLeaving();
            }

            public override void DoBeforeEntering()
            {
                base.DoBeforeEntering();

                if (screenTransition != null && !screenTransition.IsOpening())
                    IsAnimationOpen(true);
                else
                    SetInteractable(true);
            }

            public override int GetStateID()
            {
                return (int)(object)screenID;
            }

            protected virtual void SetScreenTransition(IScreenTransition transition)
            {
                screenTransition = transition;
                if (screenTransition != null)
                    screenTransition.OnInitialize(gameObject, requireAnimations);
            }

            //used to set the screenID and useful stuff
            public virtual void Awake()
            {
                //Register the Onclick event
                //This avoids setting OnClick function in the inspector for every screen.
                Button[] buttons = GetComponentsInChildren<Button>(true);

                foreach (Button button in buttons)
                {
                    UIUtil.AddButtonListener(button, OnClick);
                }

                ///Register call backs for Toggles available in the screen....
                Toggle[] toggles = GetComponentsInChildren<Toggle>(true);
                foreach (Toggle toggle in toggles)
                {
                    Toggle t = toggle;
                    toggle.onValueChanged.AddListener((bool val) => OnValueChange(t, val));
                }

                ///Register call backs for Scroll Views available in the screen....
                ScrollRect[] scrollViews = GetComponentsInChildren<ScrollRect>(true);
                foreach (ScrollRect scrollView in scrollViews)
                {
                    ScrollRect scrollRect = scrollView;
                    scrollView.onValueChanged.AddListener((Vector2 val) => OnScrollValueChanged(scrollRect));
                }

               

                //Get CanvasGroup
                canvasGroup = GetComponent<CanvasGroup>();
                if (canvasGroup == null)
                    canvasGroup = gameObject.AddComponent<CanvasGroup>();

                //This peice of code will place the menu at 0,0 even if you put it anywhere in scene view
                var rect = GetComponent<RectTransform>();
                rect.offsetMax = rect.offsetMin = new Vector2(0, 0);
            }

            public virtual void OnEnable()
            {
                if(screenTransition != null && !screenTransition.IsOpening())
                    IsAnimationOpen(true);
                else
                    SetInteractable(true);
            }

            

            /// <summary>
            /// Use this method to check subPanel ID if required to open directly that subPanel
            /// </summary>
            /// <param name="subPanelID"></param>
            protected virtual void checkGoToSubPanelDirectly(int subPanelID)
            {

            }

            /// <summary>
            /// This will be called before Awake
            /// </summary>
            public virtual void Init()
            {
                if (alwaysVisible)
                    gameObject.SetActive(true);
            }

          

            public void ReassignListenersToButtons(Button button)
            {
                registerButtonListener(button);
            }

            public void ReassignListenersToButtons(Button[] buttons)
            {
                foreach (Button button in buttons)
                {
                    registerButtonListener(button);
                }
            }

            private void registerButtonListener(Button button)
            {
                Button b = button;
                button.onClick.RemoveAllListeners();
                UIUtil.AddButtonListener(button, OnClick);
            }
            public void ReassignListenersToToggles(Toggle toggle)
            {
                registerToggleListner(toggle);
            }

            public void ReassignListenersToToggles(Toggle[] toggles)
            {
                foreach (Toggle toggle in toggles)
                {
                    registerToggleListner(toggle);
                }
            }

            private void registerToggleListner(Toggle toggle)
            {
                Toggle t = toggle;
                toggle.onValueChanged.RemoveAllListeners();
                toggle.onValueChanged.AddListener((bool val) => OnValueChange(t, val));
            }


            /// <summary>
            /// This will be called if any Toggle value changed
            /// </summary>
            /// <param name="toggle">Toggle object</param>
            /// <param name="isOn">On/Off</param>
            public virtual void OnValueChange(Toggle toggle, bool isOn)
            {
                if (isOn)
                    Log.Print("UIToggle : " + "[" + toggle.name + ", " + isOn + "]", LogFilter.UI);
                var worldPosition = toggle.transform.TransformPoint(toggle.transform.position);
                Utils.EventAsync(new GameEvents.UIEvent(Convert.ToInt32(screenID), toggle.name, UnityExtensions.GetUIWorldPosition(toggle.transform), isOn));
            }

            /// <summary>
            /// This will be called if any Scroll View  value changed
            /// </summary>
            public virtual void OnScrollValueChanged(ScrollRect scrollRect)
            {
            }

            /// <summary>
            /// Raises UI Event Type
            /// </summary>
            /// <param name="buttonName"></param>
            protected void RaiseButtonEvent(Button button)
            {
                Utils.EventAsync(new GameEvents.UIEvent(Convert.ToInt32(screenID), button.name, UnityExtensions.GetUIWorldPosition(button.transform)));
            }

            public void SwitchScreen(int screenID)
            {
                Utils.EventAsync(new GameEvents.UIScreenEvent(screenID, UIScreenEventType.Switch));
            }

            /// <summary>
            /// OnClick function handles all the button clicks in that screen 
            /// </summary>
            /// <param name="button"></param>
            public virtual void OnClick(Button button)
            {
                Log.Print("UIButton Clicked : " + "[" + button.name + "]", LogFilter.UI);

                // As we are going with event based system, we need buffer in between multiple(at signle time) onclicks in same screen.
                // Otherwise, tapping on two buttons at a time will enable two screens(either overlap or flow altered in device back button)
                DisableInteractableTemporarily(2);


                // PlayAudio ((int)GameConsts.Enums.ButtonSounds._buttonClick);
                //Once after execution check wether the button has CoolDown timer attached 
                if(uIPairs != null)
                {
                    for(int i=0;i<uIPairs.Length;i++)
                    {
                        if(button.name.Equals(uIPairs[i].buttonName))
                        {
                            if (uIPairs[i].eventType == UIEventType.SwitchScreen)
                                SwitchScreen(uIPairs[i].screenID);
                            break;
                        }
                    }
                }

                //Write common button functionality in this.
                switch (button.name)
                {
                    case "Back":
                        Log.Print("Back pressed", LogFilter.UI);
                        Utils.EventSync(new BackKeyPressed());
                        break;

                    default:
                        break;
                }
                
                RaiseButtonEvent(button);
            }

            public virtual void OnBackKeyPressed()
            {
                
            }
           


            

            /// <summary>
            /// Disable interations at the screen transitions
            /// Closes the screen, if Close animation done
            /// </summary>
            public virtual void Update()
            {
                bool isTutorialActive = false;
                if (TutorialManager.IsInstatiated() && TutorialManager.Instance.IsTutorialActive)
                {
                    isTutorialActive = true;
                }
                if (Input.GetKeyDown(KeyCode.Escape) && !NetworkUtils.IsBackBlocked && !isTutorialActive)
                    OnBackKeyPressed();

                // Check 'OnClick' CoolDown Counter
                if (onClickCoolDownCounter > 0)
                {
                    onClickCoolDownCounter--;
                    if (onClickCoolDownCounter == 0)
                        SetInteractable(true);
                }

                if (screenTransition != null && requireAnimations)
                    screenTransition.Update(gameObject, canvasGroup);
            }

            /// <summary>
            /// Find Button By Name
            /// </summary>
            /// <param name="name"></param>
            /// <param name="checkDisabled"></param>
            /// <returns></returns>
            public Button GetButton(string name, bool checkDisabled)
            {
                Button[] avalilableButtons = GetComponentsInChildren<Button>(checkDisabled);
                foreach (Button b in avalilableButtons)
                {
                    if (b.name == name)
                        return b;
                }

                return null;
            }

            /// <summary>
            /// Disables current screens interactablity and sets 'Onclick CoolDownCounter'
            /// </summary>
            /// <param name="noOfFrames"></param>
            private void DisableInteractableTemporarily(sbyte noOfFrames)
            {
                SetInteractable(false);
                onClickCoolDownCounter = noOfFrames;
            }

            /// <summary>
            /// Enable/Disable Interactability of the screen
            /// </summary>
            /// <param name="val"></param>
            public void SetInteractable(bool val)
            {
                UIBlocker.Instance.gameObject.SetActive(!val);
            }

            public void Enable(bool isActive)
            {
                gameObject.SetActive(isActive);
            }

            public int GetScreenID()
            {
                return Convert.ToInt32(screenID);
            }

            public CanvasGroup GetCanvasGroup()
            {
                return GetComponent<CanvasGroup>();
            }


            /// <summary>
            /// can goback to Previous Screen
            /// </summary>
            /// <returns></returns>
            public bool CanGoToPreviousScreen()
            {
                return canGoBack;
            }


            protected int GetSiblingIndex()
            {
                return transform.GetSiblingIndex();
            }

            protected void SetSiblingIndex(int index)
            {
                transform.SetSiblingIndex(index);
            }

            

            protected void IsAnimationOpen(bool isOpen)
            {
                if (screenTransition != null)
                    screenTransition.IsOpen = isOpen;
            }

            protected GameObject AddChild(string name, GameObject childPrefab, Transform parentTransform)
            {
                if (childPrefab == null)
                    return null;
                GameObject child = GameObject.Instantiate(childPrefab, parentTransform);
                child.name = name;
                return child;
            }
        }
    }
}
