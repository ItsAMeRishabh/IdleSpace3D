﻿using GS.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


//public class CountDownTimer : MonoBehaviour
//{
//    public Text refTxt;
//    Text txt;

//    public List<Text> action;

//    // Start is called before the first frame update
//    void Start()
//    {
//        txt = transform.GetComponentInChildren<Text>();

//        //action
//    }

//    private void OnEnable()
//    {

//    }

//    // Update is called once per frame
//    void Update()
//    {
//        //if (txt)
//    }

//    void OnLocalTimerUpdate()
//    {

//    }

//}

namespace GS
{
    public class TimeUtils : GS.Unity.SingleTon<TimeUtils>
    {

        UnityEngine.Networking.UnityWebRequest webReq;
        string url = "http://vroovygames.com/Cricket/Cricket2/time.php";
        double timeInSeconds;
        public System.DateTime currentUTCTime;
        public bool isTimeReceived = false;
        List<TimerComponentEvent> timerComponentEvents = new List<TimerComponentEvent>();
        private float timer = 1f;
        IEnumerator smoothSliderReference;


        // Use this for initialization
        public void Start()
        {
            // EventManager.Instance.AddListener<GameEvents.ApplicationFocusEvent>(onApplicationFocus);
            EventManager.Instance.AddListener<TimerComponentEvent>(onTimerComponentEvent);
            EventManager.Instance.AddListener<RemoveTimerComponentEvents>(onRemoveTimerComponentEvents);
            EventManager.Instance.AddListener<GameEvents.ApplicationFocusEvent>(onApplicationFocus);
            EventManager.Instance.AddListener<GetCurrentTimeEvent>(onGetTimeEvent);
            GetTime();

        }

        private void onRemoveTimerComponentEvents(RemoveTimerComponentEvents e)
        {
            if (timerComponentEvents.Contains(e.removeTimerComponentEvent))
            {
                if (smoothSliderReference != null)
                    StopCoroutine(smoothSliderReference);
                timerComponentEvents.Remove(e.removeTimerComponentEvent);
            }
        }

        private void onGetTimeEvent(GetCurrentTimeEvent e)
        {
            e.callbackWithCurrentTime(currentUTCTime);
        }

        private void onTimerComponentEvent(TimerComponentEvent e)
        {
            e.initTime = currentUTCTime;
            timerComponentEvents.Add(e);
        }

        private void onApplicationFocus(GameEvents.ApplicationFocusEvent e)
        {
            if (e.focus)
                GetTime();
        }

        public void GetTime()
        {
            //if (true)
            //{
            StartCoroutine(FetchTime());
            //}
            //else
            //{
            //    //Temporary fix for energy time to countdown if there is no internet
            //    Debug.Log((int)(System.DateTime.UtcNow - new System.DateTime(1970, 1, 1)).TotalSeconds);
            //    timeInSeconds = (int)(System.DateTime.UtcNow - new System.DateTime(1970, 1, 1)).TotalSeconds;
            //    //if (double.TryParse(webReq.text, out timeInSeconds))
            //    setTimeData();
            //}
        }


        IEnumerator FetchTime()
        {
            using (webReq = UnityEngine.Networking.UnityWebRequest.Get(url))
            {
                yield return webReq.SendWebRequest();
                if (string.IsNullOrEmpty(webReq.error))
                {
                    if (double.TryParse(webReq.downloadHandler.text, out timeInSeconds))
                    {
                        currentUTCTime = new System.DateTime(1970, 1, 1);
                        currentUTCTime = currentUTCTime.AddSeconds(timeInSeconds);
                        isTimeReceived = true;
                        CancelInvoke("UpdateTime");
                        InvokeRepeating("UpdateTime", 1, 1);
                    }
                }
                else
                {
                    CancelInvoke("GetTime");
                    Invoke("GetTime", 120);
                }
                yield return null;
            }
        }

        public void UpdateTime()
        {
            currentUTCTime = currentUTCTime.AddSeconds(1);
            UpdateTimerComponentValues();
        }

        float previousSliderValue = 1;
        float previousCuttedValue = 0;
        /// <summary>
        /// This method gets called after every 1 sec
        /// </summary>
        private void UpdateTimerComponentValues()
        {
            
            for (int i = 0; i < timerComponentEvents.Count; )
            {
                bool removedItem = false;

                TimerComponentEvent timerComponentEvent = timerComponentEvents[i];

                if (timerComponentEvent.timerComponent.timerType == TimerType.remainingTime)
                {
                    double secondsCompleted = (currentUTCTime - timerComponentEvent.initTime).TotalSeconds;
                    timerComponentEvent.timerComponent.RemainingTime -= 1;

                    // check if the remaing time of the timer is less than 0
                    if(timerComponentEvent.timerComponent.RemainingTime <= 0)
                    {
                        //Raise an event notifying the time has completed 
                       if(timerComponentEvents[i].onTimerCompleted != null)
                        {
                            timerComponentEvents[i].onTimerCompleted(timerComponentEvents[i].callBackGameobject);
                        }
                        // remove the event from events list
                        timerComponentEvents.RemoveAt(i);

                        removedItem = true;
                    }
                    // else update the timer display
                    else
                    {
                        if (timerComponentEvents[i].timerComponent.text != null)
                        {
                            UpdateTimeInFormat(timerComponentEvents[i].timerComponent);
                        }
                        if (timerComponentEvents[i].timerComponent.slider != null)
                        {
                            if (timerComponentEvents[i].timerComponent.slider.value <= timerComponentEvents[i].timerComponent.slider.minValue)
                            {
                                timerComponentEvents[i].onTimerCompleted(timerComponentEvents[i].callBackGameobject);
                                timerComponentEvents.RemoveAt(i);
                                return;
                            }
                            if (smoothSliderReference!=null)
                            StopCoroutine(smoothSliderReference);
                            //timerComponentEvents[i].timerComponent.slider.value = float.Parse(((timerComponentEvent.timerComponent.RemainingTime+1) / (timerComponentEvent.timerComponent.RemainingTime+1 + secondsCompleted-1)).ToString());
                            if (timerComponentEvents[i].timerComponent.slider.value == 1)
                            {
                                previousSliderValue = 1;
                                previousCuttedValue = 0;
                            }
                            timerComponentEvents[i].timerComponent.slider.value = previousSliderValue - previousCuttedValue;

                            //Debug.LogWarning("Before Slider Value " + timerComponentEvents[i].timerComponent.slider.value);
                            //Debug.LogWarning("slider Value "+ timerComponentEvents[i].timerComponent.slider.value+"float value "+ float.Parse(((timerComponentEvent.timerComponent.RemainingTime) / (timerComponentEvent.timerComponent.RemainingTime + secondsCompleted)).ToString()));
                            previousSliderValue = previousSliderValue - previousCuttedValue;
                            previousCuttedValue = (timerComponentEvents[i].timerComponent.slider.value - timerComponentEvents[i].timerComponent.toSliderValue) / 20;
                            // StartCoroutine(smoothSliderReference = SmoothSlider(timerComponentEvents[i].timerComponent.slider.value - float.Parse(((timerComponentEvent.timerComponent.RemainingTime) / (timerComponentEvent.timerComponent.RemainingTime + secondsCompleted)).ToString()),timerComponentEvents[i].timerComponent.slider));
                            StartCoroutine(smoothSliderReference = SmoothSlider(previousCuttedValue, timerComponentEvents[i].timerComponent.slider));
                            // timerComponentEvents[i].timerComponent.slider.value = float.Parse(((timerComponentEvent.timerComponent.RemainingTime)/ (timerComponentEvent.timerComponent.RemainingTime+ secondsCompleted)).ToString());
                        }
                    }
                }
                else
                {
                    // if both time fall on same date then change the timer type to remaining time
                    if (timerComponentEvent.timerComponent.TargetTime.Day == currentUTCTime.Day &&
                        timerComponentEvent.timerComponent.TargetTime.Month == currentUTCTime.Month &&
                        timerComponentEvent.timerComponent.TargetTime.Year == currentUTCTime.Year)
                    {
                        timerComponentEvent.timerComponent.timerType = TimerType.remainingTime;
                        double timeDiff = (timerComponentEvent.timerComponent.TargetTime - currentUTCTime).TotalSeconds;
                        timerComponentEvent.timerComponent.RemainingTime = timeDiff < 0 ? 0 : timeDiff;
                    }
                    else
                    {
                        UpdateTimeInFormat(timerComponentEvents[i].timerComponent);
                    }

                }

                if (!removedItem)
                {
                    i++;
                }
            }
        }

        IEnumerator SmoothSlider(float maxToDecreaseInOneSecond, Slider slider)
        {
            //Debug.LogWarning("max to decrease in one sencond " + maxToDecreaseInOneSecond);
            timer = 1;
            float SliderValue = slider.value;
            int i = 10;
            while (i > 0)
            {
                i--;
                //Debug.Log("i:"+ i);
                timer = maxToDecreaseInOneSecond/10;
                slider.value -= timer;//SliderValue - timer;  //Mathf.Lerp(SliderValue - maxToDecreaseInOneSecond, SliderValue, timer);
                //Debug.LogError("i" + i + "timer:" + timer + " slider " + slider.value);
                yield return new WaitForSeconds(0.1f);// WaitForSeconds(Time.unscaledDeltaTime);
            }
           // Debug.LogWarning("timeR2:" + slider.value);

        }


        private void UpdateTimeInFormat(TimerComponent timerComponent)
        {
            Text text = timerComponent.text;

            if (timerComponent.timerType == TimerType.remainingTime)
            {
                TimeSpan remaingRef = (timerComponent.TargetTime - currentUTCTime);
                //text.text = "" + timerComponent.RemainingTime.ToString(timerComponent.rtDisplayPattern);//"c"
                text.text = "" + remaingRef.ToString(timerComponent.rtDisplayPattern);//"c"

            }
            else
            {
                text.text = "" + timerComponent.TargetTime.ToString(timerComponent.ttDisplayPattern).Replace("\\n", "\n"); ;//"MM/dd/yyyy hh:mm tt"
            }
        }

        //Temporary fix for energy time to countdown if there is no internet
        void setTimeData()
        {
            currentUTCTime = new System.DateTime(1970, 1, 1);
            currentUTCTime = currentUTCTime.AddSeconds(timeInSeconds);
            isTimeReceived = true;
            CancelInvoke("UpdateTime");
            InvokeRepeating("UpdateTime", 1, 1);
        }
    }
}