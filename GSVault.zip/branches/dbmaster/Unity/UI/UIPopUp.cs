﻿using GS.Events;
using GS.GameConsts;
using System;
using UnityEngine;

namespace GS.UI
{
    class UIPopUp : IPopUP
    {
        public GameObject popUpTemplate;
        public GameObject popUpTemplateForPayTm;

        public UIPopupPanel popUpPanel;
        public bool isEnabled = false;

        public bool IsEnabled()
        {
            return popUpPanel != null;
        }

        public void ShowPopUp(UIPopUPEvent uIPopUPEvent)
        {
            if (IsEnabled())
                return;

            GameObject popUp;

            Sprite icon = null;
            UnitySprite uSpr = (UnitySprite)uIPopUPEvent.icon;
            if (uSpr != null)
                icon = uSpr.GetSprite();

            if (uIPopUPEvent.uIPopUpPrefabType == UIPopUpPrefabType.Basic)
            {
                // TODO : Load PopUp template  using Data Events here 
                if (popUpTemplate == null)
                    Utils.EventSync(new Data.LoadPrefabEvent(Data.DataConsts.AssetDataBundleKeys.UIPrefabs, Data.DataConsts.AssetDataBundleKeys.UIPrefabs + "/Popups/POP_UP", onPopUpTemplateLoaded));


                if (popUpTemplate != null)
                {
                    popUp = GameObject.Instantiate(popUpTemplate, Vector3.zero, Quaternion.identity) as GameObject;

                    popUpPanel = popUp.GetComponent<UIPopupPanel>();

                    if (popUpPanel != null)
                    {
                        popUpPanel.destroyCallback = OnPopUpDestroyed;
                        popUpPanel.Setup(uIPopUPEvent.title, uIPopUPEvent.message, icon, uIPopUPEvent.type, uIPopUPEvent.yesEvent, uIPopUPEvent.noEvent, uIPopUPEvent.cancelEvent, uIPopUPEvent.timeToClose,uIPopUPEvent.localize);
                    }
                }
                else
                    Log.Print("UIPopUpManager - PopUp template not loaded !!", LogFilter.Error);
            }

            if (uIPopUPEvent.uIPopUpPrefabType == UIPopUpPrefabType.PayTm)
            {

                if (popUpTemplateForPayTm == null)
                    Utils.EventSync(new Data.LoadPrefabEvent(Data.DataConsts.AssetDataBundleKeys.UIPrefabs, Data.DataConsts.AssetDataBundleKeys.UIPrefabs + "/Popups/Pop_Up_2", (prefab) => popUpTemplateForPayTm = prefab));

                if (popUpTemplateForPayTm != null)
                {
                    popUp = GameObject.Instantiate(popUpTemplateForPayTm, Vector3.zero, Quaternion.identity) as GameObject;

                    popUpPanel = popUp.GetComponent<UIPopupPanel>();

                    if (popUpPanel != null)
                    {
                        popUpPanel.destroyCallback = OnPopUpDestroyed;
                        popUpPanel.Setup_Paytm(icon, uIPopUPEvent.title, uIPopUPEvent.message, uIPopUPEvent.yesEvent, uIPopUPEvent.cancelEvent, uIPopUPEvent.titleParam, uIPopUPEvent.messageParam,uIPopUPEvent.localize);
                    }
                }
                else
                    Log.Print("UIPopUpManager - PopUp template not loaded !!", LogFilter.Error);
            }

            if (popUpPanel != null)
                popUpPanel.UpdateButtonListener();
        }

        private void onPopUpTemplateLoaded(GameObject popUp)
        {
            popUpTemplate = popUp;
        }

        private void OnPopUpDestroyed()
        {
            isEnabled = false;
            popUpPanel = null;
        }

        public void OnBackKeyPressed()
        {
            if (popUpPanel != null)
                popUpPanel.ClosePopUp();
        }
    }
}
