﻿using GS.GameConsts;
using System.Collections.Generic;
using UnityEngine;


namespace GS.Audio
{
    [System.Serializable]
    public class AudioChannel
    {
        public string name;
        [SerializeField]
        public AudioClip[] clipsInfo;

        
    }

    /// <summary>
    /// Holds the list of Audio FX files and BG Music
    /// Every scene might have different instance of PlayList
    /// </summary>
    [CreateAssetMenu()]
    public class AudioPlayList : ScriptableObject
    {
        [Header("ChannelType = 0 - Music, 1 - SFX, 2 - Voice")]
        
        public AudioChannel[] audioChannels;

    }
}