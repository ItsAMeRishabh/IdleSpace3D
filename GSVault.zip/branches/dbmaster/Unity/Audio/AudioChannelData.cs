﻿using UnityEngine;


namespace GS.Audio
{
    public class AudioChannelData
    {
        public bool mute = false;
        public float volume = 1.0f;
        public AudioSource source;


        private bool startFading = false;
        private float fadeStartVolume = 0.2f;
        private float fadeTargetVolume = 1.0f;
        private float fadeSpeed = 1.0f;
        private float fadeElapsedTime = 0.0f;

        public void FadeIn(float fromVolume, float toVolume, float speed)
        {
            // audioSource.volume = fromVolume;
            fadeStartVolume = fromVolume;
            fadeTargetVolume = toVolume;
            startFading = true;
            fadeElapsedTime = 0.0f;
            fadeSpeed = speed;
        }

        public void Update()
        {
            if (startFading && source != null)
            {
                fadeElapsedTime += Time.deltaTime * fadeSpeed;

                if (fadeElapsedTime >= 1.0f)
                {
                    source.volume = fadeTargetVolume;
                    startFading = false;
                }
                else
                {
                    source.volume = Mathf.Lerp(fadeStartVolume, fadeTargetVolume, fadeElapsedTime);
                }
            }
        }

    }
}
