﻿using System;
using UnityEngine;
using GS.GameConsts;

namespace GS.Audio
{


    public class AudioSystem : IAudioSystem
    {
        private GameObject audioGo = null;
        private AudioChannelData[] channels;
        private AudioPlayList currentPlayList;

        protected float masterVolume = 1.0f;

        public virtual void Initialize()
        {
            audioGo = new GameObject();
            audioGo.name = "AudioSystem";

            int length = Enum.GetNames(typeof(AudioChannelType)).Length;
            channels = new AudioChannelData[length];
           

            audioGo.AddComponent<AudioListener>();

#if UNITY_EDITOR
            GS.UnityExtensions.MarkAsGSObject(audioGo);
#endif
            GameObject.DontDestroyOnLoad(audioGo);
        }

        /// <summary>
		/// Sets the current scene Lists of sounds 
		/// </summary>
		/// <param name="vault"></param>
		public void SetPlayList(AudioPlayList vault)
        {
            currentPlayList = vault;
            if (currentPlayList == null || currentPlayList.audioChannels == null || currentPlayList.audioChannels.Length == 0)
                return;

            for (int i = 0; i < channels.Length; i++)
            {
                if (currentPlayList.audioChannels.Length > i)
                {
                    if (currentPlayList.audioChannels[i].clipsInfo.Length > 0)
                    {
                        AudioChannelData data = new AudioChannelData();
                        data.source = audioGo.AddComponent<AudioSource>();
                        channels[i] = data;
                    }
                }
            }
        }

        /// <summary>
        /// Multiplies souce volume with master volume
        /// </summary>
        /// <param name="volume"></param>
        /// <returns></returns>
        private float ApplyMasterVolume(float volume)
        {
            return volume * (masterVolume / 100.0f) / 100.0f;
        }

        /// <summary>
        /// Sets the master volume and updates all sounds from all channels
        /// </summary>
        /// <param name="masterVolume"></param>
        public void SetMasterVolume(float masterVolume)
        {
            this.masterVolume = masterVolume;

            for (int i = 0; i < channels.Length; i++)
            {
                if(channels[i] != null)
                    channels[i].volume = ApplyMasterVolume(channels[i].volume);
            }
        }


        public void Update()
        {
            if (channels == null)
                return;
            
            for (int i = 0; i < channels.Length; i++)
            {
                if(channels[i] != null)
                    channels[i].Update();
            }
        }

        private AudioClip GetAudioClip(AudioChannelType channel, int audioIndex)
        {
            int channelId = (int)channel;
            if (currentPlayList == null || currentPlayList.audioChannels == null || channelId >= currentPlayList.audioChannels.Length
                || currentPlayList.audioChannels[channelId] == null || audioIndex >= currentPlayList.audioChannels[channelId].clipsInfo.Length)
                return null;
            return currentPlayList.audioChannels[(int)channel].clipsInfo[audioIndex];
        }

        public void PlayClip(AudioChannelType channel, AudioClip clip, bool loop, float fadeSpeed)
        {
            AudioChannelData data = GetChannelData(channel);
            if (data != null && data.source != null && clip != null)
            {
                if (!loop)
                {
                    data.source.PlayOneShot(clip, masterVolume);
                }
                else
                {
                    data.source.clip = clip;
                    data.source.Play();
                }
                data.source.loop = loop;

                if (fadeSpeed > 0)
                    data.FadeIn(0.0f, ApplyMasterVolume(data.volume), fadeSpeed);
            }
        }

        private AudioSource GetAudioSource(AudioChannelType channel)
        {
            if (channels == null || (int)channel >= channels.Length || channels[(int)channel] == null)
                return null;

            return channels[(int)channel].source;
        }


        private AudioChannelData GetChannelData(AudioChannelType channel)
        {
            if (channels == null || (int)channel >= channels.Length)
                return null;
            return channels[(int)channel];
        }

        /// <summary>
        /// Is clip playing in channel
        /// </summary>
        /// <param name="channel"></param>
        /// <returns></returns>
        public bool IsPlaying(AudioChannelType channel)
        {
            AudioSource source = GetAudioSource(channel);

            if (source != null)
                return source.isPlaying;
            return false;
        }

        /// <summary>
        /// Plays an audio clip based on channel type and index type
        /// </summary>
        /// <param name="channel"></param>
        /// <param name="audioIndex"></param>
        /// <param name="loop"></param>
        /// <param name="fadeSpeed">if 0, no fading functionality</param>
        public void Play(AudioChannelType channel, int audioIndex, bool loop, float fadeSpeed)
        {
            AudioClip clip = GetAudioClip(channel, audioIndex);
            PlayClip(channel, clip, loop, fadeSpeed);
        }

        /// <summary>
        /// Pause an Audio Source by channel type
        /// </summary>
        /// <param name="channel"></param>
        public void Pause(AudioChannelType channel)
        {
            AudioSource source = GetAudioSource(channel);
            if (source != null)
                source.Pause();
        }

        /// <summary>
        /// Resumes an audio Source by channel type
        /// </summary>
        /// <param name="channel"></param>
        public void Resume(AudioChannelType channel)
        {
            AudioSource source = GetAudioSource(channel);
            if (source != null)
                source.UnPause();
        }

        /// <summary>
        /// Stops an audio source by channel 
        /// </summary>
        public void Stop(AudioChannelType channel)
        {
            AudioSource source = GetAudioSource(channel);
            if (source != null)
                source.Stop();
        }

        /// <summary>
        /// Set volume of particular channel
        /// </summary>
        /// <param name="channel"></param>
        public void SetVolume(AudioChannelType channel, float volume)
        {
            AudioChannelData data = GetChannelData(channel);
            if (data != null && data.source != null)
            {
                data.volume = volume;
                data.source.volume = volume;
            }
        }

        /// <summary>
        /// Returns the volume of particular channel
        /// </summary>
        /// <param name="channel"></param>
        /// <returns></returns>
        public float GetVolume(AudioChannelType channel)
        {
            AudioChannelData data = GetChannelData(channel);
            if (data != null)
                return data.volume;
            return 0.0f;
        }

        /// <summary>
        /// Returns current Master volume
        /// </summary>
        /// <returns></returns>
        public float GetMasterVolume()
        {
            return masterVolume;
        }

        /// <summary>
        /// Pauses all audio clips in all channels
        /// </summary>
        public void PauseAll()
        {
            for (int i = 0; i < channels.Length; i++)
            {
                if (channels[i] != null)
                    channels[i].source.Pause();
            }
        }

        /// <summary>
        /// Resumes all audio clips in all channels
        /// </summary>
        public void ResumeAll()
        {
            for (int i = 0; i < channels.Length; i++)
            {
                if (channels[i] != null)
                    channels[i].source.UnPause();
            }
        }


        public void SetTimer(AudioChannelType channelType, float time)
        {
            var channelData = GetChannelData(channelType);
            if(channelData != null)
            {
                channelData.source.time = time;
            }
        }


        public float GetTimer(AudioChannelType channelType)
        {
            var channelData = GetChannelData(channelType);
            if (channelData != null)
            {
                return channelData.source.time;
            }
            return 0;
        }

        /// <summary>
        /// Stop playing all audio clips  in all channels
        /// </summary>
        public void StopAll()
        {
            for (int i = 0; i < channels.Length; i++)
            {
                if (channels[i] != null)
                    channels[i].source.Stop();
            }
        }
    }
}
