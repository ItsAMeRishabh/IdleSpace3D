﻿
using UnityEngine;
using GS.Audio;
using GS.Data;
using System;

namespace GS
{
    /// <summary>
    /// Listens all audio related events and interacts with Audio System
    /// </summary>
    public class AudioController : IController
    {
        /// <summary>
        /// Audio System instance
        /// </summary>
        protected IAudioSystem audioSystem;

        /// <summary>
        /// Initializes Audio Controllers
        /// </summary>
        public virtual void Initialize()
        {

        }

        /// <summary>
        /// Loads a play list from specified path 
        /// Creates gameobject for Audio System and adds all required components
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        protected void LoadPlayList(string bundleKey, string path, Action<bool> callback)
        {
            AudioPlayList list = null;
            Utils.EventSync(new LoadScriptableObjectEvent(bundleKey, path, (playList) =>
            {
                list = playList as AudioPlayList;
              if (list == null)
              {
                Log.Print("Unable to find Play List : " + path);
                callback?.Invoke(false);
return;
              }
              AudioSystem sys = new AudioSystem();
              sys.Initialize();
              sys.SetPlayList(list);
              audioSystem = sys;
              callback?.Invoke(true);
            }));

           
        }

        /// <summary>
        /// Stops all channels 
        /// </summary>
        public virtual void Release()
        {
            if (audioSystem != null)
                audioSystem.StopAll();
        }

        public virtual void RegisterListener()
        {

        }

        public virtual void UnRegisterListener()
        {
        }

        public void Update()
        {

        }
    }
}
