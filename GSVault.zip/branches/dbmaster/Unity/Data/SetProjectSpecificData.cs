﻿using Game.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
  namespace Data
  {
    /// <summary>
    /// Any data that is specific to project can be passed and stored here
    /// </summary>
    public class SetProjectSpecificData : GameEvent
    {
      public ProjectSpecificData projectSpecificData;

      public SetProjectSpecificData(ProjectSpecificData projectSpecificData)
      {
        this.projectSpecificData = projectSpecificData;
      }
    }

    public class GetProjectSpecificData : GameEvent
    {
      public Action<ProjectSpecificData> projectSpecificData;

      public GetProjectSpecificData(Action<ProjectSpecificData> projectSpecificData)
      {
        this.projectSpecificData = projectSpecificData;
      }
    }
  }
}
