﻿using GS;
using GS.GameEvents;
using System;
using System.Collections.Generic;

namespace GS.Data
{

    /// <summary>
    /// Base class for controller classes in DataLayer
    /// </summary>
    public class DataController : IController
    {
        /// <summary>
        /// Do not use it directly. Use 'AddIDataController', 'RemoveIDataController'
        /// Maintains list of DataContainers.
        /// </summary>
        private List<IDataContainer> dataContainers;

        

        /// <summary>
        /// Add all types data controllers here. 
        /// </summary>
        public virtual void Initialize()
        {
            RegisterListener();

            addIDataController(ContentManager.Instance.Load<AssetDataController>(this));
        }


        /// <summary>
        /// Returns 'IDataContainer' of type 'T' if added already to list of dataContainers.
        /// Returns null, if not added
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public virtual T GetIDataContainers<T>() where T : IDataContainer
        {
            // Searche entire list for given type 'T'
            for (int i = 0; i < dataContainers.Count; i++)
            {
                if (dataContainers[i].GetType() == typeof(T))
                {
                    // Return type of 'T'
                    return (T)dataContainers[i];
                }
            }

            // As given type 'T' is not found, return null.
            Log.Print("GameDataController - DataContainer, " + typeof(T) + " is not avilable. Returning null !!", LogFilter.Data);
            return null;
        }


        protected virtual void addIDataController(IDataContainer dContner)
        {
            if (dataContainers == null)
                dataContainers = new List<IDataContainer>();

            if (dataContainers.Contains(dContner))
            {
                Log.Print("DataContainer, " + dContner + " already added !!", LogFilter.Data);
                return;
            }

            // Add Container to list
            dataContainers.Add(dContner);

            // Call Register Listners on container as we are adding it for first time.
            dContner.RegisterListners();
        }


        protected virtual void removeIDataController(IDataContainer dContner)
        {
            if (!dataContainers.Contains(dContner))
            {
                Log.Print("DataController - DataContainer, " + dContner + " is not present to remove !!", LogFilter.Data);
                return;
            }

            // Remove Container to list
            dataContainers.Remove(dContner);

            // Call DeRegister Listners on container as we are removing it
            dContner.DeRegisterListners();
        }

        

        public void RegisterListener()
        {
            Utils.EM.AddListener<AddDataConainerEvent>(OnAddDataControllerListener);
            Utils.EM.AddListener<RemoveDataConainerEvent>(OnRemoveDataControllerListener);
            if (dataContainers == null)
                return;

            for (int i = 0; i < dataContainers.Count; i++)
            {
                dataContainers[i].RegisterListners();
            }
        }

        public virtual void Release()
        {
            UnRegisterListener();

           
        }

        public void UnRegisterListener()
        {
            Utils.EM.RemoveListener<AddDataConainerEvent>(OnAddDataControllerListener);
            Utils.EM.RemoveListener<RemoveDataConainerEvent>(OnRemoveDataControllerListener);

            if (dataContainers == null)
                return;
            for (int i = 0; i < dataContainers.Count; i++)
            {
                dataContainers[i].DeRegisterListners();
            }
        }

        private void OnRemoveDataControllerListener(RemoveDataConainerEvent dataContainerEvent)
        {
            if (dataContainerEvent == null || dataContainerEvent.container == null)
                return;

            removeIDataController(dataContainerEvent.container);
        }

        private void OnAddDataControllerListener(AddDataConainerEvent dataContainerEvent)
        {
            if (dataContainerEvent == null || dataContainerEvent.container == null)
                return;

            addIDataController(dataContainerEvent.container);
        }

        public virtual void Update()
        {
        }


    }
}