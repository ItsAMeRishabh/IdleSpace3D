﻿using GS.Data.DataConsts;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Data
{
    /// <summary>
    /// Holds data of 'AssetBundle config file'
    /// </summary>
    public class AssetBundleConfigFileManager
    {
        /// <summary>
        /// Player Pref key to save downloaded 'AssetBundleConfig' file
        /// </summary>
        private string prefKey = "";

        /// <summary>
        /// Holds all bundles(Grouped/Individual) with custom class(object)
        /// </summary>
        private Dictionary<string, AssetBundleConfigData> bundlesDictionary;

        // --------------  These variables are for holding Grouped bundles   --------------
        private bool isInGroupNode = false;
        private string currentGroupNodeName;
        /// <summary>
        /// Holds Grouped bundles name as a List
        /// </summary>
        private Dictionary<string, List<string>> bundlesGroupwiseDict;


        // --------------  Download details   --------------
        private string fileName;
        private string rootPath;
        private float timeOutSeconds;
        private Action<bool, string[]> downloadStatusCallBack;

        // Getting Instance of this class.
        private static AssetBundleConfigFileManager _configFileManager = null;
        public static AssetBundleConfigFileManager Instance
        {
            get
            {
                if (_configFileManager == null)
                {
                    _configFileManager = new AssetBundleConfigFileManager();

                    _configFileManager.prefKey = ConfigFileKeys.offlineConfigFileKey;
                    // These can be reset, if we want read config data again (eg: in middle of game).
                    _configFileManager.bundlesDictionary = new Dictionary<string, AssetBundleConfigData>();
                    _configFileManager.bundlesGroupwiseDict = new Dictionary<string, List<string>>();
                }

                return _configFileManager;
            }
        }

        public void Reset()
        {
            _configFileManager = null;
        }


        /// <summary>
        /// Returns file(url) data of key. If not found returns null.
        /// </summary>
        /// <param name="bundleKey"></param>
        /// <returns></returns>
        public AssetBundleConfigData? GetBundleData(string bundleKey)
        {
            if (bundlesDictionary != null && bundlesDictionary.ContainsKey(bundleKey))
            {
                return bundlesDictionary[bundleKey];
            }

            return null;
        }

        /// <summary>
        /// Returns true, if config file data loaded
        /// </summary>
        public bool IsConfigFileLoaded() // { private set; get; }
        {
            return !string.IsNullOrEmpty(GetSavedConfigData());
        }

        /// <summary>
        /// Downloads config file from specifed url
        /// </summary>
        /// <param name="url">File location</param>
        public void DownloadConfigFile(string rootPath, string fileName, float timeOutSeconds = 10.0f, Action<bool, string[]> statusCallBack = null)
        {
            this.rootPath = rootPath;
            this.fileName = fileName;
            this.timeOutSeconds = timeOutSeconds;
            downloadStatusCallBack = statusCallBack;

            MonobehaviourHelper.Instance.StartCoroutine(FetchFile());
        }

        /// <summary>
        /// Fetches file by WWW call
        /// </summary>
        /// <returns></returns>
        private IEnumerator FetchFile()
        {
            if (String.IsNullOrEmpty(fileName) || String.IsNullOrEmpty(rootPath))
            {
                //Debug.Log("ConfigFileManager : File URL is empty !!");
                RiseDownloadCallback(false, "ConfigFileManager : File URL is empty !!");
                yield return null;
            }


            WWW file = new WWW(rootPath + "/" + fileName);
            float elapsedTime = 0.0f;

            while (!file.isDone)
            {
                elapsedTime += Time.deltaTime;
                if (elapsedTime > timeOutSeconds)
                {
                    //Debug.Log("ConfigFileManager : FectingFile Timeout!");

                    RiseDownloadCallback(false, "ConfigFileManager : FectingFile Timeout!");

                    break;
                }
                yield return null;
            }

            yield return file;

            if (!string.IsNullOrEmpty(file.error))
            {
                //Debug.Log("ConfigFileManager : Failed to get file. Error, " + file.error);
                RiseDownloadCallback(false, "ConfigFileManager : Failed to get file. Error, " + file.error);
            }
            else if (string.IsNullOrEmpty(file.text))
            {
                //Debug.Log("ConfigFileManager : File is Empty !! ");
                RiseDownloadCallback(true, "ConfigFileManager : File is Empty !! ");
            }
            else
            {
                //Debug.Log("ConfigFileManager : File Download successfull");

                // Save File data locally
                SaveRawConfigData(file.text);

                ConvertRawDataToObject(file.text);

                // Makesure this invoking callback line in last of this block.
                RiseDownloadCallback(true, "ConfigFileManager : File Download successfull");
            }
        }

        /// <summary>
        /// Invokes download status callback of config file
        /// </summary>
        /// <param name="status"></param>
        private void RiseDownloadCallback(bool status, params string[] addtionalComnts)
        {
            if (downloadStatusCallBack != null)
                downloadStatusCallBack(status, addtionalComnts);

            downloadStatusCallBack = null;
        }

        /// <summary>
        /// In offline we can get data from here
        /// </summary>
        /// <param name="data"></param>
        private void SaveRawConfigData(string data)
        {
            PlayerPrefs.SetString(prefKey, data);
        }

        /// <summary>
        /// Returns raw data that saved locally. Can be used if user plays in offline.
        /// </summary>
        /// <returns></returns>
        private string GetSavedConfigData()
        {
            return PlayerPrefs.GetString(prefKey, string.Empty);
        }

        /// <summary>
        /// Loads last saved config file from preferences.
        /// Use this if, ping to get config file fails.
        /// </summary>
        ///<param name="callBack">Invokes when loading done</param>
        public void LoadOfflineConfigData(Action<bool, string[]> callBack)
        {
            downloadStatusCallBack = callBack;
            string savedConfigFile = GetSavedConfigData();

            bool isOfflineFileAvailable = IsConfigFileLoaded();
            string errorMsg;

            if (isOfflineFileAvailable)
            {
                isOfflineFileAvailable = true;
                ConvertRawDataToObject(savedConfigFile);
                errorMsg = null;
            }
            else
            {
                errorMsg = "Offline Config file is not Available or Empty";

            }

            RiseDownloadCallback(isOfflineFileAvailable, errorMsg);
        }

        /// <summary>
        /// Converts Raw JSON data in to Dictionary(key,value pairs)
        /// </summary>
        /// <param name="rawData">Data in string format</param>
        private void ConvertRawDataToObject(string rawData)
        {
            Dictionary<string, System.Object> configDataDict = Utils.ConvertStringToJsonNode(rawData);

            ReadSingleObject(configDataDict);

            /*
            foreach (KeyValuePair<string, string> bundle in configDataDict)
            {
                AssetBundleConfigData assetBundleConfigData = new AssetBundleConfigData();
                assetBundleConfigData.bundleKey = bundle.Key;

                // Get key value(s) here
                Dictionary<string, string> bundleDict = Utils.ConvertStringToJsonNode(bundle.Value);

                // Assigning key values
                assetBundleConfigData.url = bundleDict["link"];
                assetBundleConfigData.version = int.Parse(bundleDict["version"]);

                bundlesDictionary.Add(assetBundleConfigData.bundleKey, assetBundleConfigData);
            }
            */

        }

        /// <summary>
        /// Converts bundle info into custom(Our) class Object
        /// </summary>
        /// <param name="configDataDict"></param>
        private void ReadSingleObject(Dictionary<string, System.Object> configDataDict)
        {
            if (configDataDict == null)
            {
                Log.Print("ConfigFileManager - Reading Null Dict, so returning", LogFilter.GameEvent);
                return;
            }

            foreach (KeyValuePair<string, System.Object> bundle in configDataDict)
            {
                //string currentGroupNodeName = string.Empty;

                // Check if we are in group node
                if (bundle.Key.Contains(ConfigFileKeys.GroupNodeSuffix))
                {
                    // Removing suffix as we dont want code to know about this suffix
                    // eg: "BeforeMainMenuGroupNode" ==> "BeforeMainMenu" key
                    string groupNodeKey = bundle.Key.Replace(ConfigFileKeys.GroupNodeSuffix, "");

                    isInGroupNode = true;
                    currentGroupNodeName = groupNodeKey;

                    // Add GroupNode Key here to dictionary
                    if (!bundlesGroupwiseDict.ContainsKey(currentGroupNodeName))
                    {
                        bundlesGroupwiseDict.Add(currentGroupNodeName, new List<string>());
                    }

                    // Basically, implementing 'Recursive' method by passing this Key's(GroupNode) Value(text)
                    //ConvertRawDataToObject(bundle.Value);
                    ReadSingleObject(bundle.Value as Dictionary<string, System.Object>);
                    //ParseDictList(bundle.Value);

                    // Reset these variables as we are moving out of GroupNode
                    isInGroupNode = false;
                    currentGroupNodeName = null;

                    // As we are in GroupNode, child keys(objects) are added already in recursive method above.
                    continue;
                }

                // Initilize config data of an key to Object
                AssetBundleConfigData assetBundleConfigData = new AssetBundleConfigData();
                assetBundleConfigData.bundleKey = bundle.Key;

                // Get key value(s) here
                Dictionary<string, System.Object> bundleDict = bundle.Value as Dictionary<string, System.Object>; // Utils.ConvertStringToJsonNode(bundle.Value);

                // Assigning key values
                assetBundleConfigData.url = bundleDict[ConfigFileKeys.BundleLink].ToString();
                assetBundleConfigData.version = int.Parse(bundleDict[ConfigFileKeys.BundleVersion].ToString());

                // Add bundle key to asset bundle Dictionary
                bundlesDictionary.Add(assetBundleConfigData.bundleKey, assetBundleConfigData);

                // Check we are inside Grouped Node
                if (isInGroupNode)
                {
                    // Add bundle key to List present inside collective Dictionary based on GroupNode(s)
                    bundlesGroupwiseDict[currentGroupNodeName].Add(bundle.Key);
                }
            }
        }

        /* Testing 'Recursive' method
        private void ParseDictList(System.Object obj)
        {
            // Testing variables
            //List<Dictionary<string, System.Object>> list = new List<Dictionary<string, object>>();
            //list.Add(new Dictionary<string, object>());
            //list.Add(new Dictionary<string, object>());

            //Dictionary<string, System.Object>[] dictionary = new Dictionary<string, object>[2];

            // Worked
            //Dictionary<string, Dictionary<string, System.Object>[]> asd = new Dictionary<string, Dictionary<string, object>[]>(2);
            //asd.Add("1",new Dictionary<string, object>[1]);
            //asd.Add("2",new Dictionary<string, object>[1]);

            var v = obj;
            Debug.Log("typeof(v)");

            Dictionary<string, System.Object> templist = obj as Dictionary<string, System.Object>;
            ////templist.Add("1",new System.Object());
            ////templist.Add("2", new System.Object());

            ////Dictionary<string, Dictionary<string, System.Object>[]> list = obj as Dictionary<string, Dictionary<string, System.Object>[]>;
            //foreach(KeyValuePair<string, System.Object> kp in templist)
            //{
            //    ReadSingleObject(kp as Dictionary<string, System.Object>); // kp.Value as Dictionary<string, System.Object>);
            //}

            ReadSingleObject(templist);
        }
        */

        /// <summary>
        /// Returns List of Bundle Names(keys in Data file) from grouped block
        /// </summary>
        /// <param name="groupName"></param>
        /// <returns></returns>
        public List<string> GetBundleNamesInGroup(string groupName)
        {
            if (!IsConfigFileLoaded())
            {
                Log.Error("ConfigFileManager - Config file is not loaded yet !");
                return null;
            }

            if (bundlesGroupwiseDict == null || !bundlesGroupwiseDict.ContainsKey(groupName))
            {
                Log.Error("ConfigFileManager - Either Grouped Bundles Dict is Null (or) Key not found !!. Key : " + groupName);
                return null;
            }


            return bundlesGroupwiseDict[groupName];
        }

        /// <summary>
        /// Returns all Bundle Names in a array
        /// </summary>
        /// <returns></returns>
        public String[] GetAllBundlesNames()
        {
            string[] keys = new string[bundlesDictionary.Keys.Count];
            bundlesDictionary.Keys.CopyTo(keys, 0);

            return keys;
        }

    }
}