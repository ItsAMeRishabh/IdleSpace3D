﻿namespace GS.Data.Encryption
{
    public interface IEncryptionSystem
    {
        string Encrypt(string data);
        bool Decrypt(ref string data);
    }
}
