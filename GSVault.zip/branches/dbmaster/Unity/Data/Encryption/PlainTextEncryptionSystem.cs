﻿using System;

namespace GS.Data.Encryption
{
    public class PlainTextEncryptionSystem : IEncryptionSystem
    {
        public bool Decrypt(ref string data)
        {
            return true;
        }

        public string Encrypt(string data)
        {
            return data;
        }
    }
}
