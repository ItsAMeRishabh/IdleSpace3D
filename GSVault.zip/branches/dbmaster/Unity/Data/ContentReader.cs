﻿using Game.Data;
using Game.Event;
using GS.GameConsts;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if USE_ADDRESSABLES
using UnityEngine.AddressableAssets;
#endif

namespace GS.Data
{
    /// <summary>
    /// Common class for content reading.
    /// Currently capable of setting file based on GraphicType and
    /// reading contents from,
    /// 1. Resources folder
    /// 2. AssetBundles
    /// </summary>
    public class ContentReader
    {
        /// <summary>
        /// Returns asset from Resources folder of type T. Use this in DataLayer only
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="relativePathWithName"></param>
        /// <returns></returns>
        public static void LoadAssetType<T>(string relativePathWithName, System.Action<T> action)
            where T : UnityEngine.Object
        {
            if (relativePathWithName == null)
            {
                action?.Invoke(null);
                return;
            }
            string fileName = System.IO.Path.GetFileName(relativePathWithName);

            string updatedRelativePath = relativePathWithName.Replace(
                fileName,
                GetNameBasedOnGraphicType<T>(fileName, null)
            );

            //// Passing relativeFileName here
            //relativePathWithName = GetFileNameBasedOnGraphicType<T>(relativePathWithName, null);

            T assetFile = null;
            assetFile = Resources.Load<T>(updatedRelativePath);

            if (assetFile != null)
            {
                action?.Invoke(assetFile);
                return;
            }

            action?.Invoke(Resources.Load<T>(relativePathWithName));
            //return null;
        }

        /// <summary>
        /// Returns Sprite in SpriteSheet from Resources folder of type T. Use this in DataLayer only
        /// </summary>
        /// <param name="relativePathWithSheetName"></param>
        /// <param name="spriteName"></param>
        /// <returns></returns>
        static Sprite LoadAssetTypeSpriteSheet(string relativePathWithSheetName, string spriteName)
        {
            if (relativePathWithSheetName == null)
                return null;

            string fileName = System.IO.Path.GetFileName(relativePathWithSheetName);

            string updatedRelativePath = relativePathWithSheetName.Replace(
                fileName,
                GetNameBasedOnGraphicType<Sprite>(fileName, null)
            );

            //// Passing relativeFileName here
            //relativePathWithSheetName = GetFileNameBasedOnGraphicType<Sprite>(relativePathWithSheetName, null);

            Sprite[] spriteSheet = null;
            //Sprite assetFile = null;
            spriteSheet = Resources.LoadAll<Sprite>(updatedRelativePath);

            if (spriteSheet == null || spriteSheet.Length == 0)
                spriteSheet = Resources.LoadAll<Sprite>(relativePathWithSheetName);

            if (spriteSheet == null)
            {
                Log.Print(
                    "ContentReader - LoadAssetTypeSpriteSheetLocal, SpriteSheet is not found with name "
                        + relativePathWithSheetName
                        + ". So returning null",
                    LogFilter.Error
                );
                return null;
            }
            else
            {
                foreach (Sprite subSprite in spriteSheet)
                {
                    if (subSprite.name.Equals(spriteName))
                    {
                        return subSprite;
                    }
                }

                Log.Print(
                    "ContentReader - LoadAssetTypeSpriteSheetLocal, Image not found for, "
                        + spriteName
                        + ", not found in spriteSheet : "
                        + relativePathWithSheetName,
                    LogFilter.Error
                );
            }

            return null;
        }

        public static void LoadBundle(
            string assetBundleKey,
            Action<AssetBundle> action,
            IProgress<float> progress
        )
        {
            string bundleName = GetNameBasedOnGraphicType<AssetBundle>(assetBundleKey, null);
            bundleName = bundleName.ToLower();
            Utils.EventSync(
                new IsBundlePresent(
                    bundleName,
                    (isBundlePresent) =>
                    {
                        if (isBundlePresent)
                        {
                            GS.EventManager.Instance.TriggerEvent(
                                new LoadAssetBundleSignal(
                                    bundleName,
                                    (value) =>
                                    {
                                        action?.Invoke(value);
                                    },
                                    progress
                                )
                            );
                        }
                        else
                        {
                            GS.EventManager.Instance.TriggerEvent(
                                new LoadAssetBundleSignal(
                                    assetBundleKey,
                                    (value) =>
                                    {
                                        action?.Invoke(value);
                                    },
                                    progress
                                )
                            );
                        }
                    }
                )
            );
        }

        /// <summary>
        /// Returns asset from Assetbundle related to key passed.
        /// If asset bundle is not found, returns asset from Resources folder based on 'relativePathWithName'
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="relativePathWithName">File name (with/with out) relative path</param>
        /// <param name="assetBundleKey">Key in config file</param>
        /// <returns></returns>
        public static void LoadAssetType<T>(
            string relativePathWithName,
            string assetBundleKey,
            System.Action<T> action
        )
            where T : UnityEngine.Object
        {
            #region new code
#if USE_ADDRESSABLES
            AddressableHandler.LoadAsset<T>(relativePathWithName, action);
#elif USE_ASSETBUNDLES
            string filePath = System.IO.Path.GetFileName(relativePathWithName);
            string bundleName = GetNameBasedOnGraphicType<T>(assetBundleKey, null);
            Utils.EventAsync(
                new IsBundlePresent(
                    bundleName,
                    (isBundlePresent) =>
                    {
                        if (isBundlePresent)
                        {
                            GS.EventManager.Instance.TriggerEvent(
                                new LoadAssetBundleSignal(
                                    bundleName,
                                    (value) =>
                                    {
                                        string newFilePath = GetNameBasedOnGraphicType<T>(
                                            filePath,
                                            value
                                        );
                                        if (newFilePath.Equals(filePath))
                                        {
                                            //Log.Error(bundleName + " Assetbundle does not have Updated file Name for file " + filePath);
                                        }
                                        else
                                        {
                                            assetBundleKey = bundleName;
                                            filePath = newFilePath;
                                        }

                                        LoadBundleFile(
                                            relativePathWithName,
                                            assetBundleKey,
                                            action,
                                            filePath
                                        );
                                    }
                                )
                            );
                        }
                        else
                        {
                            LoadBundleFile(relativePathWithName, assetBundleKey, action, filePath);
                        }
                    }
                )
            );
#else
            LoadAssetType<T>(relativePathWithName, action);
#endif
            #endregion
            #region oldCode
            //AssetBundle assetBundle = AssetBundleManager.GetAssetBundle(assetBundleKey);
            //      if (assetBundle == null)
            //      {

            //          return LoadAssetType<T>(relativePathWithName);
            //      }

            //      if (string.IsNullOrEmpty(relativePathWithName))
            //      {
            //          Debug.Log("ContentReader - RelativeFilePath is NULL/Empty");
            //          return null;
            //      }

            //      // TODO: Try to avoid using 'System.IO' library
            //      // As i we are getting asset from AssetBundle, we need only 'fileName' instead of 'relativePathWithName'
            //      string fileName = System.IO.Path.GetFileName(relativePathWithName);
            //      //Debug.Log(relativePathWithName);  // need to find last index of '\'
            //      //Debug.Log(fileName);


            //      // Checking GameGraphics Type
            //      fileName = GetFileNameBasedOnGraphicType<T>(fileName, assetBundle);

            //      return assetBundle.LoadAsset<T>(fileName);
            #endregion
        }

        private static void LoadBundleFile<T>(
            string relativePathWithName,
            string assetBundleKey,
            Action<T> action,
            string filePath
        )
            where T : UnityEngine.Object
        {
            GS.EventManager.Instance.TriggerEvent(
                new LoadAssetBundleSignal(
                    assetBundleKey,
                    (value) =>
                    {
                        if (value == null)
                        {
                            LoadAssetType<T>(relativePathWithName, action);
                        }
                        else
                        {
                            var loadedValue = value.LoadAsset<T>(filePath);
                            if (loadedValue != null)
                            {
                                action?.Invoke(loadedValue);
                            }
                            else
                                LoadAssetType<T>(relativePathWithName, action);
                        }
                    }
                )
            );
        }

        /// <summary>
        /// Returns Sprite in SpriteSheet from Assetbundle related to key passed.
        /// If asset bundle is not found, returns Sprite in SpriteSheet from Resources folder based on 'relativePathWithSheetName' and 'spriteName'
        /// </summary>
        /// <param name="relativePathWithSheetName"></param>
        /// <param name="spriteName"></param>
        /// <param name="assetBundleKey"></param>
        /// <returns></returns>
        public static Sprite LoadAssetTypeSpriteSheet(
            string relativePathWithSheetName,
            string spriteName,
            string assetBundleKey
        )
        {
            AssetBundle assetBundle = AssetBundleManager.GetAssetBundle(assetBundleKey);
            if (assetBundle == null)
            {
                Log.Print(
                    "ContentReader - AssetBundle, " + assetBundleKey + ". is not found!!",
                    LogFilter.Error
                );
                Log.Print("ContentReader - Reading from resources folder !!", LogFilter.GameEvent);
                return LoadAssetTypeSpriteSheet(relativePathWithSheetName, spriteName);
            }

            if (string.IsNullOrEmpty(relativePathWithSheetName))
            {
                Log.Print(
                    "ContentReader - RelativeFilePath os SpriteSheet is NULL/Empty",
                    LogFilter.Error
                );
                return null;
            }

            // TODO: Try to avoid using 'System.IO' library
            // As i we are getting asset from AssetBundle, we need only 'fileName' instead of 'relativePathWithName'
            string sheetName = System.IO.Path.GetFileName(relativePathWithSheetName);

            // Checking GameGraphics Type
            sheetName = GetNameBasedOnGraphicType<Sprite>(sheetName, assetBundle);

            Sprite[] spriteSheet = assetBundle.LoadAssetWithSubAssets<Sprite>(sheetName);
            if (spriteSheet == null || spriteSheet.Length == 0)
            {
                Log.Print(
                    "ContentReader - LoadAssetTypeSpriteSheet, SpriteSheet is not found with name "
                        + sheetName
                        + ". So returning null",
                    LogFilter.Error
                );
                Log.Print(
                    "ContentReader - spriteSheet.Length : " + spriteSheet.Length,
                    LogFilter.GameEvent
                );
                return null;
            }
            else
            {
                foreach (Sprite subSprite in spriteSheet)
                {
                    if (subSprite.name.Equals(spriteName))
                    {
                        return subSprite;
                    }
                }

                Log.Print(
                    "ContentReader - LoadAssetTypeSpriteSheet, Image not found for, "
                        + spriteName
                        + ", not found in spriteSheet : "
                        + sheetName,
                    LogFilter.Error
                );
            }

            return null;
        }

        /// <summary>
        /// Returns fileName by performing,
        /// 1. Add's suffix to file name based on GraphicType
        /// 2. If file not found then, reverts fileName by removing suffix
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="assetBundle"></param>
        /// <returns></returns>
        static string GetNameBasedOnGraphicType<T>(string fileName, AssetBundle assetBundle)
            where T : UnityEngine.Object
        {
            // --------------- Assign fileName suffix basedOn graphicType
            if (ContentManager.Instance.GetProjectSpecificData().assetsBasedOnGraphicType)
            {
                if (ContentManager.Instance.GetGameGraphicType() == GameGraphicsType.HD)
                {
                    string graphicTypeSuffix = ContentManager.Instance
                        .GetProjectSpecificData()
                        .graphicTypeSuffix;

                    fileName += graphicTypeSuffix;

                    if (assetBundle != null)
                    {
                        // Now check file exists in assetBundle/not.
                        if (!assetBundle.Contains(fileName))
                            // As file not exists in assetBundle, remove suffix. It means either common file across different GraphicTypes
                            fileName = fileName.Replace(graphicTypeSuffix, "");
                    }
                    else
                    {
                        // Remove suffix if file not found in Resoources folder
                        //if(Resources.Load<T>(fileName) == null)
                        //    fileName = fileName.Replace(graphicTypeSuffix, "");
                    }
                }
            }

            return fileName;
        }

        //void LoadImage(string path)
        //{
        //    Sprite sprite = Resourcess.Load<Sprite>("");
        //    if (sprite == null)
        //        Debug.Log("Sprite is null");
        //    else
        //        Debug.Log("Sprite is NOT null");

        //    AssetBundle _assetBundle;

        //    _assetBundle.LoadAsset<Sprite>("");
        //}
    }
}
