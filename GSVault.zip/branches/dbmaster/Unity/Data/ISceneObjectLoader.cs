﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Data
{
    public interface ISceneObjectLoader 
    {
        /// <summary>
        /// Initialze the Gamemode
        /// </summary>
        void Initialize();

        /// <summary>
        /// To load game mode specific objects in couroutine
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        bool OnLoading(int index);

        /// <summary>
        /// Returns the max number of divisions rerquired to load the game mode
        /// </summary>
        /// <returns></returns>
        int GetLoadingMaxIndex();
    }
}
