﻿using System;
using UnityEngine;

namespace GS.Data
{
    public abstract class IDataContainer
    {
        //protected string assetBundleKey;
        protected int assetBundleVersion;

        public abstract string AssetBundleKey { get; } //protected set; }

        //public abstract int AssetBundleVersion { get; protected set; }

        /// <summary>
        /// Reads content from asset bundle
        /// </summary>
        /// <param name="assetBundle"></param>
        public abstract void ReadAssetBundle(AssetBundle assetBundle);

        /// <summary>
        /// Reads content from asset bundle
        /// </summary>
        /// <param name="assetBundle"></param>
        public abstract void ReadLocal();

    /// <summary>
    /// Loads 'T' type from resources folder
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="path"></param>
    /// <returns></returns>
    protected void LoadLocalContent<T>(string path,Action<T> action) where T : UnityEngine.Object
    {
      ContentReader.LoadAssetType<T>(path, action);
    }

    protected DataController Controller;

        public abstract void RegisterListners();

        public abstract void DeRegisterListners();

        public IDataContainer(DataController dataController)
        {
            Controller = dataController;
        }
    }
}