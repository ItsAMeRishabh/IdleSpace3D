﻿
namespace GS.Data.DataConsts
{
    /// <summary>
    /// Holds AssetBundle keys(which are in configFile) of particular 'Asset'
    /// </summary>
    public class AssetDataBundleKeys
    {
        /// <summary>
        /// Asset bundle key that holds 'GameContent'
        /// </summary>
        public const string GameContentKey = "GameContent";

        /// <summary>
        /// Asset bundle key that holds 'all UIPrefabs'
        /// Making all scenes UI prefabs into single asset bundle to reduce size(file size).
        /// If we have multiple then, each bundle will inculde shared assets into which will occupy lot of size.
        /// </summary>
        public const string UIPrefabs = "uiprefabs";

        /// <summary>
        /// Asset bundle key that holds 'CommonResources' which are shared between different assetBundles
        /// </summary>
        public const string CommonResources = "CommonResources";

        /// <summary>
        /// Asset bundle key that holds 'StoreData' like LiveChallenges,CommingSoon etc.,
        /// </summary>
        public const string StoreData = "StoreData";

        /// <summary>
        /// Asset bundle key that holds 'Stadiums' related info
        /// </summary>
        public const string StadiumsData = "StadiumData";

        /// <summary>
        /// Asset bundle key that holds 'Player' related like Models, Textures, Animators etc.,
        /// </summary>
        public const string Actors = "Player";

        /// <summary>
        /// Animator Game States
        /// </summary>
        public const string States = "States";

        public const string AudioFiles = "Audio";
    }

    /// <summary>
    /// Config file's (JSON/XML) keys
    /// </summary>
    public class ConfigFileKeys
    {

        /// <summary>
        /// Player Pref key to save downloaded 'AssetBundleConfig' file
        /// </summary>
        public const string offlineConfigFileKey = "AssetBundleConfigFileRawData";

        public const string BundleLink = "link";
        public const string BundleVersion = "version";

        public const string GroupNodeSuffix = "GroupNode";

        /// <summary>
        /// Group of bundles needed to be downloaded before MainMenu
        /// </summary>
        public const string BeforeMainMenu = "BeforeMainMenu";

        /// <summary>
        /// Bundles group must for enterning into Ingame scene
        /// </summary>
        public const string BeforeInGame = "BeforeInGame";
    }

    public class ErrorMessages
    {
        public const string ErrorDownloadingBundle = "ErrorDownloading";
    }
}