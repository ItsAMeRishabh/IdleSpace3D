﻿using GS;
using System;

namespace Game.Event
{
  public class InitializeAssetBundleSignal : GameEvent
  {
    public readonly string baseURL;
    public readonly Action<bool> onCompleteLoading;
        public readonly bool useLocalIfAvailable;
    public InitializeAssetBundleSignal(string baseURL, Action<bool> onCompleteLoading)
    {
      this.baseURL = baseURL;
      this.onCompleteLoading = onCompleteLoading;
    }

		public InitializeAssetBundleSignal(string baseURL, bool useLocalIfAvailable, Action<bool> onCompleteLoading)
		{
			this.baseURL = baseURL;
			this.onCompleteLoading = onCompleteLoading;
			this.useLocalIfAvailable = useLocalIfAvailable;
		}
	}
}
