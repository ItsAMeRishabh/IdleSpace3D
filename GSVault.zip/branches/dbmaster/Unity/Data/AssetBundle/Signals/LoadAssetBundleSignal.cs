﻿using GS;
using System;
using UnityEngine;

namespace Game.Event
{
    public class LoadAssetBundleSignal : GameEvent
    {
        public readonly string name;
        public readonly IProgress<float> progress;
        public readonly Action<AssetBundle> handler;
        public LoadAssetBundleSignal(string name, Action<AssetBundle> handler, IProgress<float> progress = null)
        {
            this.name = name;
            this.handler = handler;
            this.progress = progress;
        }
    }
}
