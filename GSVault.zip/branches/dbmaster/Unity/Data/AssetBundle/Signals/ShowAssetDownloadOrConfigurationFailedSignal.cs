﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowAssetDownloadOrConfigurationFailedSignal : GS.GameEvent
{
  public Action onButtonClick;
  public string popUpMessage;
  public string popUpTitle;
  public ShowAssetDownloadOrConfigurationFailedSignal(Action onButtonClick, string popupTitle, string popupMessage)
  {
    this.onButtonClick = onButtonClick;
    this.popUpMessage = popupMessage;
    this.popUpTitle = popupTitle;
  }
    public ShowAssetDownloadOrConfigurationFailedSignal(Action onButtonClick)
    {
        this.onButtonClick = onButtonClick;
        this.popUpMessage = "Please check your internet connection and try again..";
        this.popUpTitle = "Failed to load the bundle";
    }
}
