﻿namespace Game.Event
{
  public class LoadAssetComponentSignal : GS.GameEvent
  {
    public readonly string path;

    public LoadAssetComponentSignal(string path)
    {
      this.path = path;
    }
  }
}
