﻿using System;
using System.Collections.Generic;

namespace Game.Event
{
  public class LoadAssetBundlesSignal : GS.GameEvent
  {
    public readonly List<string> data;
    public readonly Action handler;
    public readonly IProgress<float> progress;

    public LoadAssetBundlesSignal(List<string> data, Action handler, IProgress<float> progress = null)
    {
      this.data = data;
      this.handler = handler;
      this.progress = progress;
    }
  }
}
