﻿using System;

namespace Game.Event
{
  public class SetDefaultProgressSignal : GS.GameEvent
  {
    public readonly IProgress<float> Progress;

    public SetDefaultProgressSignal(IProgress<float> progress)
    {
      Progress = progress;
    }
  }
}
