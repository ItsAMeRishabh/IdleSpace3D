﻿using GS;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ApplicationQuitSignal : GameEvent
{
  public ApplicationQuitSignal()
  {
  }
}

