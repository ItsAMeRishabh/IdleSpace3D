﻿using System;
using UnityEngine;

namespace Game.Event
{
  public class GetAssetBundleSignal : GS.GameEvent
  {
    public readonly string path;
    public readonly Action<AssetBundle> handler;

    public GetAssetBundleSignal(string path, Action<AssetBundle> handler)
    {
      this.path = path;
      this.handler = handler;
    }
  }
}
