﻿using GS;
using System;

namespace Game.Event
{
  public class GetAssetSignal : GameEvent
  {
    public string name;
    public string path;
    public Type assetType;
    public Action<UnityEngine.Object> handler;

    public GetAssetSignal(string name, Type type, Action<UnityEngine.Object> handler)
    {
      this.name = name;
      this.assetType = type;
      this.handler = handler;
    }

    public GetAssetSignal(string name, string path, Type type, Action<UnityEngine.Object> handler)
    {
      this.name = name;
      this.assetType = type;
      this.path = path;
      this.handler = handler;
    }
  }
}
