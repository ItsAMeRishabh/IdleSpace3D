﻿using GS;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Game.Event
{
  public class IsBundlePresent : GameEvent
  {
    public string bundleName;
    public Action<bool> isBundlePresent;

    public IsBundlePresent(string bundleName, Action<bool> isBundlePresent)
    {
      this.bundleName = bundleName;
      this.isBundlePresent = isBundlePresent;
    }
  }
}
