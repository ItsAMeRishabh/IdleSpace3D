﻿using GS;

namespace Game.Event
{
  public class UnloadAssetBundleSignal : GameEvent
  {
    public readonly string name;
    public readonly bool unloadAllLoadedObjects;
    public readonly bool unloadDependencies;

    public UnloadAssetBundleSignal(string name, bool unloadAllLoadedObjects = false, bool unloadDependencies = false)
    {
      this.name = name;
      this.unloadAllLoadedObjects = unloadAllLoadedObjects;
      this.unloadDependencies = unloadDependencies;
    }
  }
}
