﻿using Game.Event;
using System;
using UnityEngine;
using UnityEngine.UI;


public static class AssetBundleUtil
{

  public static void GetSprite(string name, Action<Sprite> handler)
  {
    if (string.IsNullOrEmpty(name))
    {
      return;
    }

    GS.EventManager.Instance.TriggerEvent(new GetAssetSignal(name, typeof(Sprite), (value) =>
    {
      if (value != null)
      {
        handler?.Invoke((Sprite)value);
      }

    }));
  }

  public static void GetSprite(string name, string path, Action<Sprite> handler)
  {
    if (string.IsNullOrEmpty(path))
    {
      return;
    }

    GS.EventManager.Instance.TriggerEvent(new LoadAssetBundleSignal(path, (bundle) =>
    {
      if (bundle != null)
      {
        var value = bundle.LoadAsset<Sprite>(name);
        if (value != null)
        {
          handler?.Invoke(value);
        }
      }
      else if(bundle == null)
      {
        GS.EventManager.Instance.TriggerEvent(new ShowAssetDownloadOrConfigurationFailedSignal(() => GetSprite(name, path, handler)));
      }
    }));
  }

  public static void AssetSprite(this Image image, string name)
  {
    if (string.IsNullOrEmpty(name))
    {
      return;
    }

    var bundleName = name.GetBundleName();
    if (!string.IsNullOrEmpty(bundleName))
    {
      GetSprite(name.GetAssetName(), bundleName, (x) => image.sprite = x);
    }
    else
    {
      GetSprite(name, (x) => image.sprite = x);
    }
  }
}
