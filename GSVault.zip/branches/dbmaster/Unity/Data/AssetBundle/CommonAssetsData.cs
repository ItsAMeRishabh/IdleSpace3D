﻿using System.Collections.Generic;
using UnityEngine;

namespace Game.Data
{
  [CreateAssetMenu(fileName = "CommonAssets")]
  public class CommonAssetsData : ScriptableObject
  {
    [SerializeField]
    private DataPath path;

    public List<string> Paths
    {
      get
      {
        return path.GetUrls();
      }
    }

    [System.Serializable]
    private class DataPath
    {
      public List<string> Urls;

      internal List<string> GetUrls()
      {
        return Urls;
      }
    }
  }

}
