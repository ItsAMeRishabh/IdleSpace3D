﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class StringExtensions
{

  public static string GetAssetName(this string name)
  {
    if (name.Contains("/"))
    {
      int startIndex = name.LastIndexOf("/") + 1;
      int pathLength = name.Length;
      var assetName = name.Substring(startIndex, pathLength - startIndex);
      //var bundleName = name.Substring(0, pathLength - (assetName.Length + 1));

      return assetName;
    }

    if (name.Contains("\\"))
    {
      int startIndex = name.LastIndexOf("\\") + 1;
      int pathLength = name.Length;
      var assetName = name.Substring(startIndex, pathLength - startIndex);
      //var bundleName = name.Substring(0, pathLength - (assetName.Length + 1));

      return assetName;
    }

    return name;
  }

  public static string GetBundleName(this string name)
  {
    if (name.Contains("/"))
    {
      int startIndex = name.LastIndexOf("/") + 1;
      int pathLength = name.Length;
      var assetName = name.Substring(startIndex, pathLength - startIndex);
      var bundleName = name.Substring(0, pathLength - (assetName.Length + 1));

      return bundleName;
    }

    if (name.Contains("\\"))
    {
      int startIndex = name.LastIndexOf("\\") + 1;
      int pathLength = name.Length;
      var assetName = name.Substring(startIndex, pathLength - startIndex);
      var bundleName = name.Substring(0, pathLength - (assetName.Length + 1));

      return bundleName;
    }

    return string.Empty;
  }

}
