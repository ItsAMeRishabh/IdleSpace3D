﻿using AssetBundles;
using Game.Event;
using GS;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Game.Controller
{
    public sealed class AssetBundleController<TSettingType, TPacketType> : GS.IController
        where TSettingType : Enum
        where TPacketType : Enum
    {
        private readonly AssetBundleManager bundleManager;

        private Queue<LoadAssetBundleSignal> signals;

        private bool isDownloading;

        private IProgress<float> progress { get { return overrideProgress ?? defaultProgress; } }

        private IProgress<float> defaultProgress;

        private IProgress<float> overrideProgress;

        public AssetBundleController(AssetBundleManager bundleManager)
        {
            this.bundleManager = bundleManager;
            signals = new Queue<LoadAssetBundleSignal>();
            isDownloading = false;
        }

        #region ICONTROLLER IMPLEMENTATION

        public void Initialize()
        {
        }

        public void RegisterListener()
        {
            //var eventManager = GS.EventManager.Instance;
            EventManager.Instance.AddListener<SetDefaultProgressSignal>(OnSetDefaultProgressEvent);
            EventManager.Instance.AddListener<InitializeAssetBundleSignal>(OnInitializeAssetBundleManager);
            EventManager.Instance.AddListener<LoadAssetBundleSignal>(OnLoadAssetBundleEvent);
            EventManager.Instance.AddListener<LoadAssetBundlesSignal>(OnLoadAssetBundlesEvent);
            EventManager.Instance.AddListener<GetAssetSignal>(OnGetAssetEvent);
            EventManager.Instance.AddListener<UnloadAssetBundleSignal>(OnUnloadAssetBundleEvent);
            EventManager.Instance.AddListener<GetAssetBundleSignal>(OnGetAssetBundleSignal);
            EventManager.Instance.AddListener<IsBundlePresent>(OnIsBundlePresent);
            EventManager.Instance.AddListener<ApplicationQuitSignal>(OnApplicationQuit);
        }

        private void OnIsBundlePresent(IsBundlePresent e)
        {
            if (bundleManager.getUnhashedToHashedBundleNameMap().ContainsKey(e.bundleName))
            {
                e.isBundlePresent?.Invoke(true);
            }
            else
                e.isBundlePresent?.Invoke(false);
        }

        public void Release()
        {
            bundleManager.Dispose();
        }

        public void UnRegisterListener()
        {
            var eventManager = GS.EventManager.Instance;
            eventManager.RemoveListener<SetDefaultProgressSignal>(OnSetDefaultProgressEvent);
            eventManager.RemoveListener<InitializeAssetBundleSignal>(OnInitializeAssetBundleManager);
            eventManager.RemoveListener<LoadAssetBundleSignal>(OnLoadAssetBundleEvent);
            eventManager.RemoveListener<GetAssetSignal>(OnGetAssetEvent);
            eventManager.RemoveListener<UnloadAssetBundleSignal>(OnUnloadAssetBundleEvent);
            eventManager.RemoveListener<LoadAssetBundlesSignal>(OnLoadAssetBundlesEvent);
            eventManager.RemoveListener<GetAssetBundleSignal>(OnGetAssetBundleSignal);
            eventManager.RemoveListener<IsBundlePresent>(OnIsBundlePresent);
            eventManager.RemoveListener<ApplicationQuitSignal>(OnApplicationQuit);

        }

        #endregion

        #region HELPER METHODS

        private void GetAssetWithoutPath(IDictionary<string, AssetBundleManager.AssetBundleContainer> bundles, string name, Type assetType, Action<UnityEngine.Object> handler)
        {
            //loops through all asset bundles to fetch the asset.
            foreach (var bundle in bundles)
            {
                var asset = bundle.Value.AssetBundle.LoadAsset(name, assetType);
                if (asset)
                {
                    handler?.Invoke(asset);
                    return;
                }
            }

            LogAssetNotFoundError(name);
            handler?.Invoke(null);
        }

        private void LogAssetNotFoundError(string name)
        {
            Log.Error("[ASSET BUNDLES] : Asset not found " + name);
        }

        private void LogBundletNotFoundError(string name)
        {
            Log.Error("[ASSET BUNDLES] : Bundle not found " + name);
        }

        private IEnumerator LoadAssetBundlesEnumerator(List<string> data, Action completeHandler, IProgress<float> progress)
        {
            int length = data.Count;

            for (int i = 0; i < length; i++)
            {
                yield return LoadAssetBundleAsync(data[i]);
                progress?.Report((float)(i + 1) / length);
            }

            completeHandler?.Invoke();
        }

        private IEnumerator LoadAssetBundleAsync(string url)
        {
            AssetBundle assetBundle = null;
            bundleManager.GetBundle(url, (bundle) =>
            {
                assetBundle = bundle;

            });

            while (!assetBundle)
            {
                yield return null;
            }
            yield return true;
        }

        #endregion

        #region EVENTS

        private void OnGetAssetBundleSignal(GetAssetBundleSignal e)
        {
            var bundleContainer = bundleManager.GetLoadedAssetBundles()[bundleManager.GetHashedBundleName(e.path)];
            if (bundleContainer == null)
            {
                Log.Error("[ASSET BUNDLE] Bundle not loaded :" + e.path);
                e.handler?.Invoke(null);
                return;
            }

            e.handler?.Invoke(bundleContainer.AssetBundle);
        }

        private void OnSetDefaultProgressEvent(SetDefaultProgressSignal e)
        {
            defaultProgress = e.Progress;
        }

        private void OnInitializeAssetBundleManager(InitializeAssetBundleSignal e)
        {
            //Debug.LogError($"OnInitializeAssetBundleManager is reached");
            if (!bundleManager.Initialized) // got false for => found the internal or external manifest for asset bundle 
            {
                bundleManager.SetBaseUri(e.baseURL, e.useLocalIfAvailable);
                bundleManager.AppendHashToBundleNames();
                //bundleManager.Initialize(e.onCompleteLoading);
            }
            else
            {
                //Debug.LogError($"TGL Asset bundle Manager is already initialized, cannot set base URL and append Hash with current data");
            }
            //Debug.LogError($"TGL Calling for Initializing the Asset Bundle with the settings given");
            bundleManager.Initialize(e.onCompleteLoading);
        }

        private void OnLoadAssetBundleEvent(LoadAssetBundleSignal e)
        {

            //Debug.Log("Load Asset Bundle Called 2");
            Log.Print("ASSET BUNDLE Loaded " + e.name, LogFilter.GameEvent);


            LoadBundle(e);
            //if (!isDownloading)
            //{
            //    //Debug.Log("Load Asset Bundle Called 8");
            //}
            //else
            //{
            //    //Debug.Log("Load Asset Bundle Called 4");
            //    signals.Enqueue(e);
            //}
        }

        private void LoadBundle(LoadAssetBundleSignal e)
        {
            isDownloading = true;
            overrideProgress = e.progress;

            bundleManager.GetBundle(e.name, (bundle) =>
            {
                overrideProgress = null;
                OnCompleteDownloading(bundle, e.handler);
            }, progress);

            //if you want to show the bundle info in loading screen, use this call.
            //GS.EventManager.Instance.TriggerEvent(new Event.ShowDownloadInfoSignal(e.name, ShowDownloadInfoSignal.InfoType.Asset));
        }

        private void OnCompleteDownloading(AssetBundle bundle, Action<AssetBundle> handler)
        {
            handler?.Invoke(bundle);
            isDownloading = signals.Count > 0;
            //Debug.Log("Load Asset Bundle Called 3" + isDownloading);
            if (isDownloading)
            {
                var e = signals.Dequeue();
                LoadBundle(e);
            }
        }

        private void OnGetAssetEvent(GetAssetSignal e)
        {
            //Get all loaded asset bundles.
            var bundles = bundleManager.GetLoadedAssetBundles();

            //If asset path is not given.
            if (string.IsNullOrEmpty(e.path))
            {
                //Loops through all the asset bundles to get the asset.
                GetAssetWithoutPath(bundles, e.name, e.assetType, e.handler);
            }
            else
            {
                if (bundles.TryGetValue(bundleManager.GetHashedBundleName(e.path), out AssetBundleManager.AssetBundleContainer bundleContainer))
                {
                    var asset = bundleContainer.AssetBundle.LoadAsset(e.name, e.assetType);

                    //if asset is found.
                    if (asset != null)
                    {

                        e.handler?.Invoke(asset);
                    }
                    else
                    {
                        //Log asset not found.
                        LogAssetNotFoundError(e.name);
                        e.handler?.Invoke(null);
                    }
                }
                else
                {
                    LogBundletNotFoundError(e.path);
                    e.handler?.Invoke(null);
                }
            }
        }

        private void OnUnloadAssetBundleEvent(UnloadAssetBundleSignal e)
        {
            bundleManager.UnloadBundle(e.name, e.unloadAllLoadedObjects, e.unloadDependencies);
        }

        private void OnLoadAssetBundlesEvent(LoadAssetBundlesSignal e)
        {
            MainEntry<TSettingType, TPacketType>.Instance.StartCoroutine(LoadAssetBundlesEnumerator(e.data, e.handler, e.progress));
        }

        private void OnApplicationQuit(ApplicationQuitSignal e)
        {

            var loadedBundles = AssetBundle.GetAllLoadedAssetBundles();

            foreach (var loadedBundle in loadedBundles)
            {
                bundleManager.UnloadBundle(loadedBundle);
            }
        }

        //private void OnRecieveData(QuitAppResponseClient obj)
        //{
        //}

        #endregion

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            var assetBundles = bundleManager.GetLoadedAssetBundles();

            foreach (var container in assetBundles)
            {
                if (container.Value.AssetBundle)
                {
                    stringBuilder.Append(container.Value.AssetBundle.name);
                    stringBuilder.Append("\n");
                }
            }

            return stringBuilder.ToString();
        }

        public void Update()
        {
        }
    }
}
