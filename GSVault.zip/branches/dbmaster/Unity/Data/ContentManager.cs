using Game.Data;
using GS.GameConsts;
using System;
using UnityEngine;

namespace GS.Data
{
    /// <summary>
    /// This class is responsible for Initilizing  (I)DataContainer(s).
    /// </summary>
    public partial class ContentManager // : SingleTon<ContentManager> 
    {

        // Instance of this class
        private static ContentManager _contentManager = null;
        public ProjectSpecificData projectSpecificData = null;

    public static ContentManager Instance
    {
      get
      {
        // This will make sure we will have only one instance of this class.
        if (_contentManager == null)
        {
          _contentManager = new ContentManager();
        }
        return _contentManager;
      }
    }


    /// <summary>
    /// Creates and returns object of 'T'. Additionally,
    /// 1. Checks asset bundles key in config file, if found, invokes object to read asset bundle by passing it.
    /// 2. If not found in config file, invokes object to read data from local(Resorces folder).
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="dataController">Object of controller instantiating IDataContainer</param>
    /// <returns></returns>
    public T Load<T>(DataController dataController) where T : IDataContainer
        {
            var obj = Activator.CreateInstance(typeof(T), dataController);

            IDataContainer iData = (IDataContainer)obj;
            string key = iData.AssetBundleKey;

            AssetBundle assetBundle = null;

            // Get Asset Bundle of key assigned to it.
            //if (AssetBundleManager.IsKeyExits(key))
            assetBundle = AssetBundleManager.GetAssetBundle(key);

            if (assetBundle == null)
            {
                //  Debug.Log("ContentManager - AssetBundle not found for, '" + key + "'\n Going with resources folder");
                iData.ReadLocal();
            }
            else
            {
                iData.ReadAssetBundle(assetBundle);
            }

            return (T)obj;
        }
    public GameGraphicsType GetGameGraphicType()
    {
#if UNITY_EDITOR
            if (ContentManager.Instance.GetProjectSpecificData().shouldEditorReturnHDAssets)
            {
                //Debug.LogError("under UNITY_EDITOR preprocessor - returning HD");
                return GameGraphicsType.HD;
            }
#endif
            if (projectSpecificData == null)
            {
                //Debug.LogError("projectSpecificData is null, was returning SD here earlier!!");
                GetProjectSpecificData();
            }

            if (projectSpecificData.assetsBasedOnGraphicType && SystemInfo.systemMemorySize > projectSpecificData.lowEndphoneMemorySize)
            {
                //Debug.LogError("SystemInfo.systemMemorySize:"+ SystemInfo.systemMemorySize+ ", greater than projectSpecificData.lowEndphoneMemorySize:"+ projectSpecificData.lowEndphoneMemorySize+" - Returning HD");
                return GameGraphicsType.HD;
            }
            else
            {
                //Debug.LogError("SystemInfo.systemMemorySize:" + SystemInfo.systemMemorySize + ", less than equal to projectSpecificData.lowEndphoneMemorySize:" + projectSpecificData.lowEndphoneMemorySize + " - Returning SD");
                return GameGraphicsType.SD;
            }
    }
    public ProjectSpecificData GetProjectSpecificData()
    {
      if (projectSpecificData == null)
        Utils.EventSync(new GetProjectSpecificData((projectData) => 
        {
          if (projectData == null)
            projectSpecificData = new ProjectSpecificData();
          else
            projectSpecificData = projectData;
        }));

      //ProjectSpecificDataCreator projectSpecificDataCreator = Resources.Load<ProjectSpecificDataCreator>("ProjectSpecificData");
      //if (projectSpecificData == null)
      //  projectSpecificData = new ProjectSpecificData();
      //else
      //  projectSpecificData = projectSpecificDataCreator.isThisProjectSupports;
      return projectSpecificData;


    }
  }
}