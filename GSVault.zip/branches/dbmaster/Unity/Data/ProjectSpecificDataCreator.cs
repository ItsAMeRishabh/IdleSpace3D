﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Game.Data
{
  [CreateAssetMenu(fileName = "ProjectSpecificData", menuName ="GSVault/ProjectSpecificData")]
  public class ProjectSpecificDataCreator : ScriptableObject
  {
    [SerializeField]
    public ProjectSpecificData isThisProjectSupports;
  }

  [System.Serializable]
  public class ProjectSpecificData
  {
    public bool assetsBasedOnGraphicType;
    public float lowEndphoneMemorySize;
    public string graphicTypeSuffix;
    public bool shouldEditorReturnHDAssets;
    public ProjectSpecificData()
    {
      assetsBasedOnGraphicType = false;
      lowEndphoneMemorySize = 2;
      graphicTypeSuffix = "";
      shouldEditorReturnHDAssets = false;
    }
  }


}
