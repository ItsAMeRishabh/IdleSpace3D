﻿using UnityEngine;

namespace GS.Data
{
    /// <summary>
    /// Genaric class to Load Assets from AssetBundle/Resources Folder
    /// </summary>
    public class AssetDataController : IDataContainer
    {
        public AssetDataController(DataController dataController)
            : base(dataController) { }

        #region Interface

        public override string AssetBundleKey
        {
            get
            {
                // As it is Genaric class this value is not required.
                return "";
            }
        }

        public override void ReadAssetBundle(AssetBundle assetBundle) { }

        public override void ReadLocal() { }

        public override void RegisterListners()
        {
            EventManager.Instance.AddListener<LoadPrefabEvent>(LoadPrefabEventListner);
            EventManager.Instance.AddListener<LoadSpriteEvent>(LoadSpriteEventListner);
            EventManager.Instance.AddListener<LoadAnimatorControllerEvent>(
                LoadAnimatorControllerEventListner
            );
            EventManager.Instance.AddListener<LoadTextureEvent>(LoadTextureEventListner);
            EventManager.Instance.AddListener<LoadTextAssetEvent>(LoadTextureEventListner);
            EventManager.Instance.AddListener<LoadScriptableObjectEvent>(
                LoadScriptableObjectEventListner
            );
            EventManager.Instance.AddListener<LoadBundle>(LoadAssetBundleEventListner);
        }

        public override void DeRegisterListners()
        {
            EventManager.Instance.RemoveListener<LoadPrefabEvent>(LoadPrefabEventListner);
            EventManager.Instance.RemoveListener<LoadSpriteEvent>(LoadSpriteEventListner);
            EventManager.Instance.RemoveListener<LoadAnimatorControllerEvent>(
                LoadAnimatorControllerEventListner
            );
            EventManager.Instance.RemoveListener<LoadTextureEvent>(LoadTextureEventListner);
            EventManager.Instance.RemoveListener<LoadTextAssetEvent>(LoadTextureEventListner);
            EventManager.Instance.RemoveListener<LoadScriptableObjectEvent>(
                LoadScriptableObjectEventListner
            );
            EventManager.Instance.RemoveListener<LoadBundle>(LoadAssetBundleEventListner);
        }

        #endregion Interface


        #region Event Listners

        private void LoadPrefabEventListner(LoadPrefabEvent eve)
        {
            // If callback is null then no need to fetch asset
            if (eve != null && eve.callback != null)
            {
                /* GameObject prefab = */
                ContentReader.LoadAssetType<GameObject>(
                    eve.assetRelativePath,
                    eve.assetBundleKey,
                    eve.callback
                );
                // eve.callback(prefab);
            }
        }

        private void LoadSpriteEventListner(LoadSpriteEvent eve)
        {
            // If callback is null then no need to fetch asset
            if (eve != null && eve.callback != null)
            {
                /* Sprite prefab = */ContentReader.LoadAssetType<Sprite>(
                    eve.assetRelativePath,
                    eve.assetBundleKey,
                    eve.callback
                );
                // eve.callback(prefab);
            }
        }

        private void LoadAnimatorControllerEventListner(LoadAnimatorControllerEvent eve)
        {
            // If callback is null then no need to fetch asset
            if (eve != null && eve.callback != null)
            {
                /* RuntimeAnimatorController prefab =*/ContentReader.LoadAssetType<RuntimeAnimatorController>(
                    eve.assetRelativePath,
                    eve.assetBundleKey,
                    eve.callback
                );
                //eve.callback(prefab);
            }
        }

        private void LoadTextureEventListner(LoadTextureEvent eve)
        {
            // If callback is null then no need to fetch asset
            if (eve != null && eve.callback != null)
            {
                /*Texture prefab = */ContentReader.LoadAssetType<Texture>(
                    eve.assetRelativePath,
                    eve.assetBundleKey,
                    eve.callback
                );
                //eve.callback(prefab);
            }
        }

        private void LoadTextureEventListner(LoadTextAssetEvent eve)
        {
            // If callback is null then no need to fetch asset
            if (eve != null && eve.callback != null)
            {
                /* TextAsset prefab = */ContentReader.LoadAssetType<TextAsset>(
                    eve.assetRelativePath,
                    eve.assetBundleKey,
                    eve.callback
                );
                //eve.callback(prefab);
            }
        }

        private void LoadScriptableObjectEventListner(LoadScriptableObjectEvent eve)
        {
            // If callback is null then no need to fetch asset
            if (eve != null && eve.callback != null)
            {
                /* Object prefab = */
                ContentReader.LoadAssetType<Object>(
                    eve.assetRelativePath,
                    eve.assetBundleKey,
                    eve.callback
                );
                //eve.callback(prefab);
            }
        }

        private void LoadAssetBundleEventListner(LoadBundle eve)
        {
            // If callback is null then no need to fetch asset
            if (eve != null)
            {
                /* Object prefab = */
                ContentReader.LoadBundle(eve.assetBundleKey, eve.action, eve.progress);
                //eve.callback(prefab);
            }
        }

        #endregion Event Listners


        #region Genaric EventListner is in Testing

        //private void LoadGenaricTypeEventListner<T>(LoadPrefabEvent<T> eve) where T : UnityEngine.Object
        //{
        //    T prefab = ContentReader.LoadAssetType<T>(eve.prefabRelativePath, eve.assetBundleKey);
        //    if (eve.callback != null)
        //        eve.callback(prefab);
        //}

        #endregion Genaric EventListner is in Testing
    } // class
} // namespace Cricket
