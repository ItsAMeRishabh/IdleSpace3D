﻿using System;
using UnityEngine;

namespace GS
{
    namespace Data
    {

        /// <summary>
        /// Adds Data Containers to DataControllers
        /// </summary>
        public class AddDataConainerEvent : GameEvent
        {
            public IDataContainer container;

            public AddDataConainerEvent(IDataContainer container)
            {
                this.container = container;
            }
        }


        /// <summary>
        /// Removes Data Containers to DataControllers
        /// </summary>
        public class RemoveDataConainerEvent : GameEvent
        {
            public IDataContainer container;

            public RemoveDataConainerEvent(IDataContainer container)
            {
                this.container = container;
            }
        }

        /// <summary>
        /// This is a base class for all asset loading classes
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public class AssetBaseClass<T> : GameEvent
        {
            public string assetBundleKey { get; protected set; }
            public string assetRelativePath { get; protected set; }

            public Action<T> callback { get; private set; }

            protected AssetBaseClass(string assetBundleKey, string prefabRelativePath, /*string resourcesPath, */ Action<T> callback)
            {
                this.callback = callback;
                this.assetBundleKey = assetBundleKey;
                this.assetRelativePath = prefabRelativePath;
            }

            public override string ToString()
            {
                return "LoadAnimator :" + assetBundleKey + ", Prefab = " + assetRelativePath;
            }
        }

        /// <summary>
        /// Loads prefab from given path from given assetBundle
        /// </summary>
        public class LoadPrefabEvent : AssetBaseClass<GameObject>
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="assetBundleKey"></param>
            /// <param name="prefabRelativePath">Path including prefab name</param>
            /// <param name="callback"></param>
            public LoadPrefabEvent(string assetBundleKey, string prefabRelativePath, /*string resourcesPath, */ Action<GameObject> callback) : base(assetBundleKey, prefabRelativePath, callback)
            {
            }
        }

        /// <summary>
        /// Loads sprite from given path from given assetBundle
        /// </summary>
        public class LoadSpriteEvent : AssetBaseClass<Sprite>
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="assetBundleKey"></param>
            /// <param name="prefabRelativePath">Path including prefab name</param>
            /// <param name="callback"></param>
            public LoadSpriteEvent(string assetBundleKey, string prefabRelativePath, /*string resourcesPath, */ Action<Sprite> callback) : base(assetBundleKey, prefabRelativePath, callback)
            {
            }
        }

        /// <summary>
        /// Loads RuntimeAnimatorController from given path from given assetBundle
        /// </summary>
        public class LoadAnimatorControllerEvent : AssetBaseClass<RuntimeAnimatorController>
        {
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="assetBundleKey"></param>
            /// <param name="prefabRelativePath">Path including prefab name</param>
            /// <param name="callback"></param>
            public LoadAnimatorControllerEvent(string assetBundleKey, string prefabRelativePath, /*string resourcesPath, */ Action<RuntimeAnimatorController> callback) : base(assetBundleKey, prefabRelativePath, callback)
            {
            }

           
        }

        public class ReleaseGameObjectEvent : GameEvent
        {
            public GameObject gameObject;

            public ReleaseGameObjectEvent(GameObject gameObject)
            {
                this.gameObject = gameObject;
            }
        }

        /// <summary>
        /// Loads Texture from given path from given assetBundle
        /// </summary>
        public class LoadTextureEvent : AssetBaseClass<Texture>
        {
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="assetBundleKey"></param>
            /// <param name="prefabRelativePath">Path including prefab name</param>
            /// <param name="callback"></param>
            public LoadTextureEvent(string assetBundleKey, string prefabRelativePath, /*string resourcesPath, */ Action<Texture> callback) : base(assetBundleKey, prefabRelativePath, callback)
            {
            }
        }

        /// <summary>
        /// Loads TextAsset from given path from given assetBundle
        /// </summary>
        public class LoadTextAssetEvent : AssetBaseClass<TextAsset>
        {
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="assetBundleKey"></param>
            /// <param name="prefabRelativePath">Path including prefab name</param>
            /// <param name="callback"></param>
            public LoadTextAssetEvent(string assetBundleKey, string prefabRelativePath, /*string resourcesPath, */ Action<TextAsset> callback) : base(assetBundleKey, prefabRelativePath, callback)
            {
            }
        }

        /// <summary>
        /// Loads ScriptableObject(as UnityEngine.Object so type casting needed) from given path from given assetBundle
        /// </summary>
        public class LoadScriptableObjectEvent : AssetBaseClass<UnityEngine.Object>
        {
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="assetBundleKey"></param>
            /// <param name="prefabRelativePath">Path including prefab name</param>
            /// <param name="callback"></param>
            public LoadScriptableObjectEvent(string assetBundleKey, string prefabRelativePath, /*string resourcesPath, */ Action<UnityEngine.Object> callback) : base(assetBundleKey, prefabRelativePath, callback)
            {
            }
        }

        public class LoadBundle : GameEvent
        {
            public string assetBundleKey;
            public Action<AssetBundle> action;
            public IProgress<float> progress;

            public LoadBundle(string assetBundleKey, Action<AssetBundle> action, IProgress<float> progress)
            {
                this.assetBundleKey = assetBundleKey;
                this.action = action;
                this.progress = progress;
            }
        }
    } // namespace AssetInfo
} // namespace Data
