﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Data
{
    /// <summary>
    /// Event to inform that 'AssetBundleManager InitDone'
    /// </summary>
    public class AssetBundleManagerInitDone : GameEvent
    {

    }
    
}