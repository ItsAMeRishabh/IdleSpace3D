﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using GS.Data.DataConsts;

namespace GS.Data
{
    static public class AssetBundleManager
    {
        // A dictionary to hold the AssetBundle references
        static private Dictionary<string, AssetBundleRef> dictAssetBundleRefs;
        public static Dictionary<string, Action<string, float, string>> assetBundleCallbacks = new Dictionary<string, Action<string, float, string>>();

        static AssetBundleManager()
        {
            dictAssetBundleRefs = new Dictionary<string, AssetBundleRef>();
        }

        public static void Reset()
        {
            dictAssetBundleRefs = new Dictionary<string, AssetBundleRef>();
            assetBundleCallbacks = new Dictionary<string, Action<string, float, string>>();

            groupProgress = null;
            groupedAssetBundleKeyWithGorpedName = null;
        }


        #region AssetBundle Section
        // Class with the AssetBundle reference, url and version
        private class AssetBundleRef
        {
            public AssetBundle assetBundle = null;
            public int version;
            public string url;
            public AssetBundleRef(string strUrlIn, int intVersionIn)
            {
                url = strUrlIn;
                version = intVersionIn;
            }
        };

        internal static void DownloadAssetBundleGroup(object beforeMainMenu, object initialBundlesDownloadCallback)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Returns true if we have asset bundle reference.
        /// </summary>
        /// <param name="assetBundleKey"></param>
        /// <returns></returns>
        public static bool IsAssetBundleExits(string assetBundleKey)
        {
            if (dictAssetBundleRefs != null)
                return dictAssetBundleRefs.ContainsKey(assetBundleKey);
            else
            {
                Log.Error("AssetBundleManager - Dict is not initialize");
                return false;
            }
        }

        /// <summary>
        /// Returns asset bundle of specifed key. Null, if not found
        /// </summary>
        /// <param name="bundleKey"></param>
        /// <returns></returns>
        public static AssetBundle GetAssetBundle(string bundleKey) //string url, int version = -1)
        {
            if (!IsAssetBundleExits(bundleKey))
                return null;

            string keyName = bundleKey; // url + version.ToString();
            AssetBundleRef abRef;
            if (dictAssetBundleRefs.TryGetValue(keyName, out abRef))
                return abRef.assetBundle;
            else
                return null;
        }

        #endregion AssetBundle Section


        #region Downloads Section

        #region Grouped Assetbundles Private Members
        /// <summary>
        /// Stores info of received GroupDownload command.
        /// </summary>
        private class GroupedProgress
        {
            public string callBackKey;

            /// <summary>
            /// param1:BundleKey/GroupKey, param2:DownloadProgress between 0.0f to 1.0f, param3:AdditionalComments
            /// </summary>
            public Action<string, float, string> callBack;

            public Dictionary<string, float> individualProgress;
            //float totalProgress = 0.0f;

            // Adds up all child bundles progress
            public void AddProgress(string individualKey, float f, string comments)
            {
                //Debug.Log("Indie : " + f);
                float totalProgress = 0.0f;

                individualProgress[individualKey] = f;

                foreach (float progrss in individualProgress.Values)
                {
                    totalProgress += progrss;
                }


                //totalProgress += f;
                //Debug.Log("Total : " + totalProgress);

                PostProgress(totalProgress, comments);
            }

            // Invokes parent 'callBack' when ever a we receive child bundle progress
            private void PostProgress(float totalProgress, string comments)
            {
                float combinedProgress = GetCombinedProgress(totalProgress);
                callBack.Invoke(callBackKey, combinedProgress, comments);

                if (combinedProgress >= 1)
                {
                    // All asset bundles in group are downloaded
                    // So, this object can be removed from Dictinory
                }
            }

            // Groups child progress into single.
            private float GetCombinedProgress(float totalProgress)
            {
                return totalProgress / individualProgress.Count;
            }
        }

        /// <summary>
        /// Adds an entry when we start downloading an Group of asset bundle
        /// </summary>
        private static Dictionary<string, GroupedProgress> groupProgress;

        /// <summary>
        /// Maintains Grouped asset bundle info as,
        /// child Bundle Name as key, Group Name as value
        /// </summary>
        private static Dictionary<string, string> groupedAssetBundleKeyWithGorpedName;

        /// <summary>
        /// Internal method to receive call backs of Grouped asset bundles
        /// </summary>
        /// <param name="individualKey">Individual Bundle Key</param>
        /// <param name="f">DownloadProgress between 0.0f to 1.0f</param>
        /// <param name="comments">AdditionalComments</param>
        private static void GroupBundlesProgressCallback(string individualKey, float f, string comments)
        {
            string groupKey = groupedAssetBundleKeyWithGorpedName[individualKey];
            if (groupProgress.ContainsKey(groupKey))
            {
                groupProgress[groupKey].AddProgress(individualKey, f, comments);
            }
        }
        #endregion Grouped Assetbundles Private Members

        /// <summary>
        /// Downloads entire bundles present inside Group specified
        /// </summary>
        /// <param name="bundleGroupKey"></param>
        /// <param name="callBackKey">Must be Unique</param>
        /// <param name="progress">param1:BundleKey/GroupKey, param2:DownloadProgress between 0.0f to 1.0f, param3:AdditionalComments</param>
        public static void DownloadAssetBundleGroup(string rootPath, string bundleGroupKey, Action<string, float, string> progress = null)
        {
            List<string> bundleNames = AssetBundleConfigFileManager.Instance.GetBundleNamesInGroup(bundleGroupKey);

            // Group progress callbacks into one progress
            if (progress != null)
            {
                GroupedProgress grouped = new GroupedProgress();
                grouped.callBackKey = bundleGroupKey;
                grouped.callBack = progress;
                //grouped.totalSubItems = bundleNames.Count;
                grouped.individualProgress = new Dictionary<string, float>(bundleNames.Count);

                // Check null, before adding. So that object will be created only when needed(Instead of in constructor).
                if (groupProgress == null)
                    groupProgress = new Dictionary<string, GroupedProgress>();

                groupProgress.Add(bundleGroupKey, grouped);
            }

            for (int i = 0; i < bundleNames.Count; i++)
            {
                // Check null, before adding. So that object will be created only when needed(Instead of in constructor).
                if (groupedAssetBundleKeyWithGorpedName == null)
                    groupedAssetBundleKeyWithGorpedName = new Dictionary<string, string>();

                groupedAssetBundleKeyWithGorpedName.Add(bundleNames[i], bundleGroupKey);

                groupProgress[bundleGroupKey].individualProgress.Add(bundleNames[i], 0.0f);

                DownloadAssetBundle(rootPath, bundleNames[i], bundleGroupKey, GroupBundlesProgressCallback);
            }
        }

        /// <summary>
        /// Downloads Specified bundle, if found in Config file.
        /// </summary>
        /// <param name="bundleKey"></param>
        /// <param name="callBackKey"></param>
        /// <param name="progress">param1:BundleKey/GroupKey, param2:DownloadProgress between 0.0f to 1.0f, param3:AdditionalComments</param>
        public static void DownloadAssetBundle(string rootPath, string bundleKey, string callBackKey, Action<string, float, string> progress = null)
        {
            // No need to do below check. Because, if we want to download newer version at any point of application, it will download it again.
            // Check if we already downloaded bundle.
            //if(dictAssetBundleRefs.ContainsKey(bundleKey))

            // Check if we have bundle data in Config file or not
            AssetBundleConfigData? bundleData = AssetBundleConfigFileManager.Instance.GetBundleData(bundleKey);

            if (bundleData == null)
            {
                Log.Print("AssetBundleManager - Bundle data is not found form config file data for, " + bundleKey, LogFilter.Error);
                return;
            }

            MonobehaviourHelper.Instance.StartCoroutine(StartDownload(rootPath, bundleData.Value, callBackKey, progress));
        }

        /// <summary>
        /// Downloads pending bundles in config file
        /// </summary>
        public static void DownloadPendingBundles(string rootPath)
        {
            string[] allKeys = AssetBundleConfigFileManager.Instance.GetAllBundlesNames();

            //// Get all keys of downloaded bundles
            //string[] keys = new string[dictAssetBundleRefs.Keys.Count];
            //dictAssetBundleRefs.Keys.CopyTo(keys, 0);

            for (int i = 0; i < allKeys.Length; i++)
            {
                // If already downloaded, skip downloading it again.
                if (dictAssetBundleRefs.ContainsKey(allKeys[i]))
                    continue;

                // As it is not downloaded till now, download it
                DownloadAssetBundle(rootPath, allKeys[i], "");
            }
        }

        /// <summary>
        /// Downloads an AssetBundle, Adds it into Refrence Dictionary
        /// </summary>
        /// <param name="bundleData">Bundle info like URL, Version, Name</param>
        /// <param name="callBackKey">unique key for callback of this download</param>
        /// <param name="progress">call back for downloaded percentage.
        /// param1:BundleKey/GroupKey, param2:DownloadProgress between 0.0f to 1.0f, param3:AdditionalComments</param>
        /// <returns></returns>
        private static IEnumerator StartDownload(string rootPath, AssetBundleConfigData bundleData, string callBackKey, Action<string, float, string> progress = null)
        {
            //string keyName = url + version.ToString();
            string keyName = bundleData.bundleKey;

            if (!assetBundleCallbacks.ContainsKey(callBackKey) && progress != null)
                assetBundleCallbacks.Add(callBackKey, progress);

            if (dictAssetBundleRefs.ContainsKey(keyName))
                yield return null;
            else
            {
                if (!Caching.ready)
                {
                    yield return null;
                }

                using (WWW www = WWW.LoadFromCacheOrDownload(rootPath + "/" + bundleData.url, bundleData.version))
                {
                    //string prefKey = keyName; // url + "_" + version;

                    while (!www.isDone)
                    {
                        if (assetBundleCallbacks.ContainsKey(callBackKey) && www.progress < 1)
                            assetBundleCallbacks[callBackKey].Invoke(keyName, www.progress, "");
                        yield return null;
                    }

                    if (!string.IsNullOrEmpty(www.error))
                    {
                        string errorMsg = "WWW download:" + www.error + " URL: " + www.url;
                        // Add error in callMethod so that this info can be passed to receiver. Otherwise it will wait for progress reaches '1', which can't be possible forever as we got error.
                        if (assetBundleCallbacks.ContainsKey(callBackKey)) // at this moment, 'www.progress' is equal to 1
                            assetBundleCallbacks[callBackKey].Invoke(keyName, www.progress, ErrorMessages.ErrorDownloadingBundle + errorMsg);

                        throw new Exception(errorMsg);
                    }

                    AssetBundleRef abRef = new AssetBundleRef(bundleData.url, bundleData.version);
                    abRef.assetBundle = www.assetBundle;

                    // Store bundle reference
                    if (dictAssetBundleRefs.ContainsKey(keyName))
                    {
                        // Replace old bundle reference, as key exists already
                        dictAssetBundleRefs[keyName] = abRef;
                    }
                    else
                    {
                        // Add bundle reference
                        dictAssetBundleRefs.Add(keyName, abRef);
                    }

                    // This invoke must be after, adding bundle ref to our holding dictionary(dictAssetBundleRefs).
                    if (assetBundleCallbacks.ContainsKey(callBackKey))
                        assetBundleCallbacks[callBackKey].Invoke(keyName, www.progress, "");

                }
            }
        }

        #endregion Downloads Section

        public static void AddAssetBundle(string url, int version, AssetBundle bundle)
        {
            string keyName = url + version.ToString();
            AssetBundleRef abRef = new AssetBundleRef(url, version);
            abRef.assetBundle = bundle;
            dictAssetBundleRefs.Add(keyName, abRef);
        }

        // Unload an AssetBundle
        public static void Unload(string url, int version, bool allObjects)
        {
            string keyName = url + version.ToString();
            AssetBundleRef abRef;
            if (dictAssetBundleRefs.TryGetValue(keyName, out abRef))
            {
                abRef.assetBundle.Unload(allObjects);
                abRef.assetBundle = null;
                dictAssetBundleRefs.Remove(keyName);
            }
        }

        public static void UpdateCallBack(string key, Action<string, float, string> action)
        {
            if (assetBundleCallbacks.ContainsKey(key) && action != null)
                assetBundleCallbacks[key] = action;
        }
    }

    /// <summary>
    /// Model class for sending Config file data of an Asset bundle
    /// </summary>
    public struct AssetBundleConfigData
    {
        public string bundleKey;
        public string url;
        public int version;

        //public Action<string, string, float> progress;
    }
}