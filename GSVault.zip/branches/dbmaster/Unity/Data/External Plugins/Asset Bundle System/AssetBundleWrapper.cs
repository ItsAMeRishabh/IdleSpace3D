﻿using System;
using System.Threading.Tasks;
using UnityEngine;

namespace AssetBundles
{
  public sealed class AssetBundleWrapper : IDisposable
  {
    private AssetBundleWrapper()
    {
      assetBundleManager = new AssetBundleManager();
    }

    private static AssetBundleWrapper instance;

    private static AssetBundleWrapper GetInstance()
    {
      if (instance == null)
      {
        instance = new AssetBundleWrapper();
      }

      return instance;
    }

    private readonly AssetBundleManager assetBundleManager;

    #region INITIALIZATION
    /// <summary>
    /// Downloads the AssetBundle manifest and prepares the system for bundle management.
    /// </summary>
    /// <param name="baseURL"> Base URL to load assets.</param>
    /// <param name="useHash">Appends the hash name to bundle names before downloading. If you are using AssetBundleBrowser then you need to enable "Append Hash" in the advanced settings for this to</param>
    /// <param name="onCompleteHandler">Called when initialization is complete.</param>
    public static void Initialize(string baseURL, bool useHash = false, Action<bool> onCompleteHandler = null)
    {
      GetInstance()._Initialize(baseURL, useHash, false, onCompleteHandler);
    }

    public static void UseLocalServer(Action<bool> onCompleteHandler)
    {
      GetInstance()._UseLocalData(onCompleteHandler);
    }

    private void _UseLocalData(Action<bool> onCompleteHandler)
    {
      assetBundleManager.UseStreamingAssetsFolder()
        .AppendHashToBundleNames()
        .Initialize(onCompleteHandler);
    }

    /// <summary>
    /// Downloads the AssetBundle manifest and prepares the system for bundle management.
    /// </summary>
    public static void InitializeAsync(string baseURL, bool useHash = false)
    {
      GetInstance()._Initialize(baseURL, useHash, true, null);
    }

    private void _Initialize(string baseURL, bool useHash, bool isAsync, Action<bool> onCompleteHandler)
    {
      assetBundleManager.SetBaseUri(baseURL)
        .AppendHashToBundleNames(useHash);

      if (isAsync)
      {
        assetBundleManager.InitializeAsync();
      }
      else
      {
        assetBundleManager.Initialize(onCompleteHandler);
      }
    }
    #endregion

    #region LOADING BUNDLE
    public static void LoadBundle(string bundleName, Action<AssetBundle> onCompleteHandler = null, IProgress<float> progress = null)
    {
      GetInstance()._LoadBundle(bundleName, onCompleteHandler, progress);
    }

    private void _LoadBundle(string bundleName, Action<AssetBundle> onCompleteHandler, IProgress<float> progress)
    {
      assetBundleManager.GetBundle(bundleName, onCompleteHandler, progress);
    }
    #endregion

    #region GET ASSET FROM BUNDLE
    /// <summary>
    /// Gets asset from the loaded asset bundles.
    /// </summary>
    /// <typeparam name="T">Asset Type.</typeparam>
    /// <param name="assetName">Asset Name</param>
    /// <returns></returns>
    public static T GetAsset<T>(string assetName, string path = "") where T : UnityEngine.Object
    {
      return GetInstance()._GetAsset<T>(assetName, path);
    }

    /// <summary>
    /// Gets assets from the loaded asset bundles asynchronously.
    /// </summary>
    /// <typeparam name="T">Asset type</typeparam>
    /// <param name="assetName">Asset namae</param>
    /// <param name="onLoadAsset">On asset loaded.</param>
    public static void GetAssetAsync<T>(string assetName, Action<T> onLoadAsset) where T : UnityEngine.Object
    {
      GetInstance()._GetAssetAsync<T>(assetName, onLoadAsset);
    }

    private async void _GetAssetAsync<T>(string assetName, Action<T> onLoadAsset) where T : UnityEngine.Object
    {
      var enumerator = assetBundleManager.GetLoadedAssetBundles();
      foreach (var item in enumerator)
      {
        var request = await Task.Run(() => item.Value.AssetBundle.LoadAssetAsync<T>(assetName));
        onLoadAsset?.Invoke((T)request.asset);
      }
      onLoadAsset?.Invoke(null);
    }

    private T _GetAsset<T>(string assetName, string path = "") where T : UnityEngine.Object
    {
      var enumerator = assetBundleManager.GetLoadedAssetBundles();

      if (!string.IsNullOrEmpty(path))
      {
        foreach (var item in enumerator)
        {
          var bundle = item.Value.AssetBundle;
          if (bundle.name.Equals(path))
          {
            var asset = bundle.LoadAsset<T>(assetName);
            if (asset)
            {
              return asset;
            }
          }
        }
      }

      foreach (var item in enumerator)
      {
        var asset = item.Value.AssetBundle.LoadAsset<T>(assetName);
        if (asset)
        {
          return asset;
        }
      }

      return default;
    }
    #endregion

    #region UNLOAD BUNDLE
    public static void UnloadBundle(string bundleName, bool unloadAllLoadedObjects, bool force = false)
    {
      GetInstance()._UnloadBundle(bundleName, unloadAllLoadedObjects, force);
    }

    public static void UnloadBundle(AssetBundle assetBundle, bool unloadAllLoadedObjects)
    {
      GetInstance()._UnloadBundle(assetBundle, unloadAllLoadedObjects);
    }

    private void _UnloadBundle(AssetBundle assetBundle, bool unloadAllLoadedObjects)
    {
      assetBundleManager.UnloadBundle(assetBundle, unloadAllLoadedObjects);
    }

    private void _UnloadBundle(string bundleName, bool unloadAllLoadedObjects, bool force)
    {
      assetBundleManager.UnloadBundle(bundleName, unloadAllLoadedObjects, force);
    }
    #endregion

    void IDisposable.Dispose()
    {
      instance = null;
      assetBundleManager?.Dispose();
    }
  }
}
