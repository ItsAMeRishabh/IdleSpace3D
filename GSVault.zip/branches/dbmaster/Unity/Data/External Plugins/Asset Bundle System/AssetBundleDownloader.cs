﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using GS;
using GS.Data.Saving;
using GS.Events;
using GS.GameEvents;
using GS.Net;
using UnityEngine;
using UnityEngine.Networking;

namespace AssetBundles
{
  public struct AssetBundleDownloadCommand
  {
    public string BundleName;
    public Hash128 Hash;
    public uint Version;
    public IProgress<float> progress;
    public Action<AssetBundle> OnComplete;
        public Action OnDownloadAvailable;
        public float downloadTime;
        public bool retryBundleOnTimeUp;
    }

  public class AssetBundleDownloader : ICommandHandler<AssetBundleDownloadCommand>
  {
    private const int MAX_RETRY_COUNT = 3;
    private const float RETRY_WAIT_PERIOD = 1;
    private const int MAX_SIMULTANEOUS_DOWNLOADS = 4;
    private static readonly Hash128 DEFAULT_HASH = default;
    private static readonly long[] RETRY_ON_ERRORS = {
            503 // Temporary Server Error
        };

    private string baseURL;

    private Action<IEnumerator> coroutineHandler;

    private int activeDownloads = 0;
    private Queue<IEnumerator> downloadQueue = new Queue<IEnumerator>();
    private bool cachingDisabled;

    /// <summary>
    ///     Creates a new instance of the AssetBundleDownloader.
    /// </summary>
    /// <param name="baseUri">Uri to use as the base for all bundle requests.</param>
    public AssetBundleDownloader(string baseUri)
    {
      baseURL = baseUri;
      coroutineHandler = AssetBundleDownloaderMonobehaviour.Instance.HandleCoroutine;

      if (!baseURL.EndsWith("/"))
      {
        baseURL += "/";
      }
    }

    /// <summary>
    ///     Begin handling of a AssetBundleDownloadCommand object.
    /// </summary>
    public void Handle(AssetBundleDownloadCommand cmd)
    {
            //Debug.LogError($"TGL AssetBundleDownloader Handle called after StreamingAssetsBundleDownloadDecorator Handle failed. We hardcode retry count as 0 here.");
      InternalHandle(Download(cmd, 0));
    }

    private void InternalHandle(IEnumerator downloadCoroutine)
    {
      if (activeDownloads < MAX_SIMULTANEOUS_DOWNLOADS)
      {
        activeDownloads++;
        coroutineHandler(downloadCoroutine);
      }
      else
      {
        downloadQueue.Enqueue(downloadCoroutine);
      }
    }

        private void ShowLowNetworkPopup()
        {
            string title = null;
            string description = null;
            if (BaseUILocalization.checkLocalizeDataLoaded)
            {
                title = "Id_Pop_NoInternet_Error";
                description = "Id_Pop_NoInternet_Lostconnection";
            }
            else
            {
                title = "ERROR";
                description = "The game has lost connection. Please relaunch the game to restore connectivity";
            }
            Utils.EventSync(new UIPopUPEvent(title, description, () => Application.Quit()));
        }

        private float lastProgressRecorded = -1;
        private const int MAX_WAITINGTIME = 30;
        private bool isDownloadComplete = false;
        private float currentProgress = 0.0f;
        private IEnumerator AnyProgressHappening()
        {
            while (!isDownloadComplete)
            {
                yield return new WaitForSeconds(MAX_WAITINGTIME);
                if (!isDownloadComplete)
                {
                    if (currentProgress - lastProgressRecorded < 0.05f)
                    {
                        ShowLowNetworkPopup();
                        break;
                    }
                    lastProgressRecorded = currentProgress;
                }
            };
        }

    private IEnumerator Download(AssetBundleDownloadCommand cmd, int retryCount)
    {
        lastProgressRecorded = -1;
        isDownloadComplete = false;
        
        float seconds = Time.realtimeSinceStartup;
          // Debug.LogError($"TGL AssetBundleDownloader Download Called for base: {(baseURL == null? "null":baseURL)} and bundle {(cmd.BundleName == null? "null" : cmd.BundleName)}");
            var uri = baseURL + cmd.BundleName;
        // Debug.LogError($"TGL AssetBundleDownloader Download Called for URI {uri}");
          UnityWebRequest req;
          if (cachingDisabled || (cmd.Version <= 0 && cmd.Hash == DEFAULT_HASH))
          {
            Debug.LogError(string.Format("TGL (with caching disabled, or no versioning in hash key) GetAssetBundle [{0}].", uri));
            req = UnityWebRequestAssetBundle.GetAssetBundle(uri);
          }
          else if (cmd.Hash == DEFAULT_HASH)
          {
            Debug.LogError(string.Format("GetAssetBundle [{0}] v[{1}] [{2}].", Caching.IsVersionCached(uri, new Hash128(0, 0, 0, cmd.Version)) ? "cached" : "uncached", cmd.Version, uri));
            req = UnityWebRequestAssetBundle.GetAssetBundle(uri, cmd.Version, 0);
          }
          else
          {
            Debug.LogError(string.Format("GetAssetBundle [{0}] [{1}] [{2}].", Caching.IsVersionCached(uri, cmd.Hash) ? "cached" : "uncached", uri, cmd.Hash));

            req = UnityWebRequestAssetBundle.GetAssetBundle(uri, cmd.Hash, 0);
          }

          // Debug.LogError($"TGL Making request req({(req == null ? "" : "not ")}null) - {cmd.BundleName}");
          // Debug.LogError($"TGL Making request to download a asset from server at {req.uri} - {cmd.BundleName}");
          req.SendWebRequest();
          bool localDownloadCalled = false;
            Utils.EventSync(new StopCoroutineEvent(AnyProgressHappening()));
            Utils.EventSync(new StartCoroutineEvent(AnyProgressHappening()));
            while (req != null && !req.isDone)
            {
                if(currentProgress <= req.downloadProgress)
                {
                    cmd.progress?.Report(req.downloadProgress);
                }
                currentProgress = req.downloadProgress;

                if (cmd.downloadTime > 0.1f && cmd.downloadTime <= Time.time && !localDownloadCalled && !cmd.retryBundleOnTimeUp)
                {
                    // Debug.LogError($"TGL Bundle Name [{cmd.BundleName}] calling OnDownloadAvailable ({(cmd.OnDownloadAvailable == null ? "" : "not ")}null)");
                    cmd.OnDownloadAvailable?.Invoke();
                    localDownloadCalled = true;
                }
                else if (cmd.downloadTime > 0.1f && cmd.downloadTime <= Time.time && cmd.retryBundleOnTimeUp)
                {
                    if (req.downloadProgress <= SavingSystemConfigSO.Instance.minimumLoadPercentage)
                    {
                        // raise the event to show low network speed popup
                        // Debug.LogError($"TGL Bundle Name [{cmd.BundleName}] calling LowInternetSpeed.");
                        req.Dispose();
                        activeDownloads--;
                        ShowLowNetworkPopup();
                        //SongBeatTap.Constants.ShowNoInternet("ERROR", "The game has lost connection. Please relaunch the game to restore connectivity", () => Application.Quit(), false);//, "Exit game"); // button renamed to "Exit game"
                        //GS.EventManager.Instance.TriggerEvent(new LowInternetSpeed()); 
                        yield break;
                    }
                    else
                    {
                        // reattempt if the download percentage is high, but we could not finish in time limit
                        // Debug.LogError($"TGL disposing request with URI {req.uri} to redownload the bundle at time {Time.time} as the download is not finished in {(Time.time - cmd.downloadTime) + cmd.downloadTime} seconds");
                        req.Dispose();
                        activeDownloads--;
                        //yield return new WaitForSeconds(RETRY_WAIT_PERIOD);
                        InternalHandle(Download(cmd, retryCount + 1));
                        yield break;
                    }
                }
                yield return 0;
            }
            isDownloadComplete = true;

      float Totalseconds = Time.realtimeSinceStartup - seconds;

          // Debug.LogError($"TGL Total Seconds [{Time.realtimeSinceStartup}], bundle download time [{Totalseconds}] Bundle Name [{cmd.BundleName}] with version {cmd.Version} at URL [{req.uri}]");

            var isNetworkError = req.isNetworkError;
      var isHttpError = req.isHttpError;


      if (isHttpError)
      {
        Debug.LogError(string.Format("Error downloading [{0}]: [{1}] [{2}]", uri, req.responseCode, req.error));

        if (retryCount < MAX_RETRY_COUNT && RETRY_ON_ERRORS.Contains(req.responseCode))
        {
          Debug.LogWarning(string.Format("Retrying [{0}] in [{1}] seconds...", uri, RETRY_WAIT_PERIOD));
          req.Dispose();
          activeDownloads--;
          yield return new WaitForSeconds(RETRY_WAIT_PERIOD);
          InternalHandle(Download(cmd, retryCount + 1));
          yield break;
        }
        else
				{
                  // Debug.LogError($"TGL max retry count reached for [{req.uri}] i.e., {MAX_RETRY_COUNT}, so this download is considered a failure");
                }
      }

      AssetBundle bundle;

      if (isNetworkError)
      {
        Debug.LogError(string.Format("Error downloading [{0}]: [{1}]", uri, req.error));
        bundle = null;
      }
      else
      {
        bundle = DownloadHandlerAssetBundle.GetContent(req);
        // Debug.Log("Succesfully downloaded  -> " + uri);
      }

      if (!isNetworkError && !isHttpError && string.IsNullOrEmpty(req.error) && bundle == null)
      {
        if (cachingDisabled)
        {
          Debug.LogWarning(string.Format("There was no error downloading [{0}] but the bundle is null.  Caching has already been disabled, not sure there's anything else that can be done.  Returning...", uri));
        }
        else
        {
          Debug.LogWarning(string.Format("There was no error downloading [{0}] but the bundle is null.  Assuming there's something wrong with the cache folder, retrying with cache disabled now and for future requests...", uri));
          cachingDisabled = true;
          req.Dispose();
          activeDownloads--;
          yield return new WaitForSeconds(RETRY_WAIT_PERIOD);
          InternalHandle(Download(cmd, retryCount + 1));
          yield break;
        }
      }

      try
      {
              // Debug.LogError($"TGL try block called with bundle({(bundle == null ? "" : "not ")}null) Bundle Name [{cmd.BundleName}]");
        cmd.OnComplete(bundle);
      }
      finally
      {
              // Debug.LogError($"TGL finally block, disposing the request({(req == null ? "" : "not ")}null) in downloadQueue({(downloadQueue == null ? "" : "not ")}null) Bundle Name [{cmd.BundleName}]");
                req.Dispose();

        activeDownloads--;

        if (downloadQueue!= null && downloadQueue.Count > 0)
        {
                    if (downloadQueue.Peek() != null)
                    {
                        InternalHandle(downloadQueue.Dequeue());
                    }
                    else
					{
                      // Debug.LogError($"TGL downloadQueue.Peek() gave a null Bundle Name [{cmd.BundleName}]");
                    }
        }
        else
				{
                  // Debug.LogError($"TGL downloadQueue gave a null or downloadQueue.Count is not more than 0 Bundle Name [{cmd.BundleName}]");
                }
      }
    }
  }
}
