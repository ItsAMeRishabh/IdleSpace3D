﻿namespace AssetBundles
{
  public enum DownloadSettings
  {
    UseCacheIfAvailable,
    DoNotUseCache
  }

  public enum PrioritizationStrategy
  {
    PrioritizeRemote,
    PrioritizeStreamingAssets,
  }

  public enum PrimaryManifestType
  {
    None,
    Remote,
    RemoteCached,
    StreamingAssets,
  }
}
