﻿using UnityEngine;

#if NET_4_6
#endif

namespace AssetBundles
{
  public sealed partial class AssetBundleManager
  {
    public class AssetBundleContainer
    {
      public AssetBundle AssetBundle;
      public int References = 1;
      public string[] Dependencies;
    }
  }
}
