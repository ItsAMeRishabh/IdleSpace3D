﻿using System;
using UnityEngine;

#if NET_4_6
#endif

namespace AssetBundles
{
  public sealed partial class AssetBundleManager
  {
    public class DownloadInProgressContainer
    {
      public int References;
      public IProgress<float> progress;
      public Action<AssetBundle> OnComplete;

      public DownloadInProgressContainer(Action<AssetBundle> onComplete, IProgress<float> progress = null)
      {
        References = 1;
        this.progress = progress;

        if (onComplete != null)
        {
          OnComplete = onComplete;
        }
        else
        {
          OnComplete = (bundle) => { };
        }
      }
    }
  }
}
