﻿using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace AssetBundleSystem.Data
{
  #region SCRIPTABLE OBJECT CLASS
  [CreateAssetMenu(fileName = "Sprite Sheet Data", menuName = "Scriptable Objects/Sprite Sheet Data", order = 0)]
  [System.Serializable]
  public class SpriteSheetData : ScriptableObject
  {
    [SerializeField]
    private Texture2D texture;

    [SerializeField]
    private List<SheetData> spritesTable;

    public IEnumerator<SheetData> GetEnumerator()
    {
      if (spritesTable != null)
      {
        return spritesTable.GetEnumerator();
      }

      return null;
    }

    /// <summary>
    /// Gets all sprites from the database.
    /// </summary>
    /// <returns>Array of sprites</returns>
    public Sprite[] GetSprites()
    {
      if (spritesTable == null)
      {
        return new Sprite[0];
      }

      List<Sprite> sprites = new List<Sprite>(spritesTable.Count);

      var enumerator = spritesTable.GetEnumerator();

      while (enumerator.MoveNext())
      {
        sprites.Add(enumerator.Current.Sprite);
      }

      return sprites.ToArray();
    }

    /// <summary>
    /// Searches for the sprite based on the name.
    /// </summary>
    /// <param name="name">Sprite name</param>
    /// <returns>Sprite</returns>
    public Sprite GetSprite(string name)
    {
      if (spritesTable == null)
      {
        return Default();
      }

      var sheet = spritesTable.Find(x => x.Name.Equals(name));
      if (sheet != null)
      {
        return sheet.Sprite;
      }

      return Default();
    }

    /// <summary>
    /// Gets sprite from the given index
    /// </summary>
    /// <param name="index">Index</param>
    /// <returns>Sprite</returns>
    public Sprite GetSprite(int index)
    {
      if (spritesTable == null || index > spritesTable.Count - 1)
      {
        return Default();
      }

      return spritesTable[index].Sprite;
    }

    private Sprite Default()
    {
      return Sprite.Create(Texture2D.whiteTexture, Rect.zero, Vector2.zero); ;
    }

#if UNITY_EDITOR

    private void OnEnable()
    {
      var selectedTexture = Selection.activeObject as Texture2D;

      if (selectedTexture != null)
      {
        this.texture = selectedTexture;
        LoadSprites();
        EditorUtility.SetDirty(this);
      }
    }

    /// <summary>
    /// This is editor script, please do not use in non-editor scripts.
    /// </summary>
    public void LoadSprites()
    {
      var path = AssetDatabase.GetAssetPath(texture);
      int index = path.IndexOf("/Assets") + 1;
      _ = path.Substring(index);

      var sprites = AssetDatabase.LoadAllAssetsAtPath(path);

      spritesTable = new List<SheetData>(sprites.Length);

      foreach (var item in sprites)
      {
        if (item is Sprite sprite)
        {
          if (sprite)
          {
            spritesTable.Add(new SheetData(sprite.name, sprite));
          }
        }
      }
    }

#endif
  }

  #endregion

  #region EDITOR CLASS

#if UNITY_EDITOR

  [CustomEditor(typeof(SpriteSheetData))]
  [DisallowMultipleComponent]
  public class SpriteSheetDataEditor : Editor
  {
    SpriteSheetData _target;

    private void OnEnable()
    {
      _target = (SpriteSheetData)target;
    }

    public override void OnInspectorGUI()
    {
      EditorGUILayout.BeginVertical();
      serializedObject.Update();

      var texture = serializedObject.FindProperty("texture");
      EditorGUILayout.PropertyField(texture);

      if (texture.objectReferenceValue)
      {
        if (GUILayout.Button("UPDATE", EditorStyles.miniButtonLeft))
        {
          _target.LoadSprites();
          EditorUtility.SetDirty(_target);
        }

        var enumerator = _target.GetEnumerator();
        if (enumerator != null)
        {
          DrawItems(enumerator);
        }
      }

      serializedObject.ApplyModifiedProperties();
      EditorGUILayout.EndVertical();
    }

    private void DrawItems(IEnumerator<SheetData> enumerator)
    {
      while (enumerator.MoveNext())
      {
        SheetData sheetData = enumerator.Current;
        Texture2D texture = AssetPreview.GetAssetPreview(sheetData.Sprite);
        GUILayout.Label(texture);
        EditorGUILayout.LabelField(sheetData.Name, EditorStyles.helpBox);
      }
    }
  }

#endif

  #endregion

  #region DATA CLASS
  [System.Serializable]
  public class SheetData
  {
    public string Name { get { return name; } }
    public Sprite Sprite { get { return sprite; } }

    [SerializeField]
    private string name;

    [SerializeField]
    private Sprite sprite;

    public SheetData(string name, Sprite sprite)
    {
      this.name = name;
      this.sprite = sprite;
    }
  }

  #endregion
}