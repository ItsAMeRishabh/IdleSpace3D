﻿using System;
using GS.Data;
using GS.GameEvents;
using GS.Net;
using GS.Net.Transactions;
using GS.Unity;
using UnityEngine.SceneManagement;

namespace GS
{
    public class MainEntry<TSettingType, TPacketType> : SingleTon<MainEntry<TSettingType, TPacketType>>
        where TSettingType : Enum
        where TPacketType : Enum
    {
        protected GameManagerController<TSettingType> gameController;

        public virtual void Awake()
        {
            gameController = new GameManagerController<TSettingType>();
            gameController.Initialize();
            gameController.RegisterListener();

            SetDiagnosticEnv();
            SavingSystemConfigSO.Initialize();
            Log.Initialize(
                new GS.Unity.UnityLogger(),
                LogFilter.Network
                    | LogFilter.Default
                    | LogFilter.Error
                    | LogFilter.GameEvent
                    | LogFilter.Game
                    | LogFilter.Network
                    | LogFilter.UI
            );

            DoNotDestroyOnLoad = true;
            SceneManager.sceneLoaded += OnSceneLoaded;
            IntializeAppControllers();

            BaseTransactionsHolder<TPacketType>.Initialize();
        }

        private void SetDiagnosticEnv()
        {
#if Production
            UnityEngine.CrashReportHandler.CrashReportHandler.SetUserMetadata(
                "Enviroment",
                "Production"
            );
# elif UNITY_EDITOR
            UnityEngine.CrashReportHandler.CrashReportHandler.SetUserMetadata(
                "Enviroment",
                "UNITY_EDITOR"
            );
#else
            UnityEngine.CrashReportHandler.CrashReportHandler.SetUserMetadata("Enviroment", "QA15");
#endif
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode sceneLoadMode)
        {
            if (sceneLoadMode == LoadSceneMode.Single)
            {
                if (gameController != null)
                {
                    gameController.RegisterListener();
                    gameController.RegisterAllAppController();
                }
            }
            // Raise Level LoadedEvent
            Utils.EventSync(new GameEvents.LevelLoadedEvent(scene, sceneLoadMode));
        }

        private void OnApplicationQuit() { }

        /// <summary>
        /// Adding all app controllers here.
        /// These controllers available throughout game
        /// </summary>
        public virtual void IntializeAppControllers()
        {
            gameController.AddAppController(new LevelLoadManagerController<TSettingType, TPacketType>());
            gameController.AddAppController(new MonoHelperController<TSettingType, TPacketType>());
            gameController.AddAppController(new SaveManagerController());
            gameController.AddAppController(new DataController());
            //gameController.AddAppController(new UserProfileController());
            //gameController.AddAppController(new RewardController());
            //gameController.AddAppController(new PluginManagerController());
            //gameController.AddAppController(new StoreController());
            //gameController.AddAppController(new NetworkController());
        }

        protected virtual void RaiseDataSetUpCompletedEvent()
        {
            // As 'DataInit' is done, other controllers can requests/register for data events
            Utils.EventAsync(new DataInitializationDoneEvent(true));
        }

        public virtual void Update()
        {
            if (gameController != null)
                gameController.Update();
        }

        public override void OnDestroy()
        {
            if (gameController == null)
                return;

            gameController.UnRegisterListener();
            gameController.Release();
        }
    }
}
