﻿using UnityEngine;
using System.Collections;

namespace GS.Unity
{
    /// <summary>
    /// Handles scene loading in Unity Engine
    /// </summary>
    public class LevelLoadManager<TSettingType, TPacketType>
        where TSettingType : System.Enum
        where TPacketType : System.Enum
    {

        #region Varibales

        /// <summary>
        /// Loading Scene Name
        /// </summary>
        public string loadingSceneName { get { return "Loading"; } }

        /// <summary>
        /// To store name of the scene to be loaded locally.
        /// </summary>
        string sceneToLoad;


        /// <summary>
        /// 'LoadingSceneProgress' script object, it should be attached to Canvas object in Scene
        /// </summary>
        LoadingSceneProgress loadingSceneProgress;

        #endregion Varibales


        /// <summary>
        /// Constructor
        /// </summary>
        public LevelLoadManager()
        {
            sceneToLoad = "";

        }

        /// <summary>
        /// used to switch scenes, loading scene will be loaded in between scene transision, if showLoadingScene is true.
        /// </summary>
        /// <param name="sceneName">Name of the Scene to be loaded</param>
        /// <param name="showLoadingScene">Is Loading scene required to display while loading main scene</param>
        public void LoadScene(string sceneName, bool showLoadingScene = false)
        {
            // store sceneName locally.
            sceneToLoad = sceneName;

            Utils.EventSync(new GameEvents.ChangeGameState(GameConsts.GameState.Loading));
            
            if (showLoadingScene)
            {
                // Loading scene is required.
                Utils.EventSync(new GameEvents.StartCoroutineEvent(LoadLevel(loadingSceneName)));
            }
            else
            {
                // Directly load scene with out loading scene.
                Utils.EventSync(new GameEvents.StartCoroutineEvent(LoadLevel(sceneToLoad)));
            }
        }

        /// <summary>
        /// Checks loading progress and returns the status as boolean.
        /// 1. Removes loadingUI Once loading is done.
        /// </summary>
        /// <returns></returns>
        public bool isLoadingCompleted()
        {
            if (loadingSceneProgress == null)
                return true;

            if (loadingSceneProgress.totalLoadProgress >= 100)
            {
                loadingSceneProgress.DestroyLoadingProgress();
                loadingSceneProgress = null;
                return true;
            }

            return false;
        }


        #region Callbacks

        /// <summary>
        /// Callback for 'onSceneLoaded' which gets called after scene loaded.
        /// </summary>
        /// <param name="level"></param>
        public void onSceneWasLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode sceneMode)
        {
            if (scene.name == loadingSceneName)
            {
                // TODO : Remove LoadingSceneProgress class here and pass it from outside
                loadingSceneProgress = MonobehaviourHelper.FindObjectOfType<LoadingSceneProgress>();

                if (loadingSceneProgress != null)
                {
                    // Make this gameObject to stay even after scene changed
                    loadingSceneProgress.SetDontDestroyOnLoad();
                }


                // TODO : Implement using Data Event instead of Resources.Load
                //Resources.Load<Animator>();

                // As 'Loading Scene' is loaded, start loading required scene now.
                LoadScene(sceneToLoad);
            }
            else if (scene.name == sceneToLoad)
            {
                // Get Progress of SceneHandler here.
                // TODO : Get SceneHandler here. 'FindObjectOfType' will consume lot of time
                // Implement in different manner
                SceneHandler<TSettingType, TPacketType> sceneHandler = MonoHelper.FindObjectOfType<SceneHandler<TSettingType, TPacketType>>();

                if (sceneHandler != null)
                {
                    if (loadingSceneProgress != null)
                        sceneHandler.initProgressCallback += loadingSceneProgress.setSceneHandlerInitProgress;
                }
                else
                {
                    // As we dont find sceneHandler in current scene, set sceneHandler progress as '100'
                    // Otherwise loadingUI will wait for it.
                    loadingSceneProgress.setSceneHandlerInitProgress(100);
                }
            }
        }

        /// <summary>
        /// callback for Getting 'Loading Scene UI prefab'
        /// </summary>
        /// <param name="obj"></param>
        void onUIPrefabLoaded(GameObject obj)
        {
            if (obj == null)
            {
                Log.Error("Level Loading UI prefab is NULL");
                return;
            }

            InitUIPrefab(obj);
        }



        #endregion Callbacks


        #region Internal members

        /// TODO : Implement IN Proper Manner
        /// <summary>
        /// creates the loading ui gameobject in loading screen.
        /// attaches LoadingUI component to it and assigns it to loadingUIComponent variable.
        /// </summary>
        private void InitUIPrefab(GameObject uiPrefab)
        {
            /*  if (uiPrefab == null)
                  return;

              // Set parent transform and Sibling index
              //if (loadingSceneProgress != null)
              {
                  GameObject customLoadingUI = MonobehaviourHelper.Instantiate(uiPrefab, (loadingSceneProgress != null) ? loadingSceneProgress.transform : null);

                  // This will make sure newly Instantiated UI will appear over deafultUI
                  customLoadingUI.transform.SetAsLastSibling();
              }*/
        }



        /// <summary>
        /// loads the specified scene in a new thread.
        /// </summary>
        /// <param name="sceneName"></param>
        IEnumerator LoadLevel(string sceneName)
        {
#if STAGING
            Log.Print("Loading Other Level named, " + sceneName, LogFilter.Game);
#endif

            AsyncOperation async = null;
            if (!string.IsNullOrEmpty(sceneName))
            {
                async = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(sceneName);

                while (!async.isDone)
                {
                    // Sending Scene Loading Progress to Default UI
                    if (loadingSceneProgress != null)
                        loadingSceneProgress.setSceneCompleteProgress(async.progress);
                    yield return null;
                }
            }
            else
            {
                Log.Error("No Level name provided to load");
            }

            //yield return null;
        }



        #endregion Internal members

    }

}