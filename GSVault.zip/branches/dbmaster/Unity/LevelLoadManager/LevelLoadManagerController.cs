﻿using System;

namespace GS
{
    namespace Unity
    {
        public class LevelLoadManagerController<TSettingType, TPacketType> : IController
            where TSettingType : Enum
            where TPacketType : Enum
        {
            #region Variables

            LevelLoadManager<TSettingType, TPacketType> levelLoadManager;

            /// <summary>
            /// Does loading progress check required to calculate in 'Update()'
            /// </summary>
            bool isLoadingCheckRequired;

            #endregion Variables


            #region Interface Members

            public void Initialize()
            {
                if (levelLoadManager == null)
                    levelLoadManager = new LevelLoadManager<TSettingType, TPacketType>();

               // RegisterListener();
            }

            public void RegisterListener()
            {
                EventManager.Instance.AddListener<GameEvents.LoadSceneEvent>(onLoadSceneEvent);
                EventManager.Instance.AddListener<GameEvents.LevelLoadedEvent>(onSceneLoaded);
            }

            public void Release()
            {
                UnRegisterListener();
            }

            public void UnRegisterListener()
            {
                EventManager.Instance.RemoveListener<GameEvents.LoadSceneEvent>(onLoadSceneEvent);
                EventManager.Instance.RemoveListener<GameEvents.LevelLoadedEvent>(onSceneLoaded);
            }

            public void Update()
            {
                if (isLoadingCheckRequired)
                {
                    if (levelLoadManager == null)
                        return;

                    // No need to cal this update function once 'isLoadingCompleted()'
                    isLoadingCheckRequired = !levelLoadManager.isLoadingCompleted();
                }
            }

            #endregion Interface Members


            #region Event Listners

            /// <summary>
            /// callback of LoadLevel Event
            /// </summary>
            /// <param name="eve"></param>
            void onLoadSceneEvent(GameEvents.LoadSceneEvent eve)
            {
                if (eve == null || levelLoadManager == null)
                    return;

                NetworkUtils.Instance.StartCoroutine(NetworkUtils.WaitUntilSyncComplete(NetworkUtils.Instance.ForceCheckInternet(() =>
                {
                    levelLoadManager.LoadScene(eve.sceneName, eve.isLoadingSceneRequired);
                })));
            }

            /// <summary>
            /// callback of LevelLoaded Event
            /// </summary>
            /// <param name="eve"></param>
            void onSceneLoaded(GameEvents.LevelLoadedEvent eve)
            {
                if (eve == null || levelLoadManager == null)
                    return;

                levelLoadManager.onSceneWasLoaded(eve.scene, eve.sceneMode);

                if (eve.scene.name == levelLoadManager.loadingSceneName)
                {
                    isLoadingCheckRequired = true;
                }
            }

            #endregion

        }
    }
}