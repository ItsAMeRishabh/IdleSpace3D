﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// This interface used to get the level loaing progress in LevelLoadManager class 
/// </summary>
public interface ISceneProggress 
{
    /// <summary>
    /// Total Progress
    /// </summary>
    /// <returns></returns>
    float GetTotalProgress();

    /// <summary>
    /// Set the loading progress 
    /// </summary>
    /// <param name="progress"></param>
    void setSceneCompleteProgress(float progress);

    /// <summary>
    /// Sets Scene Loading Progress Handler
    /// </summary>
    /// <param name="progress"></param>
    void setSceneHandlerInitProgress(float progress);

    /// <summary>
    /// Set scene to not to destroy
    /// </summary>
    void SetDontDestroyOnLoad();
    /// <summary>
    /// Implenent here to destroy gameobject 
    /// </summary>
    void Destroy();
}
