﻿using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    [CreateAssetMenu(menuName = "FormatConfig", fileName = "FormatConfig")]
    public class FormatConfig : ScriptableObject
    {
        public List<FormatData> formatData;

        public FormatData GetFormat(string key)
        {
            if (formatData == null)
                return null;

            FormatData fdata = null;

            for (int i = 0; i < formatData.Count; i++)
            {
                if (formatData[i].key.Equals(key))
                {
                    fdata = formatData[i];
                    break;
                }
            }
            return fdata;
        }
    }
}
