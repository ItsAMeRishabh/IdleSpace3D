﻿using UnityEditor;
using UnityEngine;

namespace GS
{
    [CustomPropertyDrawer(typeof(ParameterInfo))]
    public class ParameterInfoDrawer : PropertyDrawer
    {

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            //base.OnGUI(position,property,label);
            EditorGUI.BeginProperty(position, label, property);
            //EditorGUILayout.BeginHorizontal();
            position = EditorGUI.PrefixLabel(position, GUIUtility.GetControlID(FocusType.Passive), label);
            var indent = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;
            var keyRect = new Rect(position.x - Screen.width * 0.19f, position.y, Screen.width * 0.2f, position.height);
            var separatorRect = new Rect(position.x + Screen.width * 0.02f, position.y, Screen.width * 0.18f, position.height);
            var customRect = new Rect(position.x + Screen.width * 0.22f, position.y, Screen.width * 0.1f, position.height);

            EditorGUI.PropertyField(keyRect, property.FindPropertyRelative("paramName"), GUIContent.none);
            SerializedProperty prop = property.FindPropertyRelative("dataType");
            
            EditorGUI.PropertyField(separatorRect, prop, GUIContent.none);

            if (DataType.INT_FOR == (DataType)prop.intValue)
            {
                EditorGUI.PropertyField(customRect, property.FindPropertyRelative("custom"), GUIContent.none);
            }

            EditorGUI.indentLevel = indent;

            EditorGUI.EndProperty();
        }
    }


    [CustomPropertyDrawer(typeof(FormatData))]
    public class FormatDataDrawer : PropertyDrawer
    {

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            //base.OnGUI(position,property,label);
            EditorGUI.BeginProperty(position, label, property);
            //EditorGUILayout.BeginHorizontal();
            position = EditorGUI.PrefixLabel(position, GUIUtility.GetControlID(FocusType.Passive), label);
            var indent = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;
            var keyRect = new Rect(position.x - Screen.width * 0.17f, position.y, Screen.width * 0.26f, position.height);
            
            
            EditorGUI.PropertyField(keyRect, property.FindPropertyRelative("key"), GUIContent.none);
            var rectText = new Rect(position.x + Screen.width * 0.1f, position.y, Screen.width * 0.2f, position.height);
            EditorGUI.LabelField(rectText, new GUIContent("Seperator"));

            var separatorRect = new Rect(position.x + Screen.width * 0.25f, position.y, Screen.width * 0.1f, position.height);
            EditorGUI.PropertyField(separatorRect, property.FindPropertyRelative("seperators"), GUIContent.none);

            //EditorGUI.PropertyField(paramRect, property.FindPropertyRelative("Parameters"), GUIContent.none,true);
            //EditorGUI.PropertyField(paramRect, property.FindPropertyRelative("Parameters").FindPropertyRelative("paramName"), GUIContent.none, true);

            EditorGUI.indentLevel = indent;

            EditorGUI.EndProperty();
        }
    }
}