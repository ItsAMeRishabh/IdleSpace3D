﻿using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditorInternal;


namespace GS
{
    [UnityEditor.CustomEditor(typeof(FormatConfig))]
    public class CustomValidatorEditor : Editor
    {
        private SerializedProperty formatDataClass;
        private ReorderableList list;

        private Dictionary<string, ReorderableList> innerListDict = new Dictionary<string, ReorderableList>();

        private void OnEnable()
        {
            formatDataClass = serializedObject.FindProperty("formatData");
            list = new ReorderableList(serializedObject, formatDataClass)
            {
                displayAdd = true,
                displayRemove = true,
                draggable = true,
                drawHeaderCallback = rect =>
                {
                    EditorGUI.LabelField(rect, "API Formats");
                },
                drawElementCallback = (rects, indexs, a, h) =>
                {
                    SerializedProperty element = list.serializedProperty.GetArrayElementAtIndex(indexs);
                    EditorGUI.PropertyField(position: new Rect(rects.x, rects.y, Screen.width * .2f, height: EditorGUIUtility.singleLineHeight), property: element, label: new GUIContent("API Key"), includeChildren: true);
                    var InnerList = element.FindPropertyRelative("parameters");

                    string listKey = element.propertyPath;
                    ReorderableList innerReorderableList;

                    if (innerListDict.ContainsKey(listKey))
                    {
                        innerReorderableList = innerListDict[listKey];
                    }
                    else
                    {
                        innerReorderableList = new ReorderableList(element.serializedObject, InnerList)
                        {
                            displayAdd = true,
                            displayRemove = true,
                            draggable = true,

                            drawHeaderCallback = innerRect =>
                            {
                                EditorGUI.LabelField(innerRect, element.FindPropertyRelative("key").stringValue);
                            },

                            drawElementCallback = (innerRect, innerIndex, innerA, innerH) =>
                            {
                                var innerElement = InnerList.GetArrayElementAtIndex(innerIndex);

                                var name = innerElement.FindPropertyRelative("paramName");

                                //EditorGUI.PropertyField(innerRect, name);
                                //EditorGUI.PropertyField(new Rect(innerRect.x, innerRect.y += 20, Screen.width * .8f, height: EditorGUIUtility.singleLineHeight), innerElement.FindPropertyRelative("dataType"));

                                EditorGUI.PropertyField(position: new Rect(innerRect.x, innerRect.y, Screen.width * .2f, height: EditorGUIUtility.singleLineHeight), property: innerElement, label: new GUIContent("Field"), includeChildren: true);

                            },
                            elementHeightCallback = index =>
                            {
                                float propertyHeight = EditorGUI.GetPropertyHeight(InnerList.GetArrayElementAtIndex(index), true);

                                float spacing = EditorGUIUtility.singleLineHeight / 2;

                                return propertyHeight + spacing;
                            },


                        };
                        innerListDict[listKey] = innerReorderableList;
                    }

                    //var height = (InnerList.arraySize + 3) * EditorGUIUtility.singleLineHeight;
                    innerReorderableList.DoLayoutList();//.DoList(new Rect(rects.x, rects.y + (EditorGUIUtility.singleLineHeight * 3), Screen.width * .8f, height: height * 2));
                },


                elementHeightCallback = index =>
                {
                    float propertyHeight = EditorGUI.GetPropertyHeight(list.serializedProperty.GetArrayElementAtIndex(index), true);
                    //propertyHeight = 43f;
                    float spacing = EditorGUIUtility.singleLineHeight / 2;
                    return propertyHeight + spacing;
                },

                onAddCallback = list =>
                {
                    var index = list.serializedProperty.arraySize;
                    list.serializedProperty.arraySize++;
                    list.index = index;
                    var element = list.serializedProperty.GetArrayElementAtIndex(index);
                }
            };
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            list.DoLayoutList();

            serializedObject.ApplyModifiedProperties();
        }
    }
}