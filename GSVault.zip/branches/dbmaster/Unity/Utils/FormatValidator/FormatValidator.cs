﻿
using UnityEngine;

namespace GS
{
    /// <summary>
    /// Validates format of any packet as per formats which are defined in FormatConfig scriptable object
    /// </summary>
    public class FormatValidator
    {
        public enum TokenReturnCode
        {
            Error,
            Valid,
            LoopType
        }


        private FormatConfig config;

        public bool Initialize(string filePath)
        {
            config = Resources.Load<FormatConfig>(filePath);
            return config != null;
        }


        private TokenReturnCode ProcessToken(string token, FormatData format, int fid)
        {
            DataType dataType = format.parameters[fid].dataType;
         //   Debug.Log("" + format.parameters[fid].paramName + " = " + token + ", Type : " + dataType + " , FID : "+ fid);
            switch (dataType)
            {
                case DataType.INT:
                    {
                        int res;
                        if (!int.TryParse(token, out res))
                        {
                            Log.Error("" + format.parameters[fid].paramName + " = " + token + ", Type : " + dataType + " , FID : " + fid);
                            return TokenReturnCode.Error;
                        }
                        break;
                    }
                case DataType.FLOAT:
                    float flVal;
                    if (!float.TryParse(token, out flVal))
                        return TokenReturnCode.Error;
                    break;
                case DataType.DOUBLE:
                    double dlVal;
                    if (!double.TryParse(token, out dlVal))
                        return TokenReturnCode.Error;
                    break;

              
                case DataType.BOOL:
                    int boolVal;
                    bool textVal;
                    if (!int.TryParse(token, out boolVal) && !bool.TryParse(token, out textVal))
                        return TokenReturnCode.Error;
                    break;

                case DataType.INT_FOR:
                    int forloopCnt;
                    if (!int.TryParse(token, out forloopCnt))
                        return TokenReturnCode.Error;
                    else
                        return TokenReturnCode.LoopType;
                case DataType.STRING:
                default:
                    
                    break;
            }
            return TokenReturnCode.Valid;
        }

        void PrintError(string error)
        {
            Log.Error("Failed : " + error);
        }

        private int ValidateByDataType(string[] tokens, int from, int to, FormatData format, int startFormatIndex, int maxFormatCount, int fid)
        {
            
            int i = from;

            while (i < to)
            {
                string val = tokens[i];
              
                TokenReturnCode code = ProcessToken(val, format, fid);
                switch(code)
                {
                    case TokenReturnCode.Error:
                        return -1 * i;
                    case TokenReturnCode.Valid:
                        fid++;
                        i++;
                        if (maxFormatCount > 0)
                        {
                            if (fid >= startFormatIndex + maxFormatCount)
                                fid = startFormatIndex;
                        }
                        break;
                    case TokenReturnCode.LoopType:
                        ParameterInfo info = format.parameters[fid];
                        int cnt;
                        if (!int.TryParse(val, out cnt))
                            return -1 * i;
                        
                        int totalElements = info.custom * cnt;
                        //maxFormatCount += totalElements;
                        fid++;
                        // Debug.LogError("Before Recursive ");
                        int prevFid = fid;
                        i = ValidateByDataType(tokens, i + 1, i + totalElements + 1, format, fid, info.custom, fid);
                        fid = prevFid + info.custom;
                       // Debug.LogError("After Recursive ");
                        if (maxFormatCount > 0)
                        {
                            if (cnt > 0)
                            {
                                to += cnt - 1;
                                if (to >= tokens.Length)
                                    to = tokens.Length;
                            }

                            

                            if (fid >= startFormatIndex + maxFormatCount)
                                fid = startFormatIndex;
                        }
                        break;
                }

                
                if (i < 0)
                    break;
            }
            return i;
        }

        public bool Validate(string key, string data)
        {            
            if (config == null)
            {
                PrintError("Format Config file not found....");
                return false;
            }
            else if(string.IsNullOrEmpty(data))
            {
                PrintError("Data cannot be empty or null");
                return false;
            }

            FormatData format = config.GetFormat(key);
            if (format == null || format.seperators == null || format.seperators.Length == 0)
            {
                PrintError("Configure format in config file for the key : " + key);
                return false;
            }

            string[] tokens = data.Split(format.seperators[0]);

            if (tokens.Length < format.parameters.Count)
            {
                PrintError("Data length is not enough to parse");
                return false;
            }
            Log.Print("No of Tokens Length : " + tokens.Length, LogFilter.Data);

            int errCode = ValidateByDataType(tokens, 0, tokens.Length, format, 0, 15, 0);
            if (errCode < 0)
            {
                PrintError("Data format mismatch at element no :" + (errCode * -1));
                return false;
            }
            Log.Print("Validation : SUCCESS", LogFilter.Data);
            return true;
        }

    }


}