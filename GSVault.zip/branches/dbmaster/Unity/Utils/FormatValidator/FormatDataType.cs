﻿
using System.Collections.Generic;
using UnityEngine;

namespace GS
{
    public enum DataType
    {
        STRING,
        INT,
        FLOAT,
        DOUBLE,
        BOOL,
        INT_FOR
    }

    [System.Serializable]
    public class ParameterInfo
    {
        public string paramName;
        public DataType dataType;
        public int custom = 0;
    }

    [System.Serializable]
    public class FormatData
    {
        public string key;
        public string seperators;
        public List<ParameterInfo> parameters;
    }
}
