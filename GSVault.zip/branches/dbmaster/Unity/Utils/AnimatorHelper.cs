﻿
using System;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Unity
{
    public class AnimatorHelper<T> where T : struct, IConvertible
    {
        private Animator animator;
        private Dictionary<T, int> hashKeys = new Dictionary<T, int>();
        private const int INVALID = -9999;

        public void Initialize(Animator animator)
        {
            this.animator = animator;

            Type type = typeof(T);
            if (!type.IsEnum)
                throw new ArgumentException("AnimationHelper<T> -- here T must be an enumerated type");

            foreach (T key in Enum.GetValues(type))
            {
                hashKeys.Add(key, Animator.StringToHash(key.ToString()));
            }
        }

        public void SetInteger(T key, int val)
        {
            if(hashKeys.ContainsKey(key))
                animator?.SetInteger(hashKeys[key], val);
        }

        public int GetInteger(T key)
        {
            if (animator != null && hashKeys.ContainsKey(key))
                return animator.GetInteger(hashKeys[key]);
            return INVALID;
        }

        public void SetFloat(T key, float val)
        {
            if (hashKeys.ContainsKey(key))
                animator?.SetFloat(hashKeys[key], val);
        }

        public float GetFloat(T key)
        {
            if (animator != null && hashKeys.ContainsKey(key))
                return animator.GetFloat(hashKeys[key]);
            return INVALID;
        }

        public void SetBool(T key, bool val)
        {
            if (hashKeys.ContainsKey(key))
                animator?.SetBool(hashKeys[key], val);
        }

        public bool GetBool(T key)
        {
            if (animator != null && hashKeys.ContainsKey(key))
                return animator.GetBool(hashKeys[key]);
            return false;
        }
    }
}
