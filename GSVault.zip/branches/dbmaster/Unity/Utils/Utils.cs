﻿using UnityEngine;
using System.Collections.Generic;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Reflection;

namespace GS
{
    //This class is useful for most of common tasks which we are going to use in scripts
    public static class UnityExtensions
    {
        public static Vector3 GetUIWorldPosition(Transform uiTransform)
        {
            return uiTransform.transform.position;
        }

        /// <summary>
        /// Gets or Adds a component of Type T.
        /// </summary>
        /// <returns>The or add component.</returns>
        /// <param name="child">Child.</param>
        /// <typeparam name="T">The 1st type parameter.</typeparam>
        public static T GetOrAddComponent<T>(this Component child)
            where T : Component
        {
            T result = child.GetComponent<T>();
            if (result == null)
                result = child.gameObject.AddComponent<T>();
            return result;
        }

        /// <summary>
        /// Actives or Deactive the gameObject which has called this function.
        /// </summary>
        /// <param name="child">Child.</param>
        /// <typeparam name="T">The 1st type parameter.</typeparam>
        public static void ActiveOrDeactive<T>(this Component child)
            where T : Component
        {
            child.gameObject.SetActive(!child.gameObject.activeSelf);
        }

        /// <summary>
        /// Converts string to Enum type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="strType"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static bool EnumTryParse<T>(string strType, out T result)
        {
            string strTypeFixed = strType.Replace(' ', '_');
            if (Enum.IsDefined(typeof(T), strTypeFixed))
            {
                result = (T)Enum.Parse(typeof(T), strTypeFixed, true);
                return true;
            }
            else
            {
                foreach (string value in Enum.GetNames(typeof(T)))
                {
                    if (value.Equals(strTypeFixed, StringComparison.OrdinalIgnoreCase))
                    {
                        result = (T)Enum.Parse(typeof(T), value);
                        return true;
                    }
                }
                result = default(T);
                return false;
            }
        }

        /// <summary>
        /// Plays the animation if not playing.
        /// </summary>
        /// <param name="child">Child.</param>
        /// <param name="animName">Animation name.</param>
        public static void PlayAnimationIfNotPlaying(this Component child, string animName)
        {
            if (!child.GetComponent<Animation>().IsPlaying(animName))
                child.GetComponent<Animation>().CrossFade(animName);
        }

        /// <summary>
        /// Finds the child gameObject with the name. It searches all children and sub-children,
        /// if It finds the gameObject it returns or it retuns null.
        /// checkDisabled is the bool value to check in  the disabled children as well.
        /// </summary>
        /// <returns>The child game object.</returns>
        /// <param name="parent">Parent.</param>
        /// <param name="childName">Child name.</param>
        /// <param name="checkDisabled">If set to <c>true</c> check disabled.</param>
        public static GameObject FindChildGameObject(
            this Transform parent,
            string childName,
            bool checkDisabled
        )
        {
            if (parent.name.Equals(childName))
                return parent.gameObject;
            Transform[] allChildTransforms = parent.GetComponentsInChildren<Transform>(
                checkDisabled
            );

            foreach (Transform tr in allChildTransforms)
            {
                if (tr.name == childName)
                    return tr.gameObject;
            }
            return null;
        }

        /// <summary>
        /// Finds the child Transform with the name. It searches all children and sub-children,
        /// if It finds the gameObject it returns transofrm or it retuns null.
        /// checkDisabled is the bool value to check in  the disabled children as well.
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="childName"></param>
        /// <param name="checkDisabled"></param>
        /// <returns></returns>
        public static Transform FindChildTransform(
            this Transform parent,
            string childName,
            bool checkDisabled
        )
        {
            Transform tr = null;
            if (parent == null)
                return tr;
            GameObject go = parent.FindChildGameObject(childName, checkDisabled);

            if (go != null)
                tr = go.transform;
            return tr;
        }

        /// <summary>
        /// RayCasts to the distance mentioned and return the transform if hits.
        /// </summary>
        /// <returns>The ray cast tranasfom.</returns>
        /// <param name="tr">Tr.</param>
        /// <param name="dir">Dir.</param>
        /// <param name="dis">Dis.</param>
        public static Transform GetRayCastTranasfom(this Transform tr, Vector3 dir, float dis)
        {
            RaycastHit hit;
            Vector3 from = tr.position + Vector3.up;
            Debug.DrawRay(from, dir * dis, Color.green);
            if (Physics.Raycast(from, dir, out hit, dis))
            {
                if (hit.transform != null)
                    return hit.transform;
            }
            return null;
        }

        /// <summary>
        /// returns only active gameobjects count
        /// </summary>
        /// <param name="Parent"></param>
        /// <returns></returns>
        public static int GetActiveChildCount(this Transform Parent)
        {
            int Count = 0;
            foreach (Transform child in Parent)
            {
                if (child.gameObject.activeSelf)
                    Count++;
            }
            return Count;
        }

        /// <summary>
        /// returns only active gameobjects
        /// </summary>
        /// <param name="Parent"></param>
        /// <returns></returns>
        public static List<GameObject> GetActiveChildGameObjects(this Transform Parent)
        {
            List<GameObject> gameObjects = new List<GameObject>();
            foreach (Transform child in Parent)
            {
                if (child.gameObject.activeSelf)
                    gameObjects.Add(child.gameObject);
            }
            return gameObjects;
        }

        public static void ClampAngles(
            this Component child,
            Vector2 xClamp,
            Vector2 yClamp,
            Vector2 zClamp,
            float inertiaSpeed
        )
        {
            Vector3 currentAngle = child.transform.eulerAngles;

            currentAngle.x = ClampAngle(currentAngle.x, xClamp.x, xClamp.y);
            currentAngle.y = ClampAngle(currentAngle.y, yClamp.x, yClamp.y);
            currentAngle.z = ClampAngle(currentAngle.z, zClamp.x, zClamp.y);

            //child.transform.rotation = Quaternion.Euler (currentAngle);
            child.transform.rotation = Quaternion.Lerp(
                child.transform.rotation,
                Quaternion.Euler(currentAngle),
                Time.deltaTime * inertiaSpeed
            );
        }

        public static float ClampAngle(float angle, float min, float max)
        {
            if (angle > 180f)
                angle -= 360f;
            if (angle < -360f)
                angle += 360f;
            if (angle > 360f)
                angle -= 360f;

            return Mathf.Clamp(angle, min, max);
        }

        static public bool ColorCompare(Color a, Color b, int diff)
        {
            return (int)(Mathf.Abs(a.r - b.r) * 100) < diff
                && (int)(Mathf.Abs(a.g - b.g) * 100) < diff
                && (int)(Mathf.Abs(a.b - b.b) * 100) < diff;
        }

        static public bool ColorCompare(Color a, Color b)
        {
            return ((int)(a.r * 100.0f) == (int)(b.r * 100.0f))
                && ((int)(a.g * 100.0f) == (int)(b.g * 100.0f))
                && ((int)(a.b * 100.0f) == (int)(b.b * 100.0f));
        }

        /// <summary>
        /// Shuffles the generic list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list"></param>
        public static void Shuffle<T>(this List<T> list)
        {
            int n = list.Count;
            System.Random rnd = new System.Random();
            while (n > 1)
            {
                int k = (rnd.Next(0, n) % n);
                n--;
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }

        /// <summary>
        /// returs true, Is Web request done
        /// </summary>
        /// <param name="www"></param>
        /// <returns></returns>
        public static bool IsRequestNotDone(this UnityEngine.Networking.UnityWebRequest request)
        {
            if (!string.IsNullOrEmpty(request.error))
                Log.Print(
                    "WWW call to " + request.url + " returned an Error : " + request.error,
                    LogFilter.Network
                );
            else if (string.IsNullOrEmpty(request.downloadHandler.text))
                Log.Print("WWW call to " + request.url + " returned no text", LogFilter.Network);
            return (
                !request.isDone
                || string.IsNullOrEmpty(request.downloadHandler.text)
                || !string.IsNullOrEmpty(request.error)
            );
        }

        /// <summary>
        /// Sets the alpha of UI Graphic elements
        /// </summary>
        /// <param name="graphic"></param>
        /// <param name="val"></param>
        public static void SetAlpha(this UnityEngine.UI.Graphic graphic, float val)
        {
            Color c = graphic.color;
            c.a = val;
            graphic.color = c;
        }

        /// <summary>
        /// Adds IEnumerable type to current one.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target"></param>
        /// <param name="source"></param>
        public static void AddRange<T>(this ICollection<T> target, IEnumerable<T> source)
        {
            if (target == null)
                throw new ArgumentNullException(target.ToString());
            if (source == null)
                throw new ArgumentNullException(source.ToString());
            foreach (var element in source)
                target.Add(element);
        }

        public static void ShuffleMe<T>(this IList<T> list)
        {
            System.Random random = new System.Random();
            int n = list.Count;

            for (int i = list.Count - 1; i > 1; i--)
            {
                int rnd = random.Next(i + 1);

                T value = list[rnd];
                list[rnd] = list[i];
                list[i] = value;
            }
        }

        /// <summary>
        /// Check internet availibility
        /// </summary>
        /// <returns></returns>
        public static bool IsNetReachable()
        {
            bool result = false;
            result = (Application.internetReachability != NetworkReachability.NotReachable);
            return result;
        }

        // Convert an object to a byte array
        public static byte[] ObjectToByteArray(System.Object obj)
        {
            if (obj == null)
                return null;

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, obj);

            return ms.ToArray();
        }

        // Convert a byte array to an Object
        public static System.Object ByteArrayToObject(byte[] arrBytes)
        {
            MemoryStream memStream = new MemoryStream();
            BinaryFormatter binForm = new BinaryFormatter();
            memStream.Write(arrBytes, 0, arrBytes.Length);
            memStream.Seek(0, SeekOrigin.Begin);
            System.Object obj = (System.Object)binForm.Deserialize(memStream);

            return obj;
        }

        /// <summary>
        /// Parses string data and find value by given key
        /// </summary>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string GetValueFromString(
            string data,
            string key,
            char dataSeparator,
            char keySeparator
        )
        {
            string value = string.Empty;
            string[] elements = data.Split(dataSeparator);
            for (int i = 0; i < elements.Length; i++)
            {
                if (elements[i].Contains(key))
                    value = elements[i].Split(keySeparator)[1];
            }

            return value;
        }

        /// <summary>
        /// Returns component after Copying all values in given object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="comp"></param>
        /// <param name="other"></param>
        /// <returns></returns>
        public static T GetCopyOf<T>(this Component comp, T other)
            where T : Component
        {
            Type type = comp.GetType();

            // Return if, type mis-match.
            if (type != other.GetType())
                return null;

            BindingFlags flags =
                BindingFlags.Public
                | BindingFlags.NonPublic
                | BindingFlags.Instance
                | BindingFlags.Default
                | BindingFlags.DeclaredOnly;

            PropertyInfo[] pinfos = type.GetProperties(flags);
            foreach (var pinfo in pinfos)
            {
                if (pinfo.CanWrite)
                {
                    try
                    {
                        pinfo.SetValue(comp, pinfo.GetValue(other, null), null);
                    }
                    catch { } // In case of NotImplementedException being thrown. For some reason specifying that exception didn't seem to catch it, so I didn't catch anything specific.
                }
            }

            FieldInfo[] finfos = type.GetFields(flags);
            foreach (var finfo in finfos)
            {
                finfo.SetValue(comp, finfo.GetValue(other));
            }

            return comp as T;
        }

        /// <summary>
        /// Returns true if the string has any data
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static bool HasValue(this string target)
        {
            return (!string.IsNullOrEmpty(target));
        }

#if UNITY_EDITOR
        /// <summary>
        /// Applies Color codes to all gameobjects which are generated by GSVault
        /// </summary>
        /// <param name="go"></param>
        public static void MarkAsGSObject(GameObject go)
        {
            HighlightGameObject(
                go,
                new Color(0.1f, 0.2f, 0.6f),
                Color.white,
                FontStyle.BoldAndItalic
            );
        }

        /// <summary>
        /// Highlights the Gameobject in Hirearchy Window
        /// </summary>
        /// <param name="go"></param>
        /// <param name="backGroundColor"></param>
        /// <param name="textColor"></param>
        /// <param name="textStyle"></param>
        public static void HighlightGameObject(
            GameObject go,
            Color backGroundColor,
            Color textColor,
            FontStyle textStyle
        )
        {
            if (go == null)
                return;

            Scripts.Utility.HierarchyHighlighter highlighter =
                go.transform.GetOrAddComponent<Scripts.Utility.HierarchyHighlighter>();
            highlighter.Background_Color = backGroundColor;
            highlighter.Text_Color = textColor;
            highlighter.TextStyle = textStyle;
        }
#endif
    }
}
