﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Unity
{
    /// <summary>
    /// Unity Logger message
    /// </summary>
    public class UnityLogger : ILogger
    {
        private Dictionary<LogFilter, string> logColorMap = new Dictionary<LogFilter, string>
        {
            { LogFilter.Default, "#ffffff" },
            { LogFilter.Game, "#9b5fe0" },
            { LogFilter.Data, "#16a4d8" },
            { LogFilter.Network, "#efdf48" },
            { LogFilter.UI, "#60dbe8" },
            { LogFilter.GameEvent, "#8bd346" },
            { LogFilter.Error, "#d64e12" }
        };
        private const int truncateValue = 13000;

        public delegate void Logdelegate(string message);
        public Logdelegate logDelegate;
        /// <summary>
        /// Logs a Error message to the Unity Console
        /// </summary>
        /// <param name="message"></param>
        public void Error(object message)
        {
#if CLOUD_EXCEPTION
            Debug.LogError(new Exception(message.ToString()));
#else
            if (CheckForTruncated(message))
            {
                logDelegate = Debug.LogError;
                SplitTruncatedString(message, LogFilter.Error, logDelegate);
            }
            else
            {
                 Debug.LogError(message);
            }
#endif
        }

        /// <summary>
        /// Logs a message to the Console
        /// </summary>
        /// <param name="message"></param>
        public void Print(object message, UnityEngine.Object obj, LogFilter logFilter)
        {
            string color;
            if (!logColorMap.TryGetValue(logFilter, out color))
            {
                color = "#000000";
            }
            if (CheckForTruncated(message))
            {
                logDelegate = Debug.Log;
                SplitTruncatedString(message, logFilter, logDelegate, color, obj);
            }
            else
            {
                Debug.Log($"<color={color}>[{logFilter}]: {message}</color>", obj);
            }
        }

        /// <summary>
        /// Logs a message to the Console
        /// </summary>
        /// <param name="message"></param>
        public void Print(object message, LogFilter logFilter)
        {
            string color;
            
            if (!logColorMap.TryGetValue(logFilter, out color))
            {
                color = "000000";
            }
            if (CheckForTruncated(message))
            {
                logDelegate = Debug.Log;
                SplitTruncatedString(message, logFilter, logDelegate,color);
            }
            else
            {
                Debug.Log($"<color={color}>[{logFilter}]: {message}</color>");
            }
           
        }

        /// <summary>
        /// Logs a message as Warning
        /// </summary>
        /// <param name="message"></param>
        public void Warning(object message)
        {
            if(CheckForTruncated(message))
            {
                logDelegate = Debug.LogWarning;
                SplitTruncatedString(message, LogFilter.Default, logDelegate);
            }
            else
            {
                Debug.LogWarning(message.ToString());
            }
        }
        
        private bool CheckForTruncated(object _log)
        {
            return _log.ToString().Length >= truncateValue;
        }
        private void SplitTruncatedString(object message, LogFilter logFilter, Logdelegate log, string color = null, UnityEngine.Object obj = null)
        {
            string messageLog = message.ToString();
            int indexValue = 1;
            int length;
            string section;
            string prefix;
            string formattedSection;
            string result;
            for (int i = 0; i < messageLog.Length; i += truncateValue)
            {
                length = Math.Min(truncateValue, messageLog.Length - i);
                section = messageLog.Substring(i, length);
                prefix = $"[{logFilter}] {indexValue}) ";
                formattedSection = color == null ? $"{prefix}{section}" : $"<color={color}>{prefix} {section}</color>";
                result = $"{formattedSection} {obj}";
                log(result);
                indexValue++;
            }
        }
    }
}
