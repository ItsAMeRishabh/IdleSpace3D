﻿
using System;
using UnityEngine.UI;

namespace GS.Unity
{
    /// <summary>
    /// Timer Type defines the type of time stored in TimerComponent
    /// Remaing Time is being used for OTP, and question timer countdown
    /// Target time is being used for unlocking a particular match category
    /// </summary>
    public enum TimerType
    {
        remainingTime,
        targetTime
    }

    /// <summary>
    /// Timer Component struct is used to hold the essential timer data types for time related operations in game
    /// </summary>
    [System.Serializable]
    public struct TimerComponent
    {
        private double remainingTime;
        private DateTime targetTime;
        public TimerType timerType;

        // realTime is displayed via TimeSpan and targetTime is Displayed via DateTime
        public string rtDisplayPattern, ttDisplayPattern;

        public Text text;
        public Slider slider;
        public float fromSliderValue;
        public float toSliderValue;

        public DateTime TargetTime
        {
            set
            {
                targetTime = value;
            }
            get
            {
                return targetTime;
            }

        }

        // remainingSeconds 
        public double RemainingTime
        {
            set
            {
                remainingTime = value;
            }
            get
            {
                return remainingTime;
            }
        }
    }
}