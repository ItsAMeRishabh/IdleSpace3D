﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GS.Unity
{
    public class GetCurrentTimeEvent : GameEvent
    {
        public Action<DateTime> callbackWithCurrentTime;
        public GetCurrentTimeEvent(Action<DateTime> callback)
        {
            callbackWithCurrentTime = callback;
        }
    }


    public class TimerComponentEvent : GameEvent
    {
        public TimerComponent timerComponent;
        public GameObject callBackGameobject;
        public System.DateTime initTime;
        public Action<GameObject> onTimerCompleted;
        public TimerComponentEvent(TimerComponent timerComponent, Action<GameObject> onTimerCompleted, GameObject callBackGameobject)
        {
            this.timerComponent = timerComponent;
            this.onTimerCompleted = onTimerCompleted;
            this.callBackGameobject = callBackGameobject;
        }
    }

    public class GetDurationAndElaspedTime : GameEvent
    {
        public Action<float[]> durationAndElaspedTime;
        public GetDurationAndElaspedTime(Action<float[]> durationAndElaspedTime)
        {
            this.durationAndElaspedTime = durationAndElaspedTime;
        }
    }

    public class RemoveTimerComponentEvents : GameEvent
    {
        public TimerComponentEvent removeTimerComponentEvent;
        public RemoveTimerComponentEvents(TimerComponentEvent removeTimerComponentEvent)
        {
            this.removeTimerComponentEvent = removeTimerComponentEvent;
        }
    }
}
