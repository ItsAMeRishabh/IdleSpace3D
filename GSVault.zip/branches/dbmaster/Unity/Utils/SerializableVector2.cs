using UnityEngine;

namespace GS
{
    [System.Serializable]
    public class SerializableVector2
    {
        public float x;
        public float y;

        public SerializableVector2(Vector2 vector)
        {
            x = vector.x;
            y = vector.y;
        }

        public Vector2 ToVector2()
        {
            return new Vector3(x, y);
        }
    }
}
