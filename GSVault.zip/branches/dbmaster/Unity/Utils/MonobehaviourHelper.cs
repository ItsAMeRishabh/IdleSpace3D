﻿using GS.Unity;
using System.Collections;

/// <summary>
/// Common MonoBehaviour for all of it functions. It is a singleTon class.
/// </summary>
public class MonobehaviourHelper : SingleTon<MonobehaviourHelper>
{
    private void Awake()
    {
        DoNotDestroyOnLoad = true;
    }

    ///// <summary>
    ///// Finds GameObject of Type 'T' and returns it if found in scene, else null.
    ///// </summary>
    ///// <typeparam name="T"></typeparam>
    ///// <returns></returns>
    //public T FindObjectOfTypeLocal<T>() where T : UnityEngine.Object
    //{
    //    return FindObjectOfType<T>();
    //}

    //public void DestroyLocal(UnityEngine.Object obj, float t = 0.0f)
    //{
    //    if (t == 0.0f)
    //        DestroyImmediate(obj);
    //    else
    //        DestroyObject(obj, t);
    //}

    //public void DestroyImmediateLocal(UnityEngine.Object obj, float t = 0.0f)
    //{
    //    Destroy(obj, t);
    //}

    // ------- Not required as we can call directly monobehaviour methods -----

    ///1. StartCoroutine()
    ///// <summary>
    ///// Starts Coroutine
    ///// </summary>
    ///// <param name="enumerator"></param>
    //public void ProcessCoroutine(IEnumerator enumerator)
    //{
    //    StartCoroutine(enumerator);
    //}
}