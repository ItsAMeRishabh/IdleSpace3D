#if USE_ADDRESSABLES
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace GS
{
    public static class AddressableHandler
    {
        public static Dictionary<AssetReference, UnityEngine.Object> loadedAssets =
            new Dictionary<AssetReference, UnityEngine.Object>();

        public static IEnumerator DownloadDependancy(string tag, Action<long, long> OnUpdate = null)
        {
            var downloadDependenciesAsync = Addressables.DownloadDependenciesAsync(tag);
            var totalBytes = downloadDependenciesAsync.GetDownloadStatus().TotalBytes;

            do
            {
                long downloadedBytes = downloadDependenciesAsync
                    .GetDownloadStatus()
                    .DownloadedBytes;
                OnUpdate?.Invoke(downloadedBytes, totalBytes);

                yield return null;
            } while (!downloadDependenciesAsync.IsDone);
        }

        public static void LoadAsset<T>(AssetReferenceT<T> assetReference, Action<T> callback)
            where T : UnityEngine.Object
        {
            if (loadedAssets.TryGetValue(assetReference, out var asset))
            {
                callback?.Invoke((T)asset);
            }
            else
            {
                var handler = assetReference.LoadAssetAsync();
                handler.Completed += handler =>
                {
                    loadedAssets.Add(assetReference, handler.Result);
                    callback?.Invoke(handler.Result);
                };
            }
        }

        public static async Task<T> LoadAssetAsync<T>(object tag)
        {
            return await Addressables.LoadAssetAsync<T>(tag).Task;
        }

        public static void LoadAsset<T>(string tag, Action<T> callback)
        {
            Addressables.LoadAssetAsync<T>(tag).Completed += handler =>
            {
                callback?.Invoke(handler.Result);
            };
        }

        public static void Instantiate(
            string tag,
            Transform transform = null,
            Action<GameObject> callback = null
        )
        {
            Addressables.InstantiateAsync(tag, transform).Completed += handler =>
            {
                callback?.Invoke(handler.Result);
            };
        }

        public static void Release<T>(T obj)
        {
            Addressables.Release(obj);
        }

        public static void ReleaseInstance(GameObject gameObject)
        {
            Addressables.ReleaseInstance(gameObject);
        }
    }
}
#endif
