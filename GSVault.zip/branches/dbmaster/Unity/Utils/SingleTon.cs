﻿using UnityEngine;

namespace GS.Unity
{

    /// <summary>
    /// Base Monobehaviour Singleton class
    /// Use this template until and unless it is really mandatory
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class SingleTon<T> : MonoBehaviour where T : MonoBehaviour
    {
        private static T _instance;
        private static object _lock = new object();
        private static bool _isApplicationQuitting = false;
        private static bool _doNotDestroyOnLoad = false;
        private static bool _checkForAppQuitting = true;

        /// <summary>
        /// Returd true, if Application is quitting
        /// </summary>
        public static bool CheckForAppQuitting
        {
            get { return SingleTon<T>._checkForAppQuitting; }
            set { SingleTon<T>._checkForAppQuitting = value; }
        }

        /// <summary>
        /// Do not destyroy this gameobject on loading Next Scene, if this is true    
        /// </summary>
        public static bool DoNotDestroyOnLoad
        {
            get
            {
                return _doNotDestroyOnLoad;
            }
            set
            {
                _doNotDestroyOnLoad = value;
                if (value)
                    DontDestroyOnLoad(Instance);
            }
        }

        /// <summary>
        /// Is Gameobject Intialized
        /// </summary>
        /// <returns></returns>
        public static bool IsInstatiated()
        {
            return _instance != null;
        }

        /// <summary>
        /// Returns instance of this class. 
        /// </summary>
        public static T Instance
        {
            get
            {
                if (_isApplicationQuitting && CheckForAppQuitting == true)
                {
                    Log.Error("[Singleton] Instance '" + typeof(T) +
                                     "' already destroyed on application quit." +
                                     " Won't create again - returning null.");
                    return null;
                }

                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = (T)FindObjectOfType(typeof(T));

                        if (FindObjectsOfType(typeof(T)).Length > 1)
                        {
                            Log.Warning("[Singleton] Something went really wrong " +
                                           " - there should never be more than 1 singleton!" +
                                           " Reopenning the scene might fix it." + FindObjectOfType(typeof(T)).name);
                            return _instance;
                        }

                        if (_instance == null)
                        {
                            GameObject singleton = new GameObject();
                            _instance = singleton.AddComponent<T>();
                            singleton.name = "(singleton) " + typeof(T).ToString();

                            if (DoNotDestroyOnLoad == true)
                                DontDestroyOnLoad(singleton);
                        }
                    }

                    return _instance;
                }
            }
        }

        /// <summary>
        /// On Detroy, setting the application quit flag true
        /// </summary>
        public virtual void OnDestroy()
        {
            _isApplicationQuitting = true;
            _instance = null;
        }
    }
}