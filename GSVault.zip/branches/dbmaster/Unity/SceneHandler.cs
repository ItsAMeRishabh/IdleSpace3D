﻿using GS.Data;
using GS.Data.DataConsts;
using System;
using UnityEngine;


namespace GS
{
    /// <summary>
    /// This is the Base Scipt in Scene Handler. It invokes Game Manager and current scene controllers
    /// Attach a Scene Handler component in all the scenes
    /// </summary>
    public class SceneHandler<TSettingType, TPacketType> : MonoBehaviour
        where TSettingType : Enum
        where TPacketType : Enum
    {
        /// <summary>
        /// To send progress of 'Initialize()' of this sceneHandler
        /// </summary>
        public Action<float> initProgressCallback;

        public GameConsts.GameState gameState;
        public int startScreen = 1;
        public string uiPrefabPath;

        EventManager eventManager;
        protected InputManager inputManager;

        protected GS.MainEntry<TSettingType, TPacketType> mainEntry;

        /// <summary>
        /// Adds Event Manager to scene
        /// </summary>
        public virtual void Awake()
        {
            mainEntry = GS.MainEntry<TSettingType, TPacketType>.Instance;

            
            //  EventManager.Instance.AddListener<GameEvents.Data.DataInitializationDoneEvent>(OnDataInitDoneEvent);
        }

        // Use this for initialization
        protected void Start()
        {
            eventManager = EventManager.Instance;
            transform.position = Vector3.zero;

           
            inputManager = new InputManager();

            Utils.EventSync(new GameEvents.ChangeGameState(gameState));
            Initialize();

            // TODO : Implement using Data Event instead of Resources.Load
            GameObject uiPrefab = null;

            if (string.IsNullOrEmpty(uiPrefabPath))
                return;
            Utils.EventSync(new LoadPrefabEvent(AssetDataBundleKeys.UIPrefabs, AssetDataBundleKeys.UIPrefabs + "/" + uiPrefabPath, 
                (gameObject) => 
                { 
                    uiPrefab = gameObject;

                    if (uiPrefab != null)
                    {
                        GameObject go = GameObject.Instantiate(uiPrefab);

                        if (go != null)
                        {
                            go.name = "GUI";
#if UNITY_EDITOR
                            GS.UnityExtensions.MarkAsGSObject(go);
#endif
                            CreateGUI(go);
                            Utils.EventAsync(new GS.Events.UIPrefabLoadedEvent(go, (int)startScreen));
                        }
                    }
                    else
                    {
                        Log.Error("Unable to find UI prefab = " + uiPrefabPath);
                    }
                }));
        }


        /// <summary>
        /// Listener callback function for On data Initialization done Event
        /// </summary>
        /// <param name="dataInitEvent"></param>
        private void OnDataInitDoneEvent(GameEvents.DataInitializationDoneEvent dataInitEvent)
        {
            if (dataInitEvent != null)
            {
                if (dataInitEvent.success)
                {
                    bool isAutoProgress = Initialize();

                    // Make sure to call this callback after 'Initialize()' and set it's value as '100%'
                    if (isAutoProgress && initProgressCallback != null)
                        initProgressCallback(100);
                }
                else
                    Log.Error("Scene Handler : Not able to initialize controllers as Data Controller failed");
            }

        }

        /// <summary>
        /// Update Event Manager, Base.Update() should be called if overriding this method 
        /// </summary>
        protected virtual void Update()
        {
            if (eventManager != null)
                eventManager.Update();

            if (inputManager != null)
                inputManager.Update();
        }

        /// <summary>
        /// Remove all controllers of the current scene
        /// </summary>
        protected virtual void OnDestroy()
        {
           // if (GameManager.Instance != null)
           //     GameManager.Instance.RemoveAllControllers();

            if (EventManager.Instance != null && eventManager != null)
                eventManager.Release();
            eventManager = null;
        }

        /// <summary>
        /// Requires AutoProgress or not. (Notify that 100% is done to sceneProgress callback, if any)
        /// </summary>
        /// <returns></returns>
        protected virtual bool Initialize()
        {
            return true;
        }

        protected void AddSceneController(IController controller)
        {
            if (controller == null)
                return;

            Utils.EventSync(new GameEvents.AddSceneController(controller));
        }

        protected virtual void CreateGUI(GameObject gui)
        {

        }
    }
}
