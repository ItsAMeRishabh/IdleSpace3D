==========================================================================================================
*** INSTRUCTIONS
==========================================================================================================
- Create a folder with name "GSVault" inside your [Project_Path]/Assets folder
- Maintain seperate repository for your project and do not commit GSVault folder to [Project_Name] 
	repository. As GSVault has ots own repository
- GSVault contains core architecture, common features and Utils etc.. which are common for all projects
- Make sure you are not modifying the files inside GSVault unless if it is not affecting other project
----------------------------------------------------------------------------------------------------------

**********************************************************************************************************
**********************************************************************************************************
**********************************************************************************************************
==========================================================================================================
*** FIRST TIME SET UP
==========================================================================================================
- While setting up the project for the first time
- Create GSVault.cs file outside GSVault folder and add the following code
- Feel free to add more enum values in your GSVault.cs as per your project specific requirements
==========================================================================================================
namespace GS
{
    public enum SettingsType
    {
        Language,
        Music,
        SoundEffects,
        Graphics,
        Tutorial
    }

    /// <summary>
    /// Typical Scene names that can be used in any Project. 
    /// Add/Remove values based on number of scenes 
	/// Enum value should match with actual scene file name
    /// </summary>
    public enum SceneType
    {
        Splash,
        Intro,
        MainMenu,
        Loading,
        Game,
        Results,
        Customization,
        Store,
        Other
    }
}
----------------------------------------------------------------------------------------------------------