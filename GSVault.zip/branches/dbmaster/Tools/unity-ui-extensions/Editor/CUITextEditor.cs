﻿/// Credit Titinious (https://github.com/Titinious)
/// Sourced from - https://github.com/Titinious/CurlyUI

using UnityEditor;

namespace UnityEngine.UI.Extensions
{
    [UnityEditor.CustomEditor(typeof(CUIText))]
    public class CUITextEditor : CUIGraphicEditor { }
}