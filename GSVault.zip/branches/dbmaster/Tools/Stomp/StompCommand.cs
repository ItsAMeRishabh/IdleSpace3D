﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StompHelper
{
    /// <summary>
    /// Stomp Client Command
    /// </summary>
    public enum StompClientCommand
    {
        CONNECT,
        DISCONNECT,
        SUBSCRIBE,
        UNSUBSCRIBE,
        SEND,
        RECEIPT //receipt
    }

    /// <summary>
    /// Server Response
    /// </summary>
    public enum StompResponse
    {
        CONNECTED,
        MESSAGE,
        ERROR
    }
}
